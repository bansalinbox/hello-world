package com.output;

import com.App;
import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.models.Gap;
import com.models.Identity;
import com.models.Status;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.beans.PropertyVetoException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Collection;

public class PostGres {

    public static Logger logger = LoggerFactory.getLogger(PostGres.class);

    public static ComboPooledDataSource cpds = new ComboPooledDataSource();

    public static void init() throws PropertyVetoException {
        cpds.setDriverClass("org.postgresql.Driver");
        cpds.setIdleConnectionTestPeriod(60 * 5);
        cpds.setMinPoolSize(1);
        cpds.setInitialPoolSize(1);
        cpds.setAcquireIncrement(1);
        cpds.setMaxPoolSize(App.connections);
//        cpds.setJdbcUrl("jdbc:postgresql://cpc-icollab-db-sys.cpc.silver.com/icollaborate?user=rtde&password=rtdedataexchanger&ssl=false");
        cpds.setJdbcUrl("jdbc:postgresql://icollab-micro.crdn3zrawkzk.us-east-1.rds.amazonaws.com/icollaborate?user=rtde&password=rtdedataexchanger&ssl=false");
    }

    public static boolean postIdentities(Collection<Identity> identities) {
        Connection connection = null;
        PreparedStatement st = null;
        try {
            connection = cpds.getConnection();
//            st = connection.prepareStatement("INSERT INTO gaps (ibor_id, gap_case, gap_type, gap_id, condition, description) VALUES (?,?, ?, ?, ?, ?) ON CONFLICT (ibor_id, gap_id, gap_case, gap_type) DO UPDATE SET first_identified_date = EXCLUDED.first_identified_date, condition = EXCLUDED.condition, description = EXCLUDED.description, load_date = EXCLUDED.load_date, score = EXCLUDED.score, ndc_id = EXCLUDED.ndc_id, ndc_label = EXCLUDED.ndc_label, inactive = EXCLUDED.inactive");
            st = connection.prepareStatement("INSERT INTO patient_identity (ibor_id, gender, first_name, last_name, dob) VALUES (?, ?, ?, ?, ?) ON CONFLICT (ibor_id) DO UPDATE SET first_name = EXCLUDED.first_name, last_name = EXCLUDED.last_name, gender = EXCLUDED.gender, dob = EXCLUDED.dob");
            for (Identity identity : identities) {
                st.setString(1, identity.iborId);
                st.setString(2, identity.gender);
                st.setString(3, identity.firstName);
                st.setString(4, identity.lastName);
                st.setDate(5, identity.dob);
                st.addBatch();
            }
            int x[] = st.executeBatch();
            for (int i = 0; i < x.length; i++) {
                if (x[i] != 1) {
                    closeStatement(st);
                    closeConnection(connection);
                    return false;
                }
            }
            Status.mainStatus.addPostedMessages(identities.size());
            return true;
        } catch (Exception e) {
            logger.error("Error", e);
            try {
                Thread.sleep(30000);
            } catch (InterruptedException ee) {
                ee.printStackTrace();
            }
        } finally {
            closeStatement(st);
            closeConnection(connection);
        }
        return false;
    }

    public static boolean postGaps(Collection<Gap> gaps) {
        Connection connection = null;
        PreparedStatement st = null;
        try {
            connection = cpds.getConnection();
            //need other parts of sql and inactive
            st = connection.prepareStatement("INSERT INTO gaps (ibor_id, gap_case, gap_type, gap_id, condition, description) VALUES (?,?, ?, ?, ?, ?) ON CONFLICT (ibor_id, gap_id, gap_case, gap_type) DO UPDATE SET first_identified_date = EXCLUDED.first_identified_date, condition = EXCLUDED.condition, description = EXCLUDED.description, load_date = EXCLUDED.load_date, score = EXCLUDED.score, ndc_id = EXCLUDED.ndc_id, ndc_label = EXCLUDED.ndc_label, inactive = EXCLUDED.inactive");
            for (Gap gap : gaps) {
                st.setString(1, gap.iborId);
                st.setString(2, gap.gapCase);
                st.setString(3, gap.gapType);
                st.setString(4, gap.gapId);
                st.setString(5, gap.condition);
                st.setString(6, gap.description);
                st.addBatch();
            }
            int x[] = st.executeBatch();
            for (int i = 0; i < x.length; i++) {
                if (x[i] != 1) {
                    closeStatement(st);
                    closeConnection(connection);
                    return false;
                }
            }
            Status.mainStatus.addPostedMessages(gaps.size());
            return true;
        } catch (Exception e) {
            logger.error("Error", e);
        } finally {
            closeStatement(st);
            closeConnection(connection);
        }
        return false;
    }

    private static void closeConnection(Connection connection) {
        if (connection == null) return;
        try {
            connection.close();
        } catch (Exception e) {
            logger.error("Error", e);
        }
    }

    private static void closeStatement(PreparedStatement statement) {
        if (statement == null) return;
        try {
            statement.close();
        } catch (Exception e) {
            logger.error("Error", e);
        }
    }

}
