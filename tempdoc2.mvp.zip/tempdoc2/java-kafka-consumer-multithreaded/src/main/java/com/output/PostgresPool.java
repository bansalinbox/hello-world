package com.output;

import com.App;
import com.models.Identity;
import com.models.PartitionOffsetData;

import java.util.Collection;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class PostgresPool {

    public static ThreadPoolExecutor pool = (ThreadPoolExecutor) Executors.newFixedThreadPool(App.connections);

    public static void executeTask(Collection<Identity> identities, List<PartitionOffsetData> partitionOffsetData) {
        pool.execute(new PostgresThread(identities, partitionOffsetData));
    }

    public static void init() {
        pool.setKeepAliveTime(30000, TimeUnit.MILLISECONDS);
    }

}
