package com.output;

import com.kafka.consumer.MasterConsumerThread;
import com.models.Identity;
import com.models.PartitionOffsetData;
import com.models.Status;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Collection;
import java.util.List;

public class PostgresThread implements Runnable {

    private List<PartitionOffsetData> partitionOffsetDataList;
    private Collection<Identity> identities;

    public PostgresThread(Collection<Identity> identities, List<PartitionOffsetData> partitionOffsetDataList) {
        this.identities = identities;
        this.partitionOffsetDataList = partitionOffsetDataList;
    }

    private static void closeConnection(Connection connection) {
        if (connection == null) return;
        try {
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void closeStatement(PreparedStatement statement) {
        if (statement == null) return;
        try {
            statement.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        Connection connection = null;
        PreparedStatement st = null;
        try {
            connection = PostGres.cpds.getConnection();
//            st = connection.prepareStatement("INSERT INTO gaps (ibor_id, gap_case, gap_type, gap_id, condition, description) VALUES (?,?, ?, ?, ?, ?) ON CONFLICT (ibor_id, gap_id, gap_case, gap_type) DO UPDATE SET first_identified_date = EXCLUDED.first_identified_date, condition = EXCLUDED.condition, description = EXCLUDED.description, load_date = EXCLUDED.load_date, score = EXCLUDED.score, ndc_id = EXCLUDED.ndc_id, ndc_label = EXCLUDED.ndc_label, inactive = EXCLUDED.inactive");
            st = connection.prepareStatement("INSERT INTO patient_identity (ibor_id, gender, first_name, last_name, dob) VALUES (?, ?, ?, ?, ?) ON CONFLICT (ibor_id) DO UPDATE SET first_name = EXCLUDED.first_name, last_name = EXCLUDED.last_name, gender = EXCLUDED.gender, dob = EXCLUDED.dob");
            for (Identity identity : identities) {
                st.setString(1, identity.iborId);
                st.setString(2, identity.gender);
                st.setString(3, identity.firstName);
                st.setString(4, identity.lastName);
                st.setDate(5, identity.dob);
                st.addBatch();
            }
            int x[] = st.executeBatch();

            for (int i = 0; i < x.length; i++) {
                if (x[i] != 1) {
                    rollback();
                    closeStatement(st);
                    closeConnection(connection);
                    return;
                }
            }
            Status.mainStatus.addPostedMessages(identities.size());
            commit();
        } catch (Exception e) {
            rollback();
            e.printStackTrace();
        } finally {
            closeStatement(st);
            closeConnection(connection);
        }
    }

    private void commit() {
        for (PartitionOffsetData partitionOffsetData : partitionOffsetDataList) {
            partitionOffsetData.commited = 1;
        }
    }

    private void rollback() {
        for (PartitionOffsetData partitionOffsetData : partitionOffsetDataList) {
            partitionOffsetData.commited = -1;
            MasterConsumerThread.commitInterval = 1000;
        }
    }

}
