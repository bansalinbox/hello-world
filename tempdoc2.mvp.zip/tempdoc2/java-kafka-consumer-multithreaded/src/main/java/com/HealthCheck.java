package com;

import ch.qos.logback.classic.Level;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.models.Status;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;

public class HealthCheck {

    public static Logger logger = LoggerFactory.getLogger(HealthCheck.class);

    public static void startHealthCheck() throws Exception {
        HttpServer server = HttpServer.create(new InetSocketAddress(8080), 0);
        server.createContext("/alive", new AliveHandler());
        server.createContext("/status", new StatusHandler());
        server.createContext("/ready", new ReadyHandler());
        server.createContext("/log/debug", new LogLevelHandler(Level.DEBUG));
        server.createContext("/log/trace", new LogLevelHandler(Level.TRACE));
        server.createContext("/log/warn", new LogLevelHandler(Level.WARN));
        server.createContext("/log/info", new LogLevelHandler(Level.INFO));
        server.createContext("/log/all", new LogLevelHandler(Level.ALL));
        server.createContext("/log/error", new LogLevelHandler(Level.ERROR));
        server.setExecutor(null);
        server.start();
    }

    static class StatusHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange t) throws IOException {
            ObjectMapper mapper = new ObjectMapper();
            String response = mapper.writeValueAsString(Status.mainStatus);
            t.sendResponseHeaders(200, response.length());
            OutputStream os = t.getResponseBody();
            os.write(response.getBytes());
            os.close();
        }
    }

    static class AliveHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange t) throws IOException {
            if (Status.mainStatus.fails > 30) {
                Status.response = 404;
                logger.error("Consumer Failure is too High: " + Status.mainStatus.fails);
            } else {
                Status.mainStatus.fails = 0;
            }
            String response = String.valueOf(Status.response);
            t.sendResponseHeaders(Status.response, response.length());
            OutputStream os = t.getResponseBody();
            os.write(response.getBytes());
            os.close();
        }
    }

    static class ReadyHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange t) throws IOException {
            if (Status.mainStatus.fails > 30) {
                Status.response = 404;
                logger.error("Consumer Failure is too High: " + Status.mainStatus.fails);
            } else {
                Status.mainStatus.fails = 0;
            }
            String response = String.valueOf(Status.response);
            t.sendResponseHeaders(Status.response, response.length());
            OutputStream os = t.getResponseBody();
            os.write(response.getBytes());
            os.close();
        }
    }

    static class LogLevelHandler implements HttpHandler {
        Level level;

        public LogLevelHandler(Level level) {
            this.level = level;
        }

        @Override
        public void handle(HttpExchange t) throws IOException {
            App.setLoggingLevel(level);
            String response = String.valueOf(Status.response);
            t.sendResponseHeaders(Status.response, response.length());
            OutputStream os = t.getResponseBody();
            os.write(response.getBytes());
            os.close();
        }
    }

}