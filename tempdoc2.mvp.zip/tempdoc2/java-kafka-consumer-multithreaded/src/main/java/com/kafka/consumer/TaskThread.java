package com.kafka.consumer;

import com.App;
import com.models.Identity;
import com.models.PartitionOffsetData;
import com.models.Status;
import com.output.PostgresPool;
import org.apache.avro.Schema;
import org.apache.avro.SchemaCompatibility;
import org.apache.avro.file.DataFileReader;
import org.apache.avro.file.DataFileStream;
import org.apache.avro.file.SeekableByteArrayInput;
import org.apache.avro.generic.GenericDatumReader;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.io.DatumReader;
import org.apache.avro.specific.SpecificDatumReader;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

public class TaskThread implements Runnable {

    private List<byte[]> task;
    private List<PartitionOffsetData> partitionOffsetDataList;

    public TaskThread(List<byte[]> task, List<PartitionOffsetData> partitionOffsetDataList) {
        this.task = task;
        this.partitionOffsetDataList = partitionOffsetDataList;
    }

    public static DataFileStream<GenericRecord> deserializeRecord(byte[] value) {
        ByteArrayInputStream stream = new ByteArrayInputStream(value);
        DatumReader<GenericRecord> datumReader = new GenericDatumReader<>(App.schema);
        DataFileStream<GenericRecord> dataFileReader = null;
        try {
            dataFileReader = new DataFileStream<>(stream, datumReader);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return dataFileReader;
    }

    public static List<GenericRecord> deserializeGenericWithSchema(byte[] message) throws IOException {
        List<GenericRecord> listOfRecords = new ArrayList<>();
        DatumReader<GenericRecord> reader = new SpecificDatumReader<>();
        DataFileReader<GenericRecord> fileReader =
                new DataFileReader<>(new SeekableByteArrayInput(message), reader);
        while (fileReader.hasNext()) {
            listOfRecords.add(fileReader.next());
        }
        return listOfRecords;
    }

    public static boolean checkSchemaCompatibility(Schema one, Schema two) {
        if (one.getFullName().equals(two.getFullName())) {
            SchemaCompatibility.SchemaPairCompatibility compatibility = SchemaCompatibility.checkReaderWriterCompatibility(one, two);
            return compatibility.getType() == SchemaCompatibility.SchemaCompatibilityType.COMPATIBLE;
        }
        return false;
    }

    @Override
    public void run() {
        HashMap<String, Identity> hashMap = new HashMap<>();
        AtomicLong skipped = new AtomicLong();
        task.forEach(record -> {
            try {
                DataFileStream<GenericRecord> dataFileReader = deserializeRecord(record);
                if (dataFileReader != null) {
                    if (checkSchemaCompatibility(dataFileReader.getSchema(), App.schema)) {
                        while (dataFileReader.hasNext()) {
                            GenericRecord genericRecord = dataFileReader.next();
                            if (genericRecord != null) {
                                Identity identity = new Identity(genericRecord);
                                if (identity != null) {
                                    hashMap.put(identity.iborId, identity);
                                }
                            }
                        }
                    } else {
                        skipped.getAndIncrement();
                    }
                    try {
                        dataFileReader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        Status.mainStatus.addSkippedMessages(skipped.get());

        if (hashMap.size() > 0) {
//            if (PostGres.postIdentities(hashMap.values())) {
//                commit();
//            } else {
//                rollback();
//                Status.mainStatus.fails++;
//            }
            PostgresPool.executeTask(hashMap.values(), partitionOffsetDataList);
        } else {
            commit();
        }
    }

    private void commit() {
        for (PartitionOffsetData partitionOffsetData : partitionOffsetDataList) {
            partitionOffsetData.commited = 1;
        }
    }

    private void rollback() {
        for (PartitionOffsetData partitionOffsetData : partitionOffsetDataList) {
            partitionOffsetData.commited = -1;
            MasterConsumerThread.commitInterval = 1000;
        }
    }

}
