package com.kafka.consumer;

import com.App;
import com.models.PartitionOffsetData;
import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.common.TopicPartition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.stream.Collectors;

public class ConsumerGroup {

    public static Logger logger = LoggerFactory.getLogger(ConsumerGroup.class);

    public static Thread thread = null;
    private static ConcurrentHashMap<Integer, ConcurrentLinkedQueue<PartitionOffsetData>> offsetMap = new ConcurrentHashMap<>();
    private static KafkaConsumer<String, byte[]> consumer;

    public static long getOffsetEnd(int partition) {
        try {
            return Math.max(consumer.position(new TopicPartition(App.topic, partition)), 0);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public static PartitionOffsetData putInHashMap(int partition, long start) {
        ConcurrentLinkedQueue<PartitionOffsetData> list;
        PartitionOffsetData partitionOffsetData = new PartitionOffsetData(partition, start, getOffsetEnd(partition));
        if ((list = offsetMap.get(partition)) != null) {
            list.add(partitionOffsetData);
        } else {
            list = new ConcurrentLinkedQueue<>();
            list.add(partitionOffsetData);
            offsetMap.put(partition, list);
        }
        return partitionOffsetData;
    }

    public static void rollBack(int partition, long offset) {
        try {
            logger.warn("Rolling back partition: " + partition + " to offset " + offset);
            consumer.seek(new TopicPartition(App.topic, partition), offset);
        } catch (Exception e) {
            logger.error("Error", e);
        }
    }

    public static void handleOffsets(long currentTimestamp) {
        Map<TopicPartition, OffsetAndMetadata> commits = new HashMap<>();
        for (Map.Entry<Integer, ConcurrentLinkedQueue<PartitionOffsetData>> entry : offsetMap.entrySet()) {
            logger.info("Partition : " + entry.getKey() + " List : " + Arrays.toString(entry.getValue().toArray()));
            if (entry.getValue().size() > 0) {
                ConcurrentLinkedQueue<PartitionOffsetData> list = entry.getValue().stream().
                        sorted(Comparator.comparingLong(o -> o.start))
                        .collect(Collectors.toCollection(ConcurrentLinkedQueue::new));
                PartitionOffsetData last = null;
                boolean shouldBreak = false;
                for (PartitionOffsetData item : list) {
                    switch (item.commited) {
                        case 0:
                            if (currentTimestamp - item.started > 60000) {
                                item.commited = -1;
                                rollBack(item.id, item.start);
                                list.clear();
                            }
                            shouldBreak = true;
                            break;
                        case 1:
                            last = item;
                            list.remove(item);
                            break;
                        case -1:
                            rollBack(item.id, item.start);
                            list.clear();
                            shouldBreak = true;
                            break;
                    }
                    if (shouldBreak) {
                        break;
                    }
                }
                if (last != null) {
                    commits.put(new TopicPartition(App.topic, last.id), new OffsetAndMetadata(last.end));
                    logger.info("Queuing partition " + last.id + " to commit offset " + last.end);
                }
                entry.setValue(list);
            } else {
                offsetMap.remove(entry.getKey());
            }
            if (commits.size() > 0) {
                consumer.commitAsync(commits, null);
                logger.info("Committing " + commits.size() + " offsets");
            }
        }
    }

    public static ConsumerRecords<String, byte[]> pollRecords() {
        return consumer.poll(Duration.ofSeconds(10));
    }

    public void init() throws Exception {
        String finalString = "com.sun.security.auth.module.Krb5LoginModule required useKeyTab=true storeKey=true keyTab=\""
                + App.finalPath + "\" principal=\"" + App.principal + "\";";
        System.setProperty("java.security.krb5.conf", App.krb5Path);
        Properties props = new Properties();
        props.put("bootstrap.servers", "cilhdkfs0301.sys.cigna.com:9095,cilhdkfs0302.sys.cigna.com:9095");
//        props.put("bootstrap.servers", "cilhdkfd0304.sys.cigna.com:9095");
        props.put("security.protocol", "SASL_SSL");
        props.put("sasl.mechanism", "GSSAPI");
        props.put("sasl.kerberos.service.name", "kafka");
        props.put("sasl.jaas.config", finalString);
        props.put("ssl.truststore.location", App.jksPath);
        props.put("ssl.truststore.password", "password");
        props.put("ssl.truststore.type", "JKS");
        props.put("group.id", App.consumerGroupId);
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);

        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        props.put(ConsumerConfig.FETCH_MAX_BYTES_CONFIG, 2048576);
        props.put(ConsumerConfig.MAX_PARTITION_FETCH_BYTES_CONFIG, 2048576);
        props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, 3000);
//        props.put("max.poll.interval.ms", 10000);

//        props.put(ConsumerConfig.RECONNECT_BACKOFF_MS_CONFIG, 10000);
//        props.put(ConsumerConfig.DEFAULT_API_TIMEOUT_MS_CONFIG, 300);
//        props.put(ConsumerConfig.RETRY_BACKOFF_MS_CONFIG, 10000);

        props.put("key.deserializer",
                "org.apache.kafka.common.serialization.StringDeserializer");
        props.put("value.deserializer",
                "org.apache.kafka.common.serialization.ByteArrayDeserializer");

        consumer = new KafkaConsumer<>(props);
//        consumer.subscribe(Arrays.asList(App.topic), new HandleRebalance());
        consumer.subscribe(Arrays.asList(App.topic));
        thread = new MasterConsumerThread();
        thread.setPriority(8);
        thread.start();
    }

    private class HandleRebalance implements ConsumerRebalanceListener {
        public void onPartitionsAssigned(Collection<TopicPartition> partitions) {
//            System.out.println(partitions.size());
            // Implement what you want to do once rebalancing is done.
        }

        public void onPartitionsRevoked(Collection<TopicPartition> partitions) {
//            System.out.println(partitions.size());

            // commit current method

        }
    }

}