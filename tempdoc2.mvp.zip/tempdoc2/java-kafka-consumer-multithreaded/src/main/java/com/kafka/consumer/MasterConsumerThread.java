package com.kafka.consumer;

import com.App;
import com.models.PartitionOffsetData;
import com.models.STATE;
import com.output.PostgresPool;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;

import static com.models.Status.mainStatus;

public class MasterConsumerThread extends Thread {
    public static Logger logger = LoggerFactory.getLogger(MasterConsumerThread.class);

    public static ExecutorService executor = Executors.newFixedThreadPool(App.connections);

    public static LinkedBlockingQueue linkedBlockingQueue = new LinkedBlockingQueue<Runnable>();
    public static ThreadPoolExecutor pool = (ThreadPoolExecutor) Executors.newFixedThreadPool(App.connections * 2);
    public static long lastRan = 0;
    public static long commitInterval = App.commitInterval;
    private static int maxQue = App.connections * 3;

    public static void executeTask(List<byte[]> task, List<PartitionOffsetData> partitionOffsetData) {
//        linkedBlockingQueue.add(new TaskThread(task, partitionOffsetData));
        pool.execute(new TaskThread(task, partitionOffsetData));
    }

    @Override
    public void run() {
        new Thread() {
            @Override
            public void run() {
                this.setPriority(7);

                while (true) {
                    int size = pool.getQueue().size();
                    if (linkedBlockingQueue.size() > 0 && size < maxQue) {
                        int canTake = maxQue - size;
                        for (int i = 0; i < canTake; i++) {
                            if (linkedBlockingQueue.size() > 0) {
                                try {
                                    pool.execute((Runnable) linkedBlockingQueue.take());
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                            } else {
                                break;
                            }
                        }
                    }
                    try {
                        this.sleep(5);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

            }
        };

        mainStatus.setStart(System.currentTimeMillis());

        while (true) {

//            if (linkedBlockingQueue.size() < maxQue && PostgresPool.pool.getQueue().size() < maxQue) {
            if (pool.getQueue().size() < maxQue && PostgresPool.pool.getQueue().size() < maxQue) {

                try {

                    if (System.currentTimeMillis() - lastRan > commitInterval) {
                        if (commitInterval < App.commitInterval) {
                            commitInterval = App.commitInterval;
                        }
                        lastRan = System.currentTimeMillis();
                        ConsumerGroup.handleOffsets(lastRan);
                    }

                    final ConsumerRecords<String, byte[]> consumerRecords = ConsumerGroup.pollRecords();

                    if (consumerRecords.count() == 0) {
                        mainStatus.setState(STATE.WAITING_FOR_MESSAGES);
                        try {
                            Thread.sleep(10000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        continue;
                    } else {
                        mainStatus.setState(STATE.PROCESSING);
                    }


                    int currentPartitionId = -1;

                    ArrayList<PartitionOffsetData> list = new ArrayList<>();

                    List<byte[]> bytes = new ArrayList<>();
                    Iterator<ConsumerRecord<String, byte[]>> iterable = consumerRecords.iterator();
                    while (iterable.hasNext()) {
                        ConsumerRecord<String, byte[]> record = iterable.next();
                        if (currentPartitionId != record.partition()) {
                            currentPartitionId = record.partition();
                            list.add(ConsumerGroup.putInHashMap(currentPartitionId, record.offset()));
                        }
                        bytes.add(record.value());
                    }

                    mainStatus.addReadMessages(bytes.size());

                    executeTask(bytes, list);

                } catch (Exception e) {
                    logger.error("Error", e);
                    try {
                        this.sleep(30000);
                    } catch (InterruptedException ee) {
                        logger.error("Error", ee);
                    }
                }

            } else {
                try {
                    this.sleep(20);
                } catch (InterruptedException e) {
                    logger.error("Error", e);
                }
            }
        }

    }

}
