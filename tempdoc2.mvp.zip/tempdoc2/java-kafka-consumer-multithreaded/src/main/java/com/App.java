package com;

import ch.qos.logback.classic.Level;
import com.kafka.consumer.ConsumerGroup;
import com.models.LogInterceptor;
import com.models.Status;
import com.output.PostGres;
import com.output.PostgresPool;
import org.apache.avro.Schema;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.UUID;

public class App {

    public static Logger logger = LoggerFactory.getLogger(App.class);

    public static int connections = 10;

    //Kafka SASL
    public static String krb5Path = "conf/krb5.conf";
    public static String finalPath = "secrets/rtdesvc.keytab";
    public static String jksPath = "secrets/Cigna.jks";
    public static String principal = "rtdesvc@SILVER.COM";
    public static ch.qos.logback.classic.Logger root = (ch.qos.logback.classic.Logger) LoggerFactory.getLogger(Logger.ROOT_LOGGER_NAME);

    //Kafka
    public static String topic = "CisIdentityFeedINT";
    //    public static String topic = "CisIdentityFeedINT";
    public static String consumerGroupId = "java-icollab_identity-consumer-" + UUID.randomUUID().toString();
    //        public static String consumerGroupId = "java-icollab_identity-consumer-002";
    public static String avscFile = "/avro.avsc";


    public static long commitInterval = 23000;

    public static Schema schema;

    public static void setLoggingLevel(Level level) {
        root.setLevel(level);
    }

    public static void main(String[] args) {
        LogInterceptor logInterceptor = new LogInterceptor();
        logInterceptor.start();
        root.addAppender(logInterceptor);
        setLoggingLevel(Level.WARN);
        try {
            HealthCheck.startHealthCheck();
            schema = new Schema.Parser().parse(new App().getClass().getResourceAsStream(avscFile));
            PostgresPool.init();
            PostGres.init();
            new ConsumerGroup().init();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            logger.error("Error", e);
            Status.response = 404;
        }
    }

}
