package com.models;

import com.App;
import org.apache.avro.generic.GenericRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Date;

public class Identity {
    public static Logger logger = LoggerFactory.getLogger(Identity.class);

    public String iborId = null;
    public String gender = null;
    public Date dob = null;
    public String firstName = null;
    public String lastName = null;

    public Identity(GenericRecord genericRecord) {
        try {
            this.iborId = getString("enterpriseId", genericRecord);
            this.gender = getString("gender", genericRecord).equalsIgnoreCase("female") ? "F" : "M";
            this.firstName = getString("first", genericRecord.get("name"));
            this.lastName = getString("last", genericRecord.get("name"));
            int d = getInt("birthDate", genericRecord);
            this.dob = new Date(d * (60 * 60 * 24 * 1000));
        } catch (Exception e) {
            logger.warn("Warning", e);
        }
    }

    public static String getString(String name, Object genericRecord) {
        if (genericRecord != null) {
            try {
                GenericRecord o = (GenericRecord) genericRecord;
                return o.get(name).toString().trim();
            } catch (Exception e) {
                logger.warn("Warning", e);
            }
        }
        return "NULL";
    }

    public static int getInt(String name, Object genericRecord) {
        if (genericRecord != null) {
            try {
                GenericRecord o = (GenericRecord) genericRecord;
                return (int) o.get(name);
            } catch (Exception e) {
                logger.warn("Warning", e);
            }
        }
        return 0;
    }

    @Override
    public String toString() {
        return "Identity{" +
                "iborId='" + iborId + '\'' +
                ", gender='" + gender + '\'' +
                ", dob='" + dob + '\'' +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                '}';
    }
}
