package com.models;

public enum STATE {
    WAITING_FOR_MESSAGES,
    PROCESSING,
    UNDEFINED,
}