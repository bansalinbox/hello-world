package com.models;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.AppenderBase;

import static ch.qos.logback.classic.Level.ERROR_INT;
import static ch.qos.logback.classic.Level.WARN_INT;

public class LogInterceptor extends AppenderBase<ILoggingEvent> {

    @Override
    protected void append(ILoggingEvent e) {
        switch (e.getLevel().levelInt) {
            case WARN_INT:
                if (e.getLoggerName().equalsIgnoreCase("org.apache.kafka.clients.NetworkClient") && e.getMessage().contains("UNKNOWN_TOPIC_OR_PARTITION")) {
                    Status.response = 404;
                }
                break;
            case ERROR_INT:
                break;
        }
    }
}