package com.models;

import com.App;
import com.kafka.consumer.MasterConsumerThread;
import com.output.PostgresPool;
import com.sun.management.OperatingSystemMXBean;

import java.lang.management.ManagementFactory;

public class Status {

    public static Status mainStatus = new Status();
    public static int response = 200;

    public long readMessages = 0;
    public long skippedMessages = 0;
    public long postedMessages = 0;
    public STATE state = STATE.UNDEFINED;
    public long fails = 0;
    private long start = System.currentTimeMillis();
    private long runeTime = 0;

    public Status() {
    }

    public static String humanReadableByteCount(long bytes, boolean si) {
        int unit = si ? 1000 : 1024;
        if (bytes < unit) return bytes + " B";
        int exp = (int) (Math.log(bytes) / Math.log(unit));
        String pre = (si ? "kMGTPE" : "KMGTPE").charAt(exp - 1) + (si ? "" : "i");
        return String.format("%.1f %sB", bytes / Math.pow(unit, exp), pre);
    }

    public String getLogLevel() {
        return App.root.getLevel().levelStr;
    }

    public long getRuneTime() {
        this.runeTime = (System.currentTimeMillis() - this.start);
        return runeTime;
    }

    public void setStart(long start) {
        this.start = start;
    }

    public String getMaxMemory() {
        return humanReadableByteCount(Runtime.getRuntime().maxMemory(), true);
    }

    public String getFreeMemory() {
        return humanReadableByteCount(Runtime.getRuntime().freeMemory(), true);
    }

    public String getTotalMemory() {
        return humanReadableByteCount(Runtime.getRuntime().totalMemory(), true);
    }

    public long getReadsPerSec() {
        if (readMessages == 0) return 0;
        return this.readMessages / (this.runeTime / 1000);
    }

    public long getPostsPerSec() {
        if (postedMessages == 0) return 0;
        return this.postedMessages / (this.runeTime / 1000);
    }

    public int getReaderActive() {
        return MasterConsumerThread.pool.getActiveCount();
    }

    public int getReaderQue() {
        return MasterConsumerThread.pool.getQueue().size();
    }

    public int getPostgresActive() {
        return PostgresPool.pool.getActiveCount();
    }

    public int getPostgresQue() {
        return PostgresPool.pool.getQueue().size();
    }

    public String getCpu() {
        OperatingSystemMXBean operatingSystemMXBean = (OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean();
        String s = "Process CPU: " + operatingSystemMXBean.getProcessCpuLoad() + " : " +
                "System CPU: " + operatingSystemMXBean.getSystemCpuLoad();
        return s;
    }

    public STATE getState() {
        return state;
    }

    public void setState(STATE state) {
        if (this.state != state) {
            this.state = state;
        }
    }

    public synchronized void addReadMessages(long count) {
        this.readMessages += count;
    }

    public synchronized void addSkippedMessages(long count) {
        this.skippedMessages += count;
    }

    public synchronized void addPostedMessages(long count) {
        this.postedMessages += count;
    }

    public long getReadMessages() {
        return readMessages;
    }

    public void setReadMessages(long readMessages) {
        this.readMessages = readMessages;
    }

    public long getSkippedMessages() {
        return skippedMessages;
    }

    public void setSkippedMessages(long skippedMessages) {
        this.skippedMessages = skippedMessages;
    }

    public long getPostedMessages() {
        return postedMessages;
    }

    public void setPostedMessages(long postedMessages) {
        this.postedMessages = postedMessages;
    }
}
