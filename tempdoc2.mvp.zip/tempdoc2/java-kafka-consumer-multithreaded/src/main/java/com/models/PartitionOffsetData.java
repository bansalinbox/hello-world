package com.models;

public class PartitionOffsetData {

    public int id;
    public long start;
    public long end;
    public int commited = 0;
    public long started = System.currentTimeMillis();

    public PartitionOffsetData(int id, long start, long end) {
        this.id = id;
        this.start = start;
        this.end = end;
    }

    @Override
    public String toString() {
        return "PartitionOffsetData{" +
                "id=" + id +
                ", start=" + start +
                ", end=" + end +
                ", commited=" + commited +
                ", started=" + started +
                '}';
    }
}
