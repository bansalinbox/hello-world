package com.models;

public class Gap {
    public String iborId;
    public String gapId;
    public String gapCase;
    public String gapType;
    public String firstIdentifiedDate;
    public String condition;
    public String description;
    public String loadDate;
    public int score;
    public String ndcId;
    public String ndcLabel;
    public String inactive;
    public int offset;
    public int partition;
    public String topic;

    public Gap() {
    }

    @Override
    public String toString() {
        return "Gap{" +
                "iborId='" + iborId + '\'' +
                ", gapId='" + gapId + '\'' +
                ", gapCase='" + gapCase + '\'' +
                ", gapType='" + gapType + '\'' +
                ", firstIdentifiedDate='" + firstIdentifiedDate + '\'' +
                ", condition='" + condition + '\'' +
                ", description='" + description + '\'' +
                ", loadDate='" + loadDate + '\'' +
                ", score=" + score +
                ", ndcId='" + ndcId + '\'' +
                ", ndcLabel='" + ndcLabel + '\'' +
                ", inactive='" + inactive + '\'' +
                ", offset=" + offset +
                ", partition=" + partition +
                ", topic='" + topic + '\'' +
                '}';
    }
}