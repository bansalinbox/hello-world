# The Cigna Dragon (FHIR) API

HL7 FHIR is a standard for healthcare data exchange. The Dragon API (Get it? Dragons spit fire. Fire sounds like FHIR. Don't worry, the FHIR puns only get worse) is a project created by CIS to initially support data exchange with third parties and EHR systems in a standards compliant manner.  However, the broader goal is to provide an industry standard API that can be leveraged at Cigna as we work with external partners. The documentation here explains the various components of the Dragon API and how it can be extended and reused. 

The git repo to this project is at [dragon-api](http://git.sys.cigna.com/cis-fhir-exchange/dragon-api)
The test automation project is at [CMTTestAutomation](http://git.sys.cigna.com/AWSTestAutomation/cmttestautomation)

## Hosted in AWS

At a high level, this API exists almost completely in AWS. This was done for a number of reasons:

1. AWS abstracts A LOT of what one needs to know about the underlying hardware (and in some cases software) for a particular solution. This gives the team the ability to focus more effort on business value rather than underlying infrastructure configuration and setup
2. AWS provides a number of capabilities related to scaling solutions. This gives Cigna the ability to better respond to flucuations in volume. 
3. AWS latency between different services can create a highly responsive low-latency solution. This solution leverages data about customers that can have a potentially positive impact. That impact is diminished when the data is not delivered as close to real-time as possible. The low latency capabilities of AWS give Cigna the ability to better achieve a near real-time architecture. 

## AWS Components Used 

* Cloudfront (via the HeavenGate project)
* API Gateway (via the HeavenGate project)
* Simple Queue Service (SQS)
* SNS
* DynamoDB
* Lambda
* VPC Endpoints
* Route 53
* Cognito

## Enabling Components
To enable Eligibility S3 bucket for cmt set  ENABLE_CMT_ELIGIBILITY_MODULE: "true" in gitlab ci or in Run CI dialog
in gitlab page. (Anyway when time come to enable it that flag can be deleted)
