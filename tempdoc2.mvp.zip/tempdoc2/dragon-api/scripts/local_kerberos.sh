#!/bin/bash

KRB_PRINCIPAL="SVT_FHIR_BIGDATA"
KRB_REALM="SILVER.COM"
KRB_PASS="PASSWORD"
printf "%b" "addent -password -p ${KRB_PRINCIPAL}@${KRB_REALM} -k 1 -e aes256-cts-hmac-sha1-96\n${KRB_PASS}\nwrite_kt ${KRB_PRINCIPAL}.keytab" | ktutil
printf "%b" "read_kt ${KRB_PRINCIPAL}.keytab\nlist" | ktutil
