echo ASSUMING ROLE ${RAAS_ROLE} IN ACCOUNT NUMBER ${AWS_ACCOUNT}
  aws sts assume-role \
    --role-arn arn:aws:iam::${AWS_ACCOUNT}:role/Enterprise/${RAAS_ROLE}\
    --role-session-name "${ROLE_SESSION_NAME}" > data.json
export AWS_ACCESS_KEY_ID="`cat data.json | jq ".Credentials.AccessKeyId" -r`"
export AWS_SECRET_ACCESS_KEY="`cat data.json | jq ".Credentials.SecretAccessKey" -r`"
export AWS_SESSION_TOKEN="`cat data.json | jq ".Credentials.SessionToken" -r`"
