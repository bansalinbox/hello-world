AWS_REGION="us-east-1"
aws s3 rm s3://fhir-reporting-encounter-${STAGE_NAME} --recursive --region ${AWS_REGION}  || true
