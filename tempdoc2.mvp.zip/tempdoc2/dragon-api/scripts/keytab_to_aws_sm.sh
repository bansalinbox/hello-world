#!/bin/bash

KEYTAB_SECRET=$(aws secretsmanager list-secrets | jq --arg KEYTAB_SECRET_NAME ${KEYTAB_SECRET_NAME} '.SecretList[] | select(.Name==$KEYTAB_SECRET_NAME)')
if [[ "${KEYTAB_SECRET}" == "" ]]; then
  echo "Secret ${KEYTAB_SECRET_NAME} not found, creating..."
  aws secretsmanager create-secret --name ${KEYTAB_SECRET_NAME} --secret-string "$(base64 -w 0 "${KRB_PRINCIPAL}.keytab")" --kms-key-id "alias/fhir-exchange-${ENV_COMPUTED_NAME}"
else
  echo "Secret ${KEYTAB_SECRET_NAME} exists, updating..."
  aws secretsmanager update-secret --secret-id ${KEYTAB_SECRET_NAME} --secret-string "$(base64 -w 0 "${KRB_PRINCIPAL}.keytab")" --kms-key-id "alias/fhir-exchange-${ENV_COMPUTED_NAME}"
fi


