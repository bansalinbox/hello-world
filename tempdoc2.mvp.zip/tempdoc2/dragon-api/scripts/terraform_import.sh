#!/bin/bash

if [[ "${STAGE_NAME}" =~ ^sys$|^sit$|^pvs$|^prod$ ]] && [[ "${COGNITO_ID}" == "" ]]; then
  echo "Adding Cognito to state file";
  terraform import module.cognito.aws_cognito_user_pool.pool "${COGNITO_USER_POOL_ID}" || true;
  terraform import module.cognito.aws_cognito_user_pool_domain.domain cigna-fhir-exchange-${STAGE_NAME} || true;
  terraform import module.cognito.aws_cognito_resource_server.server  "${COGNITO_USER_POOL_ID}|encounter" || true;
  terraform import module.cognito.aws_cognito_user_pool_client.client "${COGNITO_USER_POOL_ID}/${COGNITO_CLIENT_ID}" || true;
  terraform refresh -target=module.cognito \
    -var data_to_kafka_image_name=${APP_DATA_TO_KAFKA_IMAGE_NAME} \
    -var keytab_secret_name=${KEYTAB_SECRET_NAME} \
    -var enable_cloudwatch_alarms=${ENABLE_CLOUDWATCH_ALERTS} \
    -var enable_cmt_eligibility_module=${ENABLE_CMT_ELIGIBILITY_MODULE} \
    -var stage=${STAGE_NAME} \
    -var env=${ENV_COMPUTED_NAME} \
    -var-file=../terraform-env-config/${CONFIG_NAME}.tfvars \
    -var-file=../terraform-env-config/${CONFIG_NAME}-shared.tfvars \
    -var data_to_kafka_jks_password=${JKS_PASSWORD} \
    -var fhir_ingress_sns_name=${FHIR_INGRESS_SNS_NAME};
fi;
