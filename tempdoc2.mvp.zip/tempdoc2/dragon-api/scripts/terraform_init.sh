#!/bin/bash

terraform init -get-plugins=false \
  -backend-config="bucket=${DEPLOYMENT_BUCKET_NAME}" \
  -backend-config="key=${S3_KEY_NAME}" \
  -backend-config="role_arn=${DEPLOYMENT_ROLE}" \
  -backend-config="region=${AWS_REGION}" \
  -backend-config="encrypt=true";
