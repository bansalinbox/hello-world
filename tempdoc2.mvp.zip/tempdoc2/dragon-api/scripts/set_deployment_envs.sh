#!/bin/bash

# Set DEFAULT vars for variables.
ENV_COMPUTED_NAME=$(echo "$CI_COMMIT_MESSAGE" | sed -n 's/.*\[deploy-\([^]]*\)\].*/\1/p')
CONFIG_NAME_DEFAULT=$(echo "$CI_COMMIT_MESSAGE" | sed -n 's/.*\[deploy-\([^]]*\)\].*/\1/p')

ENABLE_CLOUDWATCH_ALERTS="false"
if [[ ${CI_COMMIT_REF_NAME} =~ ^sys$|^sit$|^pvs$|^main$ ]]
then
  ENABLE_CLOUDWATCH_ALERTS="true"
fi
KRB_PRINCIPAL="${KRB_PRINCIPAL_NP}"
KRB_PASS="${KRB_PASS_NP}"
KRB_REALM="${KRB_REALM_NP}"
JKS_PASSWORD="changeit"
if [[ ${CI_COMMIT_REF_NAME} =~ ^sys$|^sit$|^pvs$ ]]
then
  echo "Setting ENV_COMPUTED_NAME from Branch name"
  ENV_COMPUTED_NAME="${CI_COMMIT_REF_NAME}"
  CONFIG_NAME_DEFAULT="${CI_COMMIT_REF_NAME}"
elif [[ "${CI_COMMIT_REF_NAME}" =~ "main" ]]
then
  echo "Setting ENV_COMPUTED_NAME from Branch name"
  ENV_COMPUTED_NAME="prod"
  CONFIG_NAME_DEFAULT="prod"
  KRB_PRINCIPAL="${KRB_PRINCIPAL_P}"
  KRB_PASS="${KRB_PASS_P}"
  KRB_REALM="${KRB_REALM_P}"
elif [[ ${CI_COMMIT_REF_NAME} == *"release"* ]]
then
  echo "Setting ENV_COMPUTED_NAME from Branch name"
  ENV_COMPUTED_NAME="prod"
  CONFIG_NAME_DEFAULT="prod"
  KRB_PRINCIPAL="${KRB_PRINCIPAL_P}"
  KRB_PASS="${KRB_PASS_P}"
  KRB_REALM="${KRB_REALM_P}"
fi


if [[ ${CI_COMMIT_MESSAGE} == *"[stage-"* ]]
then
  export STAGE_NAME=$(echo "$CI_COMMIT_MESSAGE" | sed -n 's/.*\[stage-\([^]]*\)\].*/\1/p')
fi

if [[ ${CI_COMMIT_MESSAGE} == *"[config-"* ]]
then
  export CONFIG_NAME=$(echo "$CI_COMMIT_MESSAGE" | sed -n 's/.*\[config-\([^]]*\)\].*/\1/p')
fi

echo "SHOW DEFAULT VARS"
echo "DEFAULT VALUE of ENV_COMPUTED_NAME is ${ENV_COMPUTED_NAME}"
echo "DEFAULT VALUE of CONFIG_NAME_DEFAULT is ${CONFIG_NAME_DEFAULT}"
echo "DEFAULT VALUE of ENABLE_CMT_ELIGIBILITY_MODULE is ${ENABLE_CMT_ELIGIBILITY_MODULE}"
echo "DEFAULT VALUE of APP_DATA_TO_KAFKA_IMAGE_NAME is ${APP_DATA_TO_KAFKA_IMAGE_NAME}"
echo "*****************************************************"
echo "ENV VALUE of STAGE_NAME is ${STAGE_NAME}"
echo "ENV VALUE of CONFIG_NAME is ${CONFIG_NAME}"
echo "*****************************************************"
export STAGE_NAME=${STAGE_NAME:-${ENV_COMPUTED_NAME}}
CONFIG_NAME=${CONFIG_NAME:-${CONFIG_NAME_DEFAULT}}
DEPLOYMENT_BUCKET_NAME="fhir-exchange-deployment-pipeline-bucket-${STAGE_NAME}"
FHIR_INGRESS_SNS_NAME="fhir-exchange-ingress-sns-${STAGE_NAME}"
FHARGATE_DATA_TO_KAFKA_REPO=".dkr.ecr.us-east-1.amazonaws.com"
KEYTAB_SECRET_NAME="fhir-data-to-kafka-keytab-${STAGE_NAME}"
export APP_DATA_TO_KAFKA_IMAGE_NAME="fhir-dragon-api-${ENV_COMPUTED_NAME}"
echo "SET STAGE_NAME to ${STAGE_NAME}"
echo "SET CONFIG_NAME to ${CONFIG_NAME}"
echo "*****************************************************"
echo "SET FHIR_INGRESS_SNS_NAME to ${FHIR_INGRESS_SNS_NAME}"
echo "SET DEPLOYMENT_BUCKET_NAME to ${DEPLOYMENT_BUCKET_NAME}"
echo "SET APP_DATA_TO_KAFKA_IMAGE_NAME to ${APP_DATA_TO_KAFKA_IMAGE_NAME}"
echo "*****************************************************"
echo "ENABLE_CLOUDWATCH_ALERTS=${ENABLE_CLOUDWATCH_ALERTS}"
