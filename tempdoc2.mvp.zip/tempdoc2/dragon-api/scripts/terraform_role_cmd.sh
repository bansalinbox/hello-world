#!/bin/bash

terraform version;
terraform ${TERRAFORM_COMMAND} \
  -var stage=${STAGE_NAME} \
  -var-file=../terraform-env-config/${CONFIG_NAME}-shared.tfvars \
  -var fhir_ingress_sns_name=${FHIR_INGRESS_SNS_NAME}
