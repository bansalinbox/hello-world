#!/bin/bash

CERTS_URL="https://git.sys.cigna.com/CIP/certfix/raw/master/"
CERTS=("CignaB1IssuingCA01" "CignaB1IssuingCA02" "CignaB1IssuingCA03" "CignaB1IssuingCA04" "CignaB1PolicyCA" "CignaB1RootCA" "CignaA1IssuingCA01" "CignaA1IssuingCA02" "CignaA1IssuingCA03" "CignaA1IssuingCA04" "CignaA1PolicyCA" "CignaA1RootCA" "CignaRootTestCA" "CignaIssuingCA" "CignaRootCA" "intl" "CignaProdWebGatewayCA")
DST_FILE="cigna-certs"

for CERT in ${CERTS[*]};
do
  curl -sO "${CERTS_URL}${CERT}.pem";
  keytool -importcert -noprompt -file "${CERT}.pem" -keystore "${DST_FILE}.jks" -alias "${CERT}" -storepass ${JKS_PASSWORD}
  rm -f "${CERT}.pem"
done
