#!/bin/bash
AWS_REGION="us-east-1"
echo "KEYTAB_SECRET_NAME=${KEYTAB_SECRET_NAME}"
#aws secretsmanager list-secrets --region ${AWS_REGION}
#KEYTAB_SECRET=$(aws secretsmanager list-secrets --region ${AWS_REGION} | jq --arg KEYTAB_SECRET_NAME ${KEYTAB_SECRET_NAME}  '.SecretList[] | select(.Name==$KEYTAB_SECRET_NAME)')
#echo "KEYTAB_SECRET=${KEYTAB_SECRET}"
aws secretsmanager delete-secret --secret-id ${KEYTAB_SECRET_NAME} --region ${AWS_REGION} || true


