#!/bin/bash

cd ./s3/deploymentBucket;
echo "${DEPLOYMENT_BUCKET_NAME}";
s3error=$((aws s3api head-bucket --bucket "${DEPLOYMENT_BUCKET_NAME}" || true) 2>&1)
if [[ "${s3error}" == "" ]]; then
  echo "S3 bucket ${DEPLOYMENT_BUCKET_NAME} exist and proper access configured!";
elif [[ "$(echo "${s3error}" | grep '(404)')" == "" ]]; then
  echo "ERROR - ${s3error}"; exit 1;
else
  echo "INFO - S3 bucket ${DEPLOYMENT_BUCKET_NAME} does not exits and will be created!";
  aws s3api create-bucket --bucket "${DEPLOYMENT_BUCKET_NAME}" --acl private --region "${AWS_REGION}";
  sleep 5s;
fi;
aws s3api put-bucket-encryption --bucket "${DEPLOYMENT_BUCKET_NAME}" --cli-input-json file://s3-encryption.json;
aws s3api put-bucket-tagging --bucket "${DEPLOYMENT_BUCKET_NAME}" --cli-input-json file://tag-set.json;
if [[ "${ENV_COMPUTED_NAME}" != "sys" ]]; then
  aws s3api put-bucket-policy --bucket "${DEPLOYMENT_BUCKET_NAME}" --policy "{\"Version\":\"2012-10-17\",\"Statement\":[{\"Sid\":\"crossRoleAccess${STAGE_NAME}1\",\"Effect\":\"Allow\",\"Principal\":{\"AWS\":\"arn:aws:iam::${AWS_CROSS_ACCOUNT}:role/Enterprise/FhirCrossAccountDeploy\"},\"Action\":[\"s3:ListBucketByTags\",\"s3:ListBucketVersions\",\"s3:ListBucket\",\"s3:GetEncryptionConfiguration\",\"s3:GetBucketPolicyStatus\",\"s3:GetBucketTagging\",\"s3:GetBucketLocation\",\"s3:GetBucketPolicy\",\"s3:PutBucketTagging\",\"s3:PutEncryptionConfiguration\",\"s3:PutBucketPolicy\"],\"Resource\":[\"arn:aws:s3:::${DEPLOYMENT_BUCKET_NAME}\"]},{\"Sid\":\"crossRoleAccess${STAGE_NAME}2\",\"Effect\":\"Allow\",\"Principal\":{\"AWS\":\"arn:aws:iam::${AWS_CROSS_ACCOUNT}:role/Enterprise/FhirCrossAccountDeploy\"},\"Action\":[\"s3:PutObjectTagging\",\"s3:GetObjectTagging\",\"s3:PutObject\",\"s3:GetObject\",\"s3:DeleteObjectTagging\",\"s3:DeleteObject\"],\"Resource\":[\"arn:aws:s3:::${DEPLOYMENT_BUCKET_NAME}/*\"]}]}";
fi;
