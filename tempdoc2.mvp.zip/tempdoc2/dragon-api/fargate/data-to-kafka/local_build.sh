#!/usr/bin/env sh

ENV_COMPUTED_NAME="sys"
APP_DATA_TO_KAFKA_IMAGE_NAME="fhir-dragon-api-sys"
STAGE_NAME="localbuild"
AWS_ACCOUNT="003856232118"
AWS_REGION="us-east-1"

. ../../../scripts/create_cigna_certs_jks.sh

mkdir -p src/main/resources/com/cigna/fhir
mv cigna-certs.jks src/main/resources/com/cigna/fhir/cigna-certs.jks

mvn package

. build.sh

DOCKER_REPO="${AWS_ACCOUNT}.dkr.ecr.${AWS_REGION}.amazonaws.com/${APP_DATA_TO_KAFKA_IMAGE_NAME}:${STAGE_NAME}-latest"
docker tag ${APP_DATA_TO_KAFKA_IMAGE_NAME}:${STAGE_NAME}-latest ${DOCKER_REPO}
$(aws ecr get-login --region ${AWS_REGION} --no-include-email)
docker push ${DOCKER_REPO}
