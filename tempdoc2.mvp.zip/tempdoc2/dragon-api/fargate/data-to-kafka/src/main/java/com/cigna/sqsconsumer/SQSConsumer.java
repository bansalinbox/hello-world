package com.cigna.sqsconsumer;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;
import com.amazonaws.services.sqs.model.*;
import com.cigna.cis.dragonops.fhir.cmt.encounter.v1_2.CMTEncounter;
import com.cigna.exception.EnvironmentVariableException;
import com.cigna.exception.FHIRServiceException;
import com.cigna.fhir.service.KafkaProducerService;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.quartz.*;

import java.io.FileWriter;
import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import com.cigna.fhir.ProducerUtil;

@DisallowConcurrentExecution
public class SQSConsumer implements Job {

    KafkaProducerService kafkaProducerService = null;

    static final Logger logger = LogManager.getLogger(SQSConsumer.class);

    @Override
    public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
        try {
            boolean isLastCallReturnMessages;
            do {
                healthCheck();
                logger.trace("Processing Job " + jobExecutionContext.getFireInstanceId());
                Instant startTime = Instant.now();
                isLastCallReturnMessages = consumeLogic(jobExecutionContext.getFireInstanceId());
                long delta = Duration.between(startTime, Instant.now()).toMillis();
                logger.trace("Processed Job" + " in  " + delta + " milliseconds, Id: " + jobExecutionContext.getFireInstanceId());
            } while (isLastCallReturnMessages);
        } catch (Exception ex) {
            logger.fatal(ex);
            Runtime.getRuntime().exit(1);
        } finally {
            if (this.kafkaProducerService != null) {
                this.kafkaProducerService.closeProducer();
            }
        }
    }

    private void healthCheck() throws IOException {
        FileWriter myWriter = new FileWriter(Main.healthCheckFileName, false);
        myWriter.write(Instant.now().toString());
        myWriter.close();
    }


    public boolean consumeLogic(String processId) throws JobExecutionException, EnvironmentVariableException, FHIRServiceException {
        final String queueName = ProducerUtil.getRequiredEnv("QUEUE_NAME");

        AmazonSQS sqs = null;
        if (ProducerUtil.getLocalAWScreds()) {
            logger.trace("Searching for SAML creds");
            ProfileCredentialsProvider profileCredentialsProvider = new ProfileCredentialsProvider("saml");
            sqs = AmazonSQSClientBuilder.standard()
                    .withRegion("us-east-1")
                    .withCredentials(profileCredentialsProvider)
                    .build();
        } else {
            logger.trace("Obtaining default creds");
            sqs = AmazonSQSClientBuilder.defaultClient();
        }

        ReceiveMessageResult message;
        String queueUrl;

        try {
            queueUrl = sqs.getQueueUrl(queueName).getQueueUrl();
            final ReceiveMessageRequest receive_request = new ReceiveMessageRequest()
                    .withQueueUrl(queueUrl)
                    .withMaxNumberOfMessages(Integer.parseInt(ProducerUtil.getRequiredEnv("SQS_MAX_NUMBER_OF_MESSAGES")))
                    .withVisibilityTimeout(Integer.parseInt(ProducerUtil.getRequiredEnv("SQS_VISIBILITY_TIMEOUT")))
                    .withWaitTimeSeconds(Integer.parseInt(ProducerUtil.getRequiredEnv("SQS_WAIT_TIME_SECONDS")));


            message = sqs.receiveMessage(receive_request);
        } catch (final AmazonServiceException ase) {
            logger.error("Caught an AmazonServiceException, which means " +
                    "your request made it to Amazon SQS, but was " +
                    "rejected with an error response for some reason.");
            logger.error("Error Message:    " + ase.getMessage());
            logger.error("HTTP Status Code: " + ase.getStatusCode());
            logger.error("AWS Error Code:   " + ase.getErrorCode());
            logger.error("Error Type:       " + ase.getErrorType());
            logger.error("Request ID:       " + ase.getRequestId());

            throw new JobExecutionException();
        } catch (final AmazonClientException ace) {
            logger.error("Caught an AmazonClientException, which means " +
                    "the client encountered a serious internal problem while " +
                    "trying to communicate with Amazon SQS, such as not " +
                    "being able to access the network.");
            logger.error("Error Message: " + ace.getMessage());

            throw new JobExecutionException();
        }

        if (!message.getMessages().isEmpty()) {
            List<DeleteMessageBatchRequestEntry> deleteSQSBatchEntries = new ArrayList<>();

            if (this.kafkaProducerService == null) {
                this.kafkaProducerService = KafkaProducerService.getKafkaProducerService(processId);
            }

            sendSqsMessagesToKafkaTopic(message, deleteSQSBatchEntries, kafkaProducerService);

            if ((deleteSQSBatchEntries.size() != message.getMessages().size())) {
                logger.error("Some SQS messages where not processed");
            }

            if (!deleteSQSBatchEntries.isEmpty()) {
                sqs.deleteMessageBatch(queueUrl, deleteSQSBatchEntries);
            }
        }

        return !message.getMessages().isEmpty();
    }

    private void sendSqsMessagesToKafkaTopic(ReceiveMessageResult message,
                                             List<DeleteMessageBatchRequestEntry> deleteSQSBatchEntries,
                                             KafkaProducerService kafkaProducerService) throws EnvironmentVariableException {
        String rowkeySummary = "Rowkey summary: ";
        CharSequence currentRowKey = "";
        ObjectMapper objectMapper = new ObjectMapper().disable(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES);
        for (Message m : message.getMessages()) {
            try {
                CMTEncounter enc = objectMapper.readValue(m.getBody(), CMTEncounter.class);

                currentRowKey = enc.getRowKey();
                rowkeySummary = rowkeySummary + currentRowKey + " | ";
                logger.info(currentRowKey);

                byte[] payload = KafkaProducerService.serializeEncounter(enc, CMTEncounter.getClassSchema());

                ProducerRecord<String, byte[]> record = kafkaProducerService.produceKafkaRecord(payload);
                kafkaProducerService.sendKafkaRecord(record);

                deleteSQSBatchEntries.add(new DeleteMessageBatchRequestEntry(m.getMessageId(), m.getReceiptHandle()));
            } catch (JsonParseException e) {
                logger.error("JsonParseException from sendSqsMessagesToKafkaTopic method");
                logger.error("RowKey: " + currentRowKey);
                logger.error(filterPhi(e.getMessage()));
                sendSqsMessagesToDLQ(m, deleteSQSBatchEntries);
            } catch (JsonMappingException e) {
                logger.error("JsonMappingException from sendSqsMessagesToKafkaTopic method");
                logger.error("RowKey: " + currentRowKey);
                // Show error property but not PHI data
                logger.error(filterPhi(e.getMessage()));
                sendSqsMessagesToDLQ(m, deleteSQSBatchEntries);
            } catch (FHIRServiceException e) {
                logger.error("FHIRServiceException from sendSqsMessagesToKafkaTopic method");
                logger.error("RowKey: " + currentRowKey);
                logger.error(filterPhi(e.getMessage()));
                sendSqsMessagesToDLQ(m, deleteSQSBatchEntries);
            } catch (InterruptedException e) {
                //this exceptions happend dueing sending data to kafka, it will retry after due to sqs nature
                logger.error("InterruptedException from sendSqsMessagesToKafkaTopic method");
                logger.error("RowKey: " + currentRowKey);
                logger.error(filterPhi(e.getMessage()));
            } catch (ExecutionException e) {
                //this exceptions happend dueing sending data to kafka, it will retry after due to sqs nature
                logger.error("ExecutionException from sendSqsMessagesToKafkaTopic method");
                logger.error("RowKey: " + currentRowKey);
                logger.error(filterPhi(e.getMessage()));
            } catch (IOException e) {
                logger.error("IOException from sendSqsMessagesToKafkaTopic method");
                logger.error("RowKey: " + currentRowKey);
                logger.error(filterPhi(e.getMessage()));
                sendSqsMessagesToDLQ(m, deleteSQSBatchEntries);
            } catch (Exception e) {
                logger.error("Exception from sendSqsMessagesToKafkaTopic method");
                logger.error("RowKey: " + currentRowKey);
                logger.error(filterPhi(e.getMessage()));
                sendSqsMessagesToDLQ(m, deleteSQSBatchEntries);
            }
        }
        logger.info(rowkeySummary);
    }

    private void sendSqsMessagesToDLQ(Message m, List<DeleteMessageBatchRequestEntry> deleteSQSBatchEntries) throws EnvironmentVariableException {

        final String queueName = ProducerUtil.getRequiredEnv("DEAD_QUEUE_NAME");

        AmazonSQS sqs = null;
        if (ProducerUtil.getLocalAWScreds()) {
            logger.trace("Searching for SAML creds");
            ProfileCredentialsProvider profileCredentialsProvider = new ProfileCredentialsProvider("saml");
            sqs = AmazonSQSClientBuilder.standard()
                    .withRegion("us-east-1")
                    .withCredentials(profileCredentialsProvider)
                    .build();
        } else {
            logger.trace("Obtaining default creds");
            sqs = AmazonSQSClientBuilder.defaultClient();
        }

        try {
            SendMessageRequest sendMessageRequest = new SendMessageRequest()
                    .withQueueUrl(queueName)
                    .withMessageBody(m.getBody());
            sqs.sendMessage(sendMessageRequest);
            logger.error("Message sent to DLQ");

            DeleteMessageBatchRequestEntry deleteRequest = new DeleteMessageBatchRequestEntry(m.getMessageId(), m.getReceiptHandle());

            if (!deleteSQSBatchEntries.contains(deleteRequest)) {
                deleteSQSBatchEntries.add(deleteRequest);
            }

        } catch (Exception e) {
            logger.error("Exception from sendSqsMessagesToDLQ method");
            logger.error(filterPhi(e.getMessage()));
        }

    }

    /**
     * Created as the error message in the sendToKafka topic contains PHI if it's over a length of 120 chars
     *
     * @param s
     * @return first 120 characters of a string
     */
    private String filterPhi(String s) {
        if (s.length() > 120) {
            return s.substring(0, 120);
        }
        return s;
    }
}
