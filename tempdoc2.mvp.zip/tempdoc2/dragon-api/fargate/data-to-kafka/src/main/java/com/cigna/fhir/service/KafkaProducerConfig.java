package com.cigna.fhir.service;

import java.io.File;
import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;

import com.cigna.exception.EnvironmentVariableException;
import com.cigna.fhir.ProducerUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class KafkaProducerConfig {

    static final Logger logger = LogManager.getLogger(KafkaProducerConfig.class);


    public static Producer<String, byte[]> createProducer(String processId) throws EnvironmentVariableException {

        File krb5String = ProducerUtil.fileInputAsStream(ProducerUtil.getRequiredEnv("KRB5_CONFIG"));

        String finalPath = null;
        String jksPath = null;
        jksPath = ProducerUtil.getRequiredEnv("JKSPATH");
        finalPath = ProducerUtil.getRequiredEnv("SASL_KERBEROS_KEYTAB_LOC");

        String principal = ProducerUtil.getRequiredEnv("PRINCIPAL");
        String finalString = "com.sun.security.auth.module.Krb5LoginModule required useKeyTab=true storeKey=true keyTab=\""
                + finalPath + "\" principal=\"" + principal + "\";";

        logger.trace("finalString " + finalString);

        System.setProperty("java.security.krb5.conf", krb5String.toString());
        Properties props = new Properties();
        props.put("bootstrap.servers", ProducerUtil.getRequiredEnv("BROKER_LIST"));
        props.put("client.id", "SQStoKafka_" + processId);
        props.put("acks", "1");
        props.put("retries", 0);
        props.put("batch.size", 16384);
        props.put("linger.ms", 1);
        props.put("buffer.memory", 33554432);
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("value.serializer", "org.apache.kafka.common.serialization.ByteArraySerializer");
        props.put("security.protocol", ProducerUtil.getRequiredEnv("SECURITY_PROTOCOL"));
        props.put("sasl.mechanism", ProducerUtil.getRequiredEnv("SASL_MECHANISM"));
        props.put("sasl.kerberos.service.name", "kafka");
        props.put("sasl.jaas.config", finalString);
        props.put("ssl.truststore.location", jksPath);
        props.put("ssl.truststore.password", ProducerUtil.getRequiredEnv("JKS_PASSWORD"));
        props.put("ssl.truststore.type", "JKS");

        return new KafkaProducer<>(props);

    }
}
