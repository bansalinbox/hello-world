package com.cigna.fhir;

import com.cigna.exception.EnvironmentVariableException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class ProducerUtil {

    static final Logger logger = LogManager.getLogger(ProducerUtil.class);

    static boolean defaultValueFlag = false;

    public static boolean getDefaultValueFlag() {
        return defaultValueFlag;
    }

    public static void setDefaultValueFlag(boolean value) {
        ProducerUtil.defaultValueFlag = value;
    }

    static boolean localAWScreds = false;

    public static boolean getLocalAWScreds() {
        return localAWScreds;
    }

    public static void setLocalAWScreds(boolean value) {
        ProducerUtil.localAWScreds = value;
    }

    public static File fileInputAsStream(String filePath) {
        //String resourceLoc = path + "/" + filePath;
        File input = new File(filePath);
        return input;
    }

    /**
     * It will return the environment variable and check if the returned value is
     * empty or not null.
     *
     * @param name
     * @return
     */
    public static String getRequiredEnv(String name) throws EnvironmentVariableException {
        // Dont Forgot to change to false in Production
        String value = "";
        if (name != null && !name.equals("") && !name.trim().equals("")) {
            String envValue = "";
            if (ProducerUtil.defaultValueFlag) {
                logger.trace("SEARCHING FOR: " + name + " in default dictionary");
                envValue = setDefaultValues(name);
            } else {
                logger.trace("SEARCHING FOR: " + name + " in env variable");
                envValue = System.getenv(name);
            }
            if (envValue == null) {
                String errorMessage = "Did not found the envrionment variableName " + name;
                logger.error(errorMessage);
                throw new EnvironmentVariableException(errorMessage);
            } else {
                value = envValue;
            }
        } else {
            String errorMessage = "Varible name can not be empty";
            throw new EnvironmentVariableException(errorMessage);
        }
        return value;
    }


    /**
     * This method is used to set the environment variable for local run
     *
     * @param name
     * @return
     */
    public static String setDefaultValues(String name) {
        String localPath = "./com/cigna/fhir/";
        Map<String, String> kafkaDefaultValues = new HashMap<String, String>();
        kafkaDefaultValues.put("BROKER_LIST", "cilhdkfs0304.sys.cigna.com:9095,cilhdkfs0305.sys.cigna.com:9095");
        kafkaDefaultValues.put("SASL_MECHANISM", "GSSAPI");
        kafkaDefaultValues.put("TESTTOPIC", "FhirPayloadIntTest");
        kafkaDefaultValues.put("TOPIC", "FhirPayloadIntTest");
        kafkaDefaultValues.put("TESTSTRING", "0000-0000-0000-0000-0000-0000-0000");
        kafkaDefaultValues.put("SECURITY_PROTOCOL", "SASL_SSL");
       // kafkaDefaultValues.put("PRINCIPAL", "rtdesvc@SILVER.COM");
        kafkaDefaultValues.put("PRINCIPAL", "SVT_FHIR_BIGDATA@SILVER.COM");
        kafkaDefaultValues.put("KRB5_CONFIG", "./com/cigna/fhir/krb5-dev.conf");
        kafkaDefaultValues.put("SCHEMAPATH", "./com/cigna/fhir/fhir.avsc");
        kafkaDefaultValues.put("INTERVAL_TO_POOL_SQS_MESSAGE", "10");
        kafkaDefaultValues.put("SQS_MAX_NUMBER_OF_MESSAGES", "10");
        kafkaDefaultValues.put("SQS_VISIBILITY_TIMEOUT", "20");
        kafkaDefaultValues.put("SQS_WAIT_TIME_SECONDS", "20");
        kafkaDefaultValues.put("keytab_file", "CHECK SECRET IN AWS");

        kafkaDefaultValues.put("JKSPATH", localPath + "cigna-certs.jks");
        kafkaDefaultValues.put("SASL_KERBEROS_KEYTAB_LOC", localPath + "rtdesvc4.keytab");

        kafkaDefaultValues.put("PRODUCERTIMEOUT", "60000");
        kafkaDefaultValues.put("RCD_TY", "fhir_encounter");
        kafkaDefaultValues.put("QUEUE_NAME", "fhir-icollab-queue-sergii");

        return kafkaDefaultValues.get(name);

    }
}
