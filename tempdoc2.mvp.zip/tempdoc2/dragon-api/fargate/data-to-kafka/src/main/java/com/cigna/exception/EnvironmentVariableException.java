package com.cigna.exception;

public class EnvironmentVariableException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EnvironmentVariableException(String errorMessage, Throwable err){
		super(errorMessage, err);
	}

    public EnvironmentVariableException(String errorMessage) {
        super(errorMessage);
    }
}
