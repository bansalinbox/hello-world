package com.cigna.sqsconsumer;

import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.services.secretsmanager.AWSSecretsManager;
import com.amazonaws.services.secretsmanager.AWSSecretsManagerClientBuilder;
import com.amazonaws.services.secretsmanager.model.GetSecretValueRequest;
import com.amazonaws.services.secretsmanager.model.GetSecretValueResult;
import com.cigna.exception.EnvironmentVariableException;
import com.cigna.fhir.ProducerUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.quartz.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.Base64;

import static org.quartz.JobBuilder.*;
import static org.quartz.SimpleScheduleBuilder.*;
import static org.quartz.TriggerBuilder.*;


public class Main {

    public static String healthCheckFileName = "healthcheck.txt";
    static final Logger logger = LogManager.getLogger(Main.class);

    public static void main(String[] args) throws Exception {
        logger.info("BUILD_DATE is " + System.getenv("BUILD_DATE"));

        initHealthCheckFile();
        initKerberosFile();
        Main.initScheduler();
    }

    public static void initHealthCheckFile() throws IOException {
        File file = new File(Main.healthCheckFileName);
        file.createNewFile();
    }

    public static void initKerberosFile() throws IOException, EnvironmentVariableException {
        String keytabFileString = ProducerUtil.getRequiredEnv("keytab_file");

        byte[] decodedBinarySecret = Base64.getDecoder().decode(keytabFileString);

        FileChannel fc = new FileOutputStream(ProducerUtil.getRequiredEnv("SASL_KERBEROS_KEYTAB_LOC")).getChannel();
        fc.write(ByteBuffer.wrap(decodedBinarySecret));
        fc.close();
    }


    public static void initScheduler() throws SchedulerException, EnvironmentVariableException {
        SchedulerFactory schedFact = new org.quartz.impl.StdSchedulerFactory();
        Scheduler sched = schedFact.getScheduler();

        sched.start();

        JobDetail job = newJob(SQSConsumer.class)
                .withIdentity("execute", "sqsConsumerGroup")
                .build();

        Trigger trigger = newTrigger()
                .withIdentity("triggerSqsConsumer", "sqsConsumerGroup")
                .startNow()
                .withSchedule(simpleSchedule()
                        .withIntervalInSeconds(Integer.parseInt(ProducerUtil.getRequiredEnv("INTERVAL_TO_POOL_SQS_MESSAGE")))
                        .repeatForever())
                .build();

        // Tell quartz to schedule the job using our trigger
        sched.scheduleJob(job, trigger);
    }
}

