package com.cigna.fhir.service;

import com.cigna.exception.EnvironmentVariableException;
import com.cigna.exception.FHIRServiceException;
import com.cigna.fhir.ProducerUtil;
import org.apache.avro.Schema;
import org.apache.avro.file.DataFileWriter;
import org.apache.avro.io.DatumWriter;
import org.apache.avro.specific.SpecificDatumWriter;
import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

public class KafkaProducerService {
    static final Logger logger = LogManager.getLogger(KafkaProducerService.class);

    private Producer<String, byte[]> producer;
    private String kafkaTopicName;
    private String testTopic;
    private String testString;
    private int producerTimneout;

    public KafkaProducerService(String kafkaTopicName, String testTopic, String testString, Producer<String, byte[]> producer, int producerTimneout) {
        this.kafkaTopicName = kafkaTopicName;
        this.testTopic = testTopic;
        this.testString = testString;
        this.producer = producer;
        this.producerTimneout = producerTimneout;
    }

    public static KafkaProducerService getKafkaProducerService(String processId) throws EnvironmentVariableException, FHIRServiceException {
        Producer<String, byte[]> producer = KafkaProducerConfig.createProducer(processId);

        String kafkaTopic = ProducerUtil.getRequiredEnv("TOPIC");
        String testTopic = ProducerUtil.getRequiredEnv("TESTTOPIC");
        String testString = ProducerUtil.getRequiredEnv("TESTSTRING");
        int producerTimneout = Integer.parseInt(ProducerUtil.getRequiredEnv("PRODUCERTIMEOUT"));

        KafkaProducerService service = new KafkaProducerService(kafkaTopic, testTopic, testString, producer, producerTimneout);
        return service;
    }


    public ProducerRecord<String, byte[]> produceKafkaRecord(byte[] payload) {
        String topicName = new String(payload).indexOf(testString) > -1 ? testTopic : kafkaTopicName;
        ProducerRecord<String, byte[]> record = new ProducerRecord<String, byte[]>(topicName, payload);
        return record;
    }

    public void sendKafkaRecord(ProducerRecord<String, byte[]> record) throws InterruptedException, ExecutionException {
        RecordMetadata metadata;
        try {
            metadata = producer.send(record).get();
            logger.info("Record sent to partition " + metadata.partition() + " with offset " + metadata.offset());
        } catch (InterruptedException e) {
            logger.error("InterruptedException happened when getting the metadata of the sent data");
            throw e;
        } catch (ExecutionException e) {
            logger.error("ExecutionException happened when sending the message to kafka");
            throw e;
        }
    }

    public void closeProducer() {
        producer.close(this.producerTimneout, TimeUnit.MILLISECONDS);
    }

    public static <T extends SpecificRecordBase> byte[] serializeEncounter(T data, Schema myShema) throws FHIRServiceException {
        DatumWriter<T> datumWriter = new SpecificDatumWriter<T>();
        ByteArrayOutputStream stream = new ByteArrayOutputStream();

        DataFileWriter<T> dataFileWriter = new DataFileWriter<T>(datumWriter);
        try {
            dataFileWriter.create(myShema, stream);
            dataFileWriter.append(data);
            dataFileWriter.close();
        } catch (IOException e) {
            String err = "Exception happened while serializing the data";
            logger.error(err);
            throw new FHIRServiceException(err, e);
        }
        return stream.toByteArray();
    }
}
