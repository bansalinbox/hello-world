package com.cigna.exception;

public class FHIRServiceException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FHIRServiceException(String errorMessage, Throwable err){
		super(errorMessage, err);
	}

    public FHIRServiceException(String errorMessage) {
        super(errorMessage);
    }
}
