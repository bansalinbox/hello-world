## Put image to Fargate (taken from AWS Fargate)

Ensure you have installed the latest version of the AWS CLI and Docker. For more information, see the ECR documentation .
Retrieve the login command to use to authenticate your Docker client to your registry.  

Use the AWS CLI:
```bash 
$(aws ecr get-login --no-include-email --region us-east-1)
```

Note: If you receive an "Unknown options: --no-include-email" error when using the AWS CLI, ensure that you have the latest version installed. Learn more 
Build your Docker image using the following command. For information on building a Docker file from scratch see the instructions here . You can skip this step if your image is already built:

```bash
docker build -t datatokafka:v1 .
```

After the build completes, tag your image so you can push the image to this repository:  

```bash 
docker tag datatokafka:v1 003856232118.dkr.ecr.us-east-1.amazonaws.com/datatokafka:v1
```

Run the following command to push this image to your newly created AWS repository:  

```bash
docker push 003856232118.dkr.ecr.us-east-1.amazonaws.com/datatokafka:v1
```


### Generate avro classes.  

```text
java -jar $ATP compile schema ./avroschema/hbase_cmt_encounter.avsc src/main/java
```

Where $ATP is a path to `avro-tools-1.8.2.jar`.  
get `avro-tools-1.8.2.jar`  
```text
curl http://apache.claz.org/avro/avro-1.8.2/java/avro-tools-1.8.2.jar --output avro-tools-1.8.2.jar


## Convert avdl to avsc

java -jar $ATP idl2schemata schema/avdl/v1_2/cmt_encounter_v1_2.avdl ./schema/avsc/v1_2
avsc to java class
java -jar $ATP compile schema ./schema/avsc/v1_2/CMTEncounter.avsc src/main/java
