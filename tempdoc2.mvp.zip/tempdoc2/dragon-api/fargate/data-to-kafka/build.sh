#!/usr/bin/env sh

echo "ENV_COMPUTED_NAME - ${ENV_COMPUTED_NAME}"
echo "APP_DATA_TO_KAFKA_IMAGE_NAME - ${APP_DATA_TO_KAFKA_IMAGE_NAME}"
echo "STAGE_NAME - ${STAGE_NAME}"

BUILD_DATE=$(date -u +%FT%TZ)
echo "DOCKER BUILD DATE - ${BUILD_DATE}"
docker image build  --build-arg BUILD_DATE="${BUILD_DATE}" -t "${APP_DATA_TO_KAFKA_IMAGE_NAME}:${STAGE_NAME}"-latest .
