//THIS TS/JS FILE CAN BE USED FOR DEBUG WITH REAL DYNAMO_DB.
require("source-map-support").install();

import * as AWS from 'aws-sdk';

import {SNSEvent} from "aws-lambda";
import {cis} from "./handler";

var credentials = new AWS.SharedIniFileCredentials({profile: 'saml'});
AWS.config.credentials = credentials;

// @ts-ignore
let payload3 = {
  "Records": [
    {
      "messageId": "5f0946e7-63ed-4c8f-a2bd-85e9b849a6c4",
      "receiptHandle": "AQEBTedn59z7UsXUXqoONO7jxGxKHJN0UO4iTMcw5iKSVE3AK2CEjEJwyBpQDGb1ERo81eHqjOIOpKd4z3RabGOQQFhyxjN4NfORrvLnHnDwxNt2LUU1iuDmPN5aXYUWMjFfrkX0coOM4L2b9UAYrCY+r383uk/wS3pa+n6fWanNItgdDSwSz76K3mHWKMlk2GIV6+MihV0kQEo9Ke91AgqnJ0GuYVZaK/t/ohDqYm5x1MocvC5Fdu5gQ/jkJW4X87SLDwXkqUqVZnmBxKkGpIhW2Gy3fTowilDttXrHZFWiI5NNJLX5suhIoCIM0E9+MV2sg3tarRX6z0X8gj14HlYH+ArSFCQMyoSuwk6cTiA4x14jVyB0MDsQ9b9BdgIRdOcYajdmdHA0z5mUCtwVBPR5cwDH1LtBDb8FWfPk6M9bmYY=",
      "body": "{\"rowKey\":\"encounter#1234#2019-10-11T14:20:03.931Z#undefined\",\"EID\":\"1234\",\"source\":\"cmt\",\"cmtCreatedDt\":\"2019-08-07T14:49:44Z\",\"cohort\":\"default\",\"user\":\"5na3trf8v0im1ucqena7d7t7b1\",\"createdDate\":\"2019-11-22T00:22:42.572Z\",\"lastUpdatedDate\":\"2019-11-22T00:22:42.572Z\",\"organization\":{\"name\":\"My Location\",\"cmtId\":\"3f041b11-d3ae-46c5-a9d6-4f4349aca609\",\"npi\":\"\",\"tin\":\"\"},\"patient\":{\"cmtId\":\"bb2ddddd-1824-403a-b267-daf1cf11aa11\",\"EID\":\"1234\",\"otherId\":\"\",\"active\":true,\"gender\":\"F\",\"dob\":\"1911-11-11\",\"deceased\":false,\"firstName\":\"TEST\",\"lastName\":\"TESTER\",\"phone\":\"2221115555\",\"address\":{\"line1\":\"9999 TEST AVE S\",\"city\":\"TEST\",\"state\":\"WA\",\"zip\":\"98110\"}},\"practitioner\":{\"cmtId\":\"ac1e46a1-082b-4789-97e0-fee91b245d3e\",\"firstName\":\"DONALD\",\"lastName\":\"DUCK\",\"phone\":\"8675309\",\"address\":{\"line1\":\"3434 Market St\",\"city\":\"PHILADELPHIA\",\"state\":\"PA\",\"zip\":\"19113\"}},\"encounter\":{\"cmtId\":\"a7bdc0ec-02f3-4626-8066-701975acacac\",\"otherId\":\"10249211111\",\"status\":\"arrived\",\"text\":\"<div>Patient had an Inpatient encounter at test Facility</div>\",\"provider\":\"#wa_test\",\"subject\":\"#a7bdc0ec-02f3-4626-8066-701975acacac\",\"classCode\":\"I\",\"classDesc\":\"Inpatient\",\"startDate\":\"2019-10-11T14:20:03.931Z\",\"reason\":\"\",\"diagnosisList\":\"12345 | 6789\"}}",
      "attributes": {
        "ApproximateReceiveCount": "1",
        "SentTimestamp": "1560977325388",
        "SenderId": "AIDAIT2UOQQY3AUEKVGXU",
        "ApproximateFirstReceiveTimestamp": "1560977325395"
      },
      "md5OfBody": "2b7c8e97260aa7c07fd0579b01d20bf5",
      "eventSource": "aws:sqs",
      "eventSourceARN": "arn:aws:sqs:us-east-1:003856232118:fhir-exchange-storage-queue-sergii",
      "awsRegion": "us-east-1"
    }]
};



// cis(payload3, {}, (arguments1) => {
//   console.log(arguments1)
// });
