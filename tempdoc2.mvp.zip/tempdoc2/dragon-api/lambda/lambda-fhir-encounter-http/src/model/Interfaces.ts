export interface IMetadata {
  cohort?: string,
  userId?: string
}
