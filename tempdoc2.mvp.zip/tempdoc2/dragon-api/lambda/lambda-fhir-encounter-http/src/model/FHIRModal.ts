interface rowKey{
  resourceType?: string,
  EID?: string,
  AccountKey?: string,
  EncounterStartDate?: string,
  EncounterEndDate?: string
}

interface EncounterRespMapping {
    rowKey?: string,
    correlationId?: string,
    account_no?: string,
    account_no_dual?: string,
    EID?: string,
    accountKey?: string,
    user: string,
    cohort: string,
    cmtCreatedDt: string,
    createdDate: string,
    lastUpdatedDate: string,
    source: string,
    organization: Organisation,
    patient: Patient,
    practitioner: Practitioner,
    encounter : Encounter
}

interface Encounter {
    cmtId?: string,
    otherId?: string,
    status?: string,
    text?: string,
    provider?: string,
    subject?: string,
    classCode?: string,
    classDesc?: string,
    startDate?: string,
    endDate?: string,
    reason?: string,
    diagnosisList?: string,
    diag_1?: string,
    diag_2?: string,
    diag_3?: string,
    diag_4?: string,
    diag_5?: string,
    diag_6?: string,
    diag_7?: string,
    diag_8?: string,
    diag_9?: string,
    diag_10?: string,
    diagnosisTypeList?: string,
    diag_type_1?: string,
    diag_type_2?: string,
    diag_type_3?: string,
    diag_type_4?: string,
    diag_type_5?: string,
    diag_type_6?: string,
    diag_type_7?: string,
    diag_type_8?: string,
    diag_type_9?: string,
    diag_type_10?: string
}

interface ContactPoint {
    system?: string, // C? phone | fax | email | pager | url | sms | other
    value?: string, // The actual contact point details
    use?: string, // home | work | temp | old | mobile - purpose of this contact point
    rank?: string, // Specify preferred order of use (1 = highest)
    period : Period // Time period when the contact point was/is in use
}


interface Identifier {
    use?: string,
    type?: string,
    system?: string,
    value?: string,
    period?: Period
    // assigner?: { Reference(Organization) //TODO: need to check the strategy for this element, it is flatterned by cmt at orginisation level
}

interface Patient {
    cmtId?: string,
    otherId?: string,
    EID: string,
    active?: boolean,
    gender?: string,
    dob?: string,
    deceased?: string,
    firstName?: string,
    lastName?: string,
    phone?: string,
    address?: Address | ''
}

interface Address {
//https://www.hl7.org/fhir/datatypes.html#Address
    use?: string,// home | work | temp | old | billing - purpose of this address
    type?: string,// postal | physical | both
    text?: string,// Text representation of the address
    line?: string[],
    city?: string,// Name of city, town etc.
    district?: string,
    state?: string,
    zip?: string,
    country?: string,
    period?: Period// Time period when address was/is in use
}

interface Period{
    start?: string,
    end?: string
}

interface Organisation {
    cmtId?: string, // added explicitly
    npi?: string,
    tin?: string,
    active?: string,
    // type?:
    name?: string,
    alisas?: string[],
    telecom?: ContactPoint[],
    address?: Address[]
    //partOf?: string,
    //contact?
    //endpoint?; []
}

interface Practitioner {
    cmtId?: string, // added explicitly
    firstName?: string,
    lastName?: string,
    address?: Address | '',
    // type?:
    phone?: string

    //partOf?: string,
    //contact?
    //endpoint?; []
}
