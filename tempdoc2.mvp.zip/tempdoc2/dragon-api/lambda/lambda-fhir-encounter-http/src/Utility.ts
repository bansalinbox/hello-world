import * as JWT from 'jsonwebtoken'

export class Utility {
  /**
   * Reformat the exception to custom exception
   * @param {string} name
   * @param {string} message
   * @param {Error} err
   * @returns {Error}
   */
  public static error(name: string, message: string, err: Error) {
    let errStack = null;
    if (err != null) {
      if (err.stack != null) {
        errStack = err.stack;
      }
    }
    let e = new Error();
    e.name = name;
    e.message = message + ' : ' + err.message;
    e.stack = errStack;
    return e;
  }

  public static getClientIdFromJWT(jwt: string): string {
    const bearer = "Bearer ";
    if (jwt && jwt.indexOf(bearer) == 0) {
      jwt = jwt.substr(bearer.length);
    }
    let jwtDecode = JWT.decode(jwt);
    return jwtDecode ? jwtDecode.sub : "UNKNOWN_ERROR";
  }

  public static addRequiredFields(item: EncounterRespMapping): EncounterRespMapping {
    item.account_no = "NA";
    item.account_no_dual = "NA";

    let diagnoseList = (item.encounter.diagnosisList ? item.encounter.diagnosisList.split('|') : []);
    for (let index = 0; index < 10 && index < diagnoseList.length; index++) {
      item.encounter["diag_" + (index + 1).toString()] = diagnoseList[index].trim();
    }
    let diagnosisTypeList = (item.encounter.diagnosisTypeList ? item.encounter.diagnosisTypeList.split('|') : []);
    for (let index = 0; index < 10 && index < diagnosisTypeList.length; index++) {
      item.encounter["diag_type_" + (index + 1).toString()] = diagnosisTypeList[index].trim();
    }
    return item;
  }
}
