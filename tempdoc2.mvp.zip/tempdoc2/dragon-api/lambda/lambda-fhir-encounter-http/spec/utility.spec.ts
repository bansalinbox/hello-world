import {Utility} from "../src/Utility";

describe('Utility Method tests', function () {

  describe('custom error message verification', function () {

    it('should equal appened the cutome error to acutal error message', function () {

      let e = new Error();
      e.message = 'msg content 1';
      let newError = Utility.error("StandardError", "msg content 2", e);
      const newErrorMsg = newError.message;

      expect(newErrorMsg).toEqual("msg content 2 : msg content 1");

    });
  });

  describe('jwt token', function () {

    it('should parse token with Bearer', function () {
      const token_with_bearer = "Bearer eyJraWQiOiJ6SDFtQmIzOVF3SmtJUTZGWGI4NVwvUnZNcFVUZ3BDXC8rRWoxNGlwQzZrbVk9IiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiI1bmEzdHJmOHYwaW0xdWNxZW5hN2Q3dDdiMSIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoiZW5jb3VudGVyXC9wb3N0IiwiYXV0aF90aW1lIjoxNTYwOTc0ODE1LCJpc3MiOiJodHRwczpcL1wvY29nbml0by1pZHAudXMtZWFzdC0xLmFtYXpvbmF3cy5jb21cL3VzLWVhc3QtMV9JaEVONnliTTMiLCJleHAiOjE1NjA5Nzg0MTUsImlhdCI6MTU2MDk3NDgxNSwidmVyc2lvbiI6MiwianRpIjoiNWQ5ZDExNmEtZjM4ZC00YTE0LWJiZjMtYzA2M2JhMzYxMjE0IiwiY2xpZW50X2lkIjoiNW5hM3RyZjh2MGltMXVjcWVuYTdkN3Q3YjEifQ.QGvmbK6pF_2xocXD-jnicVJcjbcjUaDNPkchVQEFF1paGwaz3j-h4cm4zXwoeahBFbugpvx4KMBT3LfGvmrEFLC1lcZDCdjCCB34_SU8aCqIahMth4-TWwbs1eIAgkwdIh_l78_mNXCl6KY_U1XPN-ucrzGgQgfjv_TniO5sRE-2oBEAB8WSKqIJ6VfuBZlwNjl0kyXhDs0TsXphDakELBJ8I-3n9Iici_UL45payybA0lljcI0u73W2XeRBP9GJTMqonaeWMNId42tTnGVoxAz3OSSvFYdHqBOTXPfufRHx1rx8n4oq2u5Kj_rMJ9t7UxMtzrRugrX4OT04tVcq7w";
      const expected = "5na3trf8v0im1ucqena7d7t7b1";
      const result = Utility.getClientIdFromJWT(token_with_bearer);
      expect(expected).toEqual(result);
    });

    it('should parse token without Bearer', function () {
      const token = "eyJraWQiOiJ6SDFtQmIzOVF3SmtJUTZGWGI4NVwvUnZNcFVUZ3BDXC8rRWoxNGlwQzZrbVk9IiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiI1bmEzdHJmOHYwaW0xdWNxZW5hN2Q3dDdiMSIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoiZW5jb3VudGVyXC9wb3N0IiwiYXV0aF90aW1lIjoxNTYwOTc0ODE1LCJpc3MiOiJodHRwczpcL1wvY29nbml0by1pZHAudXMtZWFzdC0xLmFtYXpvbmF3cy5jb21cL3VzLWVhc3QtMV9JaEVONnliTTMiLCJleHAiOjE1NjA5Nzg0MTUsImlhdCI6MTU2MDk3NDgxNSwidmVyc2lvbiI6MiwianRpIjoiNWQ5ZDExNmEtZjM4ZC00YTE0LWJiZjMtYzA2M2JhMzYxMjE0IiwiY2xpZW50X2lkIjoiNW5hM3RyZjh2MGltMXVjcWVuYTdkN3Q3YjEifQ.QGvmbK6pF_2xocXD-jnicVJcjbcjUaDNPkchVQEFF1paGwaz3j-h4cm4zXwoeahBFbugpvx4KMBT3LfGvmrEFLC1lcZDCdjCCB34_SU8aCqIahMth4-TWwbs1eIAgkwdIh_l78_mNXCl6KY_U1XPN-ucrzGgQgfjv_TniO5sRE-2oBEAB8WSKqIJ6VfuBZlwNjl0kyXhDs0TsXphDakELBJ8I-3n9Iici_UL45payybA0lljcI0u73W2XeRBP9GJTMqonaeWMNId42tTnGVoxAz3OSSvFYdHqBOTXPfufRHx1rx8n4oq2u5Kj_rMJ9t7UxMtzrRugrX4OT04tVcq7w";
      const expected = "5na3trf8v0im1ucqena7d7t7b1";
      const result = Utility.getClientIdFromJWT(token);
      expect(expected).toEqual(result);
    });

    it('should return error string in case of corrupted token with Bearer word', function () {
      const token = "Bearer CORRUPTEDeyJraWQiOiJ6SDFtQmIzOVF3SmtJUTZGWGI4NVwvUnZNcFVUZ3BDXC8rRWoxNGlwQzZrbVk9IiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiI1bmEzdHJmOHYwaW0xdWNxZW5hN2Q3dDdiMSIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoiZW5jb3VudGVyXC9wb3N0IiwiYXV0aF90aW1lIjoxNTYwOTc0ODE1LCJpc3MiOiJodHRwczpcL1wvY29nbml0by1pZHAudXMtZWFzdC0xLmFtYXpvbmF3cy5jb21cL3VzLWVhc3QtMV9JaEVONnliTTMiLCJleHAiOjE1NjA5Nzg0MTUsImlhdCI6MTU2MDk3NDgxNSwidmVyc2lvbiI6MiwianRpIjoiNWQ5ZDExNmEtZjM4ZC00YTE0LWJiZjMtYzA2M2JhMzYxMjE0IiwiY2xpZW50X2lkIjoiNW5hM3RyZjh2MGltMXVjcWVuYTdkN3Q3YjEifQ.QGvmbK6pF_2xocXD-jnicVJcjbcjUaDNPkchVQEFF1paGwaz3j-h4cm4zXwoeahBFbugpvx4KMBT3LfGvmrEFLC1lcZDCdjCCB34_SU8aCqIahMth4-TWwbs1eIAgkwdIh_l78_mNXCl6KY_U1XPN-ucrzGgQgfjv_TniO5sRE-2oBEAB8WSKqIJ6VfuBZlwNjl0kyXhDs0TsXphDakELBJ8I-3n9Iici_UL45payybA0lljcI0u73W2XeRBP9GJTMqonaeWMNId42tTnGVoxAz3OSSvFYdHqBOTXPfufRHx1rx8n4oq2u5Kj_rMJ9t7UxMtzrRugrX4OT04tVcq7w";
      const expected = "UNKNOWN_ERROR";
      const result = Utility.getClientIdFromJWT(token);
      expect(expected).toEqual(result);
    });

    it('should return error string in case of corrupted token', function () {
      const token = "CORRUPTEDeyJraWQiOiJ6SDFtQmIzOVF3SmtJUTZGWGI4NVwvUnZNcFVUZ3BDXC8rRWoxNGlwQzZrbVk9IiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiI1bmEzdHJmOHYwaW0xdWNxZW5hN2Q3dDdiMSIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoiZW5jb3VudGVyXC9wb3N0IiwiYXV0aF90aW1lIjoxNTYwOTc0ODE1LCJpc3MiOiJodHRwczpcL1wvY29nbml0by1pZHAudXMtZWFzdC0xLmFtYXpvbmF3cy5jb21cL3VzLWVhc3QtMV9JaEVONnliTTMiLCJleHAiOjE1NjA5Nzg0MTUsImlhdCI6MTU2MDk3NDgxNSwidmVyc2lvbiI6MiwianRpIjoiNWQ5ZDExNmEtZjM4ZC00YTE0LWJiZjMtYzA2M2JhMzYxMjE0IiwiY2xpZW50X2lkIjoiNW5hM3RyZjh2MGltMXVjcWVuYTdkN3Q3YjEifQ.QGvmbK6pF_2xocXD-jnicVJcjbcjUaDNPkchVQEFF1paGwaz3j-h4cm4zXwoeahBFbugpvx4KMBT3LfGvmrEFLC1lcZDCdjCCB34_SU8aCqIahMth4-TWwbs1eIAgkwdIh_l78_mNXCl6KY_U1XPN-ucrzGgQgfjv_TniO5sRE-2oBEAB8WSKqIJ6VfuBZlwNjl0kyXhDs0TsXphDakELBJ8I-3n9Iici_UL45payybA0lljcI0u73W2XeRBP9GJTMqonaeWMNId42tTnGVoxAz3OSSvFYdHqBOTXPfufRHx1rx8n4oq2u5Kj_rMJ9t7UxMtzrRugrX4OT04tVcq7w";
      const expected = "UNKNOWN_ERROR";
      const result = Utility.getClientIdFromJWT(token);
      expect(expected).toEqual(result);
    });

    it('should return error string in case if token empty', function () {
      const token = "";
      const expected = "UNKNOWN_ERROR";
      const result = Utility.getClientIdFromJWT(token);
      expect(expected).toEqual(result);
    });

    it('should return error string in case if token null', function () {
      const token = null;
      const expected = "UNKNOWN_ERROR";
      const result = Utility.getClientIdFromJWT(token);
      expect(expected).toEqual(result);
    });

    it('should return error string in case if token undefined', function () {
      const token = undefined;
      const expected = "UNKNOWN_ERROR";
      const result = Utility.getClientIdFromJWT(token);
      expect(expected).toEqual(result);
    });

  });

  describe('Adding fields to payload', function () {
    it('should set account numbers', function () {
      let payload = {
        rowKey: 'encounter#1234#2019-10-11T14:20:03.931Z#undefined',
        source: 'cmt',
        cmtCreatedDt: '2019-08-07T14:49:44Z',
        cohort: 'default',
        user: '5na3trf8v0im1ucqena7d7t7b1',
        createdDate: '2019-11-22T00:22:42.572Z',
        lastUpdatedDate: '2019-11-22T00:22:42.572Z',
        organization: {
          cmtId: '3f041b11-d3ae-46c5-a9d6-4f4349aca609',
        },
        patient: {
          cmtId: 'bb2ddddd-1824-403a-b267-daf1cf11aa11',
          EID: '1234'
        },
        practitioner: {
          cmtId: 'ac1e46a1-082b-4789-97e0-fee91b245d3e',
        },
        encounter: {
          cmtId: 'a7bdc0ec-02f3-4626-8066-701975acacac',
          diagnosisList: '12345 | 6789'
        }
      };

      let result = Utility.addRequiredFields(payload);

      expect(result.account_no_dual).toEqual("NA");
      expect(result.account_no).toEqual("NA");

    });

    it('should set diag_X property for 10 diagnoses', function () {
      let payload = {
        rowKey: 'encounter#1234#2019-10-11T14:20:03.931Z#undefined',
        source: 'cmt',
        cmtCreatedDt: '2019-08-07T14:49:44Z',
        cohort: 'default',
        user: '5na3trf8v0im1ucqena7d7t7b1',
        createdDate: '2019-11-22T00:22:42.572Z',
        lastUpdatedDate: '2019-11-22T00:22:42.572Z',
        organization: {
          cmtId: '3f041b11-d3ae-46c5-a9d6-4f4349aca609',
        },
        patient: {
          cmtId: 'bb2ddddd-1824-403a-b267-daf1cf11aa11',
          EID: '1234'
        },
        practitioner: {
          cmtId: 'ac1e46a1-082b-4789-97e0-fee91b245d3e',
        },
        encounter: {
          cmtId: 'a7bdc0ec-02f3-4626-8066-701975acacac',
          diagnosisList: 'diag_1 | diag_2 | diag_3 | diag_4 | diag_5 | diag_6 | diag_7 | diag_8 | diag_9 | diag_10'
        }
      };

      let result = Utility.addRequiredFields(payload);

      expect(result.encounter.diag_1).toEqual("diag_1");
      expect(result.encounter.diag_2).toEqual("diag_2");
      expect(result.encounter.diag_3).toEqual("diag_3");
      expect(result.encounter.diag_4).toEqual("diag_4");
      expect(result.encounter.diag_5).toEqual("diag_5");
      expect(result.encounter.diag_6).toEqual("diag_6");
      expect(result.encounter.diag_7).toEqual("diag_7");
      expect(result.encounter.diag_8).toEqual("diag_8");
      expect(result.encounter.diag_9).toEqual("diag_9");
      expect(result.encounter.diag_10).toEqual("diag_10");
    });

    it('should set diag_X property for 3 diagnoses', function () {
      let payload = {
        rowKey: 'encounter#1234#2019-10-11T14:20:03.931Z#undefined',
        source: 'cmt',
        cmtCreatedDt: '2019-08-07T14:49:44Z',
        cohort: 'default',
        user: '5na3trf8v0im1ucqena7d7t7b1',
        createdDate: '2019-11-22T00:22:42.572Z',
        lastUpdatedDate: '2019-11-22T00:22:42.572Z',
        organization: {
          cmtId: '3f041b11-d3ae-46c5-a9d6-4f4349aca609',
        },
        patient: {
          cmtId: 'bb2ddddd-1824-403a-b267-daf1cf11aa11',
          EID: '1234'
        },
        practitioner: {
          cmtId: 'ac1e46a1-082b-4789-97e0-fee91b245d3e',
        },
        encounter: {
          cmtId: 'a7bdc0ec-02f3-4626-8066-701975acacac',
          diagnosisList: 'diag_1 | diag_2 | diag_3'
        }
      };

      let result = Utility.addRequiredFields(payload);

      expect(result.encounter.diag_1).toEqual("diag_1");
      expect(result.encounter.diag_2).toEqual("diag_2");
      expect(result.encounter.diag_3).toEqual("diag_3");
    });

    it('should NOT set diagnosed list (diagnosisList is empty string)', function () {
      let payload = {
        rowKey: 'encounter#1234#2019-10-11T14:20:03.931Z#undefined',
        source: 'cmt',
        cmtCreatedDt: '2019-08-07T14:49:44Z',
        cohort: 'default',
        user: '5na3trf8v0im1ucqena7d7t7b1',
        createdDate: '2019-11-22T00:22:42.572Z',
        lastUpdatedDate: '2019-11-22T00:22:42.572Z',
        organization: {
          cmtId: '3f041b11-d3ae-46c5-a9d6-4f4349aca609',
        },
        patient: {
          cmtId: 'bb2ddddd-1824-403a-b267-daf1cf11aa11',
          EID: '1234'
        },
        practitioner: {
          cmtId: 'ac1e46a1-082b-4789-97e0-fee91b245d3e',
        },
        encounter: {
          cmtId: 'a7bdc0ec-02f3-4626-8066-701975acacac',
          diagnosisList: ''
        }
      };

      let result = Utility.addRequiredFields(payload);

      expect(result.encounter.diag_1).toBeUndefined();
      expect(result.encounter.diag_2).toBeUndefined();
      expect(result.encounter.diag_3).toBeUndefined();
      expect(result.encounter.diag_4).toBeUndefined();
      expect(result.encounter.diag_5).toBeUndefined();
      expect(result.encounter.diag_6).toBeUndefined();
      expect(result.encounter.diag_7).toBeUndefined();
      expect(result.encounter.diag_8).toBeUndefined();
      expect(result.encounter.diag_9).toBeUndefined();
      expect(result.encounter.diag_10).toBeUndefined();

    });

    it('should NOT set diagnosed list (diagnosisList is undefined)', function () {
      let payload = {
        rowKey: 'encounter#1234#2019-10-11T14:20:03.931Z#undefined',
        source: 'cmt',
        cmtCreatedDt: '2019-08-07T14:49:44Z',
        cohort: 'default',
        user: '5na3trf8v0im1ucqena7d7t7b1',
        createdDate: '2019-11-22T00:22:42.572Z',
        lastUpdatedDate: '2019-11-22T00:22:42.572Z',
        organization: {
          cmtId: '3f041b11-d3ae-46c5-a9d6-4f4349aca609',
        },
        patient: {
          cmtId: 'bb2ddddd-1824-403a-b267-daf1cf11aa11',
          EID: '1234'
        },
        practitioner: {
          cmtId: 'ac1e46a1-082b-4789-97e0-fee91b245d3e',
        },
        encounter: {
          cmtId: 'a7bdc0ec-02f3-4626-8066-701975acacac'
        }
      };

      let result = Utility.addRequiredFields(payload);

      expect(result.encounter.diag_1).toBeUndefined();
      expect(result.encounter.diag_2).toBeUndefined();
      expect(result.encounter.diag_3).toBeUndefined();
      expect(result.encounter.diag_4).toBeUndefined();
      expect(result.encounter.diag_5).toBeUndefined();
      expect(result.encounter.diag_6).toBeUndefined();
      expect(result.encounter.diag_7).toBeUndefined();
      expect(result.encounter.diag_8).toBeUndefined();
      expect(result.encounter.diag_9).toBeUndefined();
      expect(result.encounter.diag_10).toBeUndefined();
    });

  });
});
