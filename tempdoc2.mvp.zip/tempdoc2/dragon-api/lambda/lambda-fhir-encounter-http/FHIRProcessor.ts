import * as AWS from "aws-sdk";
import {AxiosInstance} from "axios";
import {SecretsManager} from 'aws-sdk';
import {SQSEvent, SQSRecord} from "aws-lambda";
import {Utility} from "./src/Utility";

export default class FHIRProcessor {
  axiosClient: AxiosInstance;
  private SECRET_NM: string;
  private FHIR_SERVER_URL: string;
  private REGION: string;
  private AXIOS_TIMEOUT_MS: number;

  constructor(axiosClient: AxiosInstance,
              options: {
                SECRET_NM: string,
                FHIR_SERVER_URL: string,
                REGION: string,
                AXIOS_TIMEOUT_MS: number
              }) {
    this.axiosClient = axiosClient;
    this.SECRET_NM = options.SECRET_NM;
    this.FHIR_SERVER_URL = options.FHIR_SERVER_URL;
    this.REGION = options.REGION;
    this.AXIOS_TIMEOUT_MS = options.AXIOS_TIMEOUT_MS;
  }

  public async handler(event: SQSEvent, callback) {
    let messages = event.Records.map((record: SQSRecord) => {
      let x:EncounterRespMapping = JSON.parse(record.body);
      return x;
    }).map(item => Utility.addRequiredFields(item));


    let parsedMsgs: Array<EncounterRespMapping> = messages;
    await this.callHttpServer(parsedMsgs, callback);
  }

  public async callHttpServer(values: Array<EncounterRespMapping>, callback: any) {
    let token;
    try {
      try {
        let resolvedToken = await this.getSecret();
        token = 'Bearer ' + JSON.parse(resolvedToken.toString()).token;
      } catch (err) {
        console.log(err);
        let errMsg = "Exception happened while getting the secret from secret manager";
        throw Utility.error(StandardError.SECRET_ERROR, errMsg, err);
      }

      let response = await this.fhirProcessorHttpCall(token, values);
      console.info(`Response code from the fhirProcessorHttpCall api is ${response.status}`);

    } catch (ex) {
      let msg = `Exception happened while calling the fhir https service from fhir encounter parser. `;
      let resp = ex.response;
      if (resp != undefined) {
        let responseData = resp.data;
        let responseDataString = null;
        if (responseData != null) {
          responseDataString = JSON.stringify(responseData);
        }
        msg = msg + 'Response Data of error is : ' + responseDataString + '';
        let statusCode = resp.status;
        if (responseData.status_code == 400 && responseData.error_type == 'PAYLOAD_ERROR') {
          console.log(msg);
          console.log('Sending to DLQ');
          await this.sendDLQ(values);

        } else {
          console.error(`${msg} Response status from fhir https service is ${statusCode}, so sending for retry`);
          callback(Utility.error(StandardError.RETRY_BATCH, msg, ex), null);
        }

      } else {
        let msg1 = 'Response is undefined, it usually happens when there is an issue of the connectivity with fhir http server ';

        callback(Utility.error(StandardError.FHIR_HTTP_SERVER_ERROR, msg1, ex), null);
      }
    }
    console.info('Execution of callHttpServer is complete');
  }

  public async fhirProcessorHttpCall(token: string, payload: Array<EncounterRespMapping>) {
    let contentType = 'application/json';
    const headers = {'content-type': contentType, 'authorization': token};
    let encounterApiResp = await this.axiosClient.post(this.FHIR_SERVER_URL, payload, {headers: headers});
    return encounterApiResp;
  }

  public async sendDLQ(payload: Array<EncounterRespMapping>) {
    let queueUrl = process.env.DLQ_URL;
    //console.log(process.env.DLQ_URL)
    //console.log(payload)
    var sqs = new AWS.SQS();
    var params = {
      MessageBody: JSON.stringify(payload),
      QueueUrl: queueUrl,
      DelaySeconds: 10
    };

    try {
      let upload = await sqs.sendMessage(params).promise();
      console.info(upload);
    } catch (e) {
      let msg = "Exception happened while sending data to DLQ"
      //console.log(e)
      //console.log(msg)
      throw Utility.error(StandardError.DLQ_ERROR, msg, e)
    }
  }

  public async getSecret() {
    var secretName = this.SECRET_NM;

    var client = new SecretsManager({
      region: this.REGION
    });
    return new Promise(function (resolve, reject) {
      client.getSecretValue({SecretId: secretName}, function (err, data) {
        if (err) {
          // Secrets Manager can't decrypt the protected secret text using the provided KMS key.
          // Deal with the exception here, and/or rethrow at your discretion.
          //  throw err;
          if (err.code === 'DecryptionFailureException') {
            reject(err);
          } else if (err.code === 'InternalServiceErrorException') {
            reject(err);
          }
          // An error occurred on the server side.
          // Deal with the exception here, and/or rethrow at your discretion.
          else if (err.code === 'InvalidParameterException') {
            reject(err);
          }
          // You provided an invalid value for a parameter.
          // Deal with the exception here, and/or rethrow at your discretion.
          else if (err.code === 'InvalidRequestException') {
            reject(err);
          }
          // You provided a parameter value that is not valid for the current state of the resource.
          // Deal with the exception here, and/or rethrow at your discretion.
          else if (err.code === 'ResourceNotFoundException') {
            reject(err);
          } else {
            reject(err);
          }
          // We can't find the resource that you asked for.
          // Deal with the exception here, and/or rethrow at your discretion.

        } else {
          // Decrypts secret using the associated KMS CMK.
          // Depending on whether the secret is a string or binary, one of these fields will be populated.
          resolve(data.SecretString);
        }
      });
    });
  }
}


enum StandardError {
  FHIR_HTTP_SERVER_ERROR = 'FHIR_HTTP_SERVER_ERROR',
  TOKEN_EXPIRED = 'TOKEN_EXPIRED',
  RETRY_BATCH = 'RETRY_BATCH',
  SECRET_ERROR = 'SECRET_ERROR',
  DLQ_ERROR = 'DLQ_ERROR'
}
