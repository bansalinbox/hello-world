require("source-map-support").install();

import * as https from "https";
import FHIRProcessor from "./FHIRProcessor";
import { SQSEvent } from "aws-lambda";
import * as fs from "fs";
import axios, { AxiosInstance } from "axios";

https.globalAgent.options.ca = fs.readFileSync(process.env.CIGNA_CA_CERT);

let handler = async (event: SQSEvent, context, callback) => {
  //console.log(JSON.stringify(event));
  try {
    let rowkey : string = "Rowkey: ";
    for(let record of event.Records)
     {
      
      rowkey = rowkey + JSON.parse(record.body).rowKey + " | " 

     }
    console.log (rowkey); 

    let axiosClient: AxiosInstance = axios.create();
    axiosClient.defaults.timeout = this.AXIOS_TIMEOUT_MS;
    let fhirProcessor = new FHIRProcessor(axiosClient, {
      AXIOS_TIMEOUT_MS: +process.env.AXIOS_TIMEOUT_MS,
      FHIR_SERVER_URL: process.env.FHIR_SERVER_URL,
      SECRET_NM: process.env.SECRET_NM,
      REGION: process.env.REGION
    });
    await fhirProcessor.handler(event, callback);
  } catch (e) {
    console.error('UNEXPECTED EXCEPTION HAPPENED');
    callback(e);
  }
}

export { handler as cis };
