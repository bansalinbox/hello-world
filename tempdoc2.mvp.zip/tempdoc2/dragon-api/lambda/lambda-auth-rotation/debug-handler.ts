//THIS TS/JS FILE CAN BE USED FOR DEBUG WITH REAL DYNAMO_DB.

import * as AWS from 'aws-sdk';

//Setup variables before any other module initializations
var credentials = new AWS.SharedIniFileCredentials({profile: 'saml'});
AWS.config.credentials = credentials;
process.env.API_VERSION = '2012-10-08';
process.env.AWS_REGION = 'us-east-1';
process.env.SECRET_NAME = "fhir-transform-bearer";
process.env.COGNITO_POOL = "us-east-1_yanra41yz";
process.env.FHIR_OPS_ID = "3umhnloe77rim7llcqd4ncjq4f";
process.env.KMS_KEY_ID = "";
process.env.SCOPE = "operations/post";
process.env.COGNITO_OAUTH_URL = "https://cigna-fhir-operations-sys.auth.us-east-1.amazoncognito.com/oauth2/token";

import { cis } from "./handler";
import { CloudWatchLogsEvent } from "aws-lambda";

let payload = <CloudWatchLogsEvent> {
}

cis(payload, {}, (arguments1) => {
  console.log(arguments1)
});
