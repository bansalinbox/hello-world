require("source-map-support").install();

import Axios, * as axios from "axios";
import { SecretsManager, CognitoIdentityServiceProvider } from 'aws-sdk';
import { DescribeUserPoolClientRequest, DescribeUserPoolClientResponse } from "aws-sdk/clients/cognitoidentityserviceprovider";
import { UpdateSecretRequest } from "aws-sdk/clients/secretsmanager";
import { CloudWatchLogsEvent } from "aws-lambda";

const secretMgr = new SecretsManager();
const getIDSecret = new CognitoIdentityServiceProvider();

let handler = (event: CloudWatchLogsEvent, context, callback) => {
  let cognitoParams: DescribeUserPoolClientRequest = {
    ClientId: process.env.FHIR_OPS_ID,
    UserPoolId: process.env.COGNITO_POOL
  };

  console.log(`Calling Cognito Pool ${cognitoParams.UserPoolId} for ${cognitoParams.ClientId}`);

  getIDSecret.describeUserPoolClient(cognitoParams, (err, data: DescribeUserPoolClientResponse) => {
    if (err) {
      console.log(`Error describing Pool Client ${err}`);
      callback(err);
    } else {
      console.log("Building URL");
      const config: axios.AxiosRequestConfig = {
        url: process.env.COGNITO_OAUTH_URL,
        method: "post",
        data: `grant_type=client_credentials&scope=${encodeURIComponent(process.env.SCOPE)}`,
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        },
        auth: {
          username: data.UserPoolClient.ClientId,
          password: data.UserPoolClient.ClientSecret
        }
      }

      console.log(`Getting bearer token for ${config.auth.username} using ${config.url}`);
      Axios.request(config)
        .then((response) => {
          let secretParams: UpdateSecretRequest = {
            SecretId: process.env.SECRET_NAME,
            SecretString: `{ \"token\":"${response.data["access_token"]}" }`,
          }

          secretMgr.updateSecret(secretParams, (err, data) => {
            if (err) {
              console.log("Secret Manager error");
              console.log(JSON.stringify(err, null, 2));
              callback(err);
            } else {
              callback(null, "Secret updated successfully");
            }
          })
        })
        .catch((oauthErr) => {
          console.log("OAuth Error");
          console.log(JSON.stringify(oauthErr, null, 2));
          callback(oauthErr);
        })
    }
  });
}

export { handler as cis };
