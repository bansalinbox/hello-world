import { SpecReporter } from "jasmine-spec-reporter"
import { Reporter } from "jasmine-pretty-html-reporter"

jasmine.getEnv().clearReporters();
jasmine.getEnv().addReporter(new SpecReporter({ }))

jasmine.getEnv().addReporter(new Reporter({
    path: './unit-test-results'
}))