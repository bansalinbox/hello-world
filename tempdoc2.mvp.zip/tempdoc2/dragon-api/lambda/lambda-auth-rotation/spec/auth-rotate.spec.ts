import {} from 'jasmine'
import { cis } from "../handler"
import { CloudWatchLogsEvent } from "aws-lambda"
import * as AWS from 'aws-sdk'

describe("Auth Rotation", () => {
    it("should fail with incorrect credentials", (done) => {
        //Setup variables before any other module initializations
        let credentials = new AWS.SharedIniFileCredentials({profile: 'saml'})
        AWS.config.credentials = credentials
        process.env.API_VERSION = '2012-10-08'
        process.env.AWS_REGION = 'us-east-1'
        process.env.SECRET_NAME = "fhir-transform-bearer"
        process.env.COGNITO_POOL = "us-east-1_yanra41yz"        // This Congito Pool does not exist
        process.env.FHIR_OPS_ID = "3umhnloe77rim7llcqd4ncjq4f"  // This ID does not exist
        process.env.SCOPE = "operations/post"
        process.env.COGNITO_OAUTH_URL = "https://cigna-fhir-operations-sys.auth.us-east-1.amazoncognito.com/oauth2/token"
        
        let payload = <CloudWatchLogsEvent> { }
        
        cis(payload, {}, (err, data) => {
            expect(data).not.toBeDefined()
            done()
        })
    })
})