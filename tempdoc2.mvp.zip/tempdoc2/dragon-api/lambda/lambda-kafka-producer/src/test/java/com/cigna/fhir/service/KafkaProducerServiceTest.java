package com.cigna.fhir.service;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.avro.file.DataFileStream;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.producer.Producer;
import org.junit.Test;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.amazonaws.services.lambda.runtime.events.SQSEvent.SQSMessage;
import com.cigna.exception.EnvironmentVariableException;
import com.cigna.exception.FHIRServiceException;
import com.cigna.fhir.ProducerUtil;

public class KafkaProducerServiceTest {

	public static void SerializeDeserialize() throws IOException, EnvironmentVariableException, FHIRServiceException {
		String payload = "this is test data";
		String schemapath = ProducerUtil.getRequiredEnv("SCHEMAPATH");
		String kafkaTopic = ProducerUtil.getRequiredEnv("TOPIC");
		String testTopic = ProducerUtil.getRequiredEnv("TESTTOPIC");
		String testString = ProducerUtil.getRequiredEnv("TESTSTRING");
		Producer<String, byte[]> producer = KafkaProducerService.getProducer();
		KafkaProducerService service = new KafkaProducerService(kafkaTopic, testTopic, testString);
		try {
			service.setSchema(schemapath);
			service.setProducer(producer);
		} catch (IOException e) {
			e.printStackTrace();
		}

		byte[] serializesDataAsByte = service.serializeProducerRecord(payload, "dummy", "dummy");

		DataFileStream<GenericRecord> dataFileReader = service.deserializeRecord(serializesDataAsByte);

		GenericRecord record = new GenericData.Record(dataFileReader.getSchema());
		
		while (dataFileReader.hasNext()) {
			GenericRecord y = dataFileReader.next(record);
			String bodyStr = y.get("payload").toString();
			assertEquals("this is test data", bodyStr);

		}
		dataFileReader.close();
	}
	
	
	
	@Test
	public void serializeProducerRecordTestWhenPayloadIsCorrectAndSchemaMatches() throws IOException, FHIRServiceException {
		String SCHEMAPATH  = "/com/cigna/fhir/fhir.avsc"; 
		KafkaProducerService service = new KafkaProducerService("dummy", "dummytest", "prod-canary-check");
		try {
			service.setSchema(SCHEMAPATH);
		} catch (IOException e) {
			e.printStackTrace();
		}
		byte[] dataBytes = service.serializeProducerRecord("this is the test payload", "dummy", "dummy");
		

		DataFileStream<GenericRecord> dataFileReader = service.deserializeRecord(dataBytes);

		GenericRecord record = new GenericData.Record(dataFileReader.getSchema());
		System.out.println("schema is --->" + dataFileReader.getSchema());
		
		while (dataFileReader.hasNext()) {
			GenericRecord recordValue = dataFileReader.next(record);
			String bodyStr = recordValue.get("payload").toString();
			assertEquals("this is the test payload", bodyStr);

		}
		dataFileReader.close();
		
		assertEquals("{\"type\":\"record\",\"name\":\"FHIR\",\"namespace\":\"com.cigna.v1_0\",\"fields\":[{\"name\":\"resourceType\",\"type\":\"string\"},{\"name\":\"payload\",\"type\":\"string\"},{\"name\":\"rcd_ty\",\"type\":\"string\"},{\"name\":\"dateCreated\",\"type\":\"string\"}]}", dataFileReader.getSchema().toString());
		
	}
	
	@Test
	public void serializeProducerRecordTestWhenSchemaDoesIsNotSet() throws IOException, FHIRServiceException {
        KafkaProducerService service = new KafkaProducerService("dummy", "dummytest", "prod-canary-check");
		try {
			byte[] dataBytes = service.serializeProducerRecord("this is the test payload", "dummy", "dummy");
		}catch(Exception e) {
			assertEquals("Not a record schema: null", e.getMessage());
		}
	}
	
	@Test
	public void serializeProducerRecordTestWhenSchemaIsBadDoesNotHavePayloadField() throws IOException, FHIRServiceException {
		String SCHEMAPATH  = "/com/cigna/fhir/bad_schema_fhir.avsc";
        KafkaProducerService service = new KafkaProducerService("dummy", "dummytest", "prod-canary-check");
		try {
			service.setSchema(SCHEMAPATH);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		try {
			byte[] dataBytes = service.serializeProducerRecord("this is the test payload", "dummy", "dummy");
		}catch(Exception e) {
			assert(e.getMessage().contains("Not a valid schema field:"));
		}
	}
	
	public static void main(String []args) throws EnvironmentVariableException, FHIRServiceException, IOException {
		ProducerUtil.setDefaultValueFlag(true);
		TestMessage() ;
		//SerializeDeserialize();
	}
	public static void TestMessage() throws EnvironmentVariableException, FHIRServiceException, IOException {
		ProducerUtil.setDefaultValueFlag(true);
		System.out.println(ProducerUtil.getDefaultValueFlag());
		
		final Map<String, String> messageAttributes = new HashMap<>();
		messageAttributes.put("nameva", "enc");
		SQSMessage message = new SQSMessage();
		message.setAttributes(messageAttributes);
		message.setBody("{\n" + "    \"contained\": [\n" + "        {\n"
				+ "            \"resourceType\": \"Organization\",\n"
				+ "            \"id\": \"a1289d72-12cb8-c123-bab2-60a365f4b4f1\",\n" + "            \"text\": {\n"
				+ "                \"status\": \"generated\",\n"
				+ "                \"div\": \"<div>My Location</div>\"\n" + "            },\n"
				+ "            \"identifier\": [\n" + "                {\n"
				+ "                    \"system\": \"http://collectivemedicaltech.com\",\n"
				+ "                    \"value\": \"a1289d72-12cb8-c123-bab2-60a365f4b4f1\"\n" + "                },\n"
				+ "                {\n" + "                    \"system\": \"NPI\",\n"
				+ "                    \"value\": \"23456548\"\n" + "                },\n" + "                {\n"
				+ "                    \"system\": \"TIN\",\n" + "                    \"value\": \"12565556\"\n"
				+ "                }\n" + "            ],\n" + "            \"name\": \"My Location\"\n"
				+ "        },\n" + "        {\n" + "            \"resourceType\": \"Patient\",\n"
				+ "            \"id\": \"88565412-0701-401b-9ef3-c17f2a345c67\",\n" + "            \"identifier\": [\n"
				+ "                {\n" + "                    \"use\": \"usual\",\n"
				+ "                    \"system\": \"http://collectivemedicaltech.com/\",\n"
				+ "                    \"value\": \"88565412-0701-401b-9ef3-c17f2a345c67\"\n" + "                },\n"
				+ "                {\n" + "                    \"use\": \"usual\",\n"
				+ "                    \"system\": \"medicaid\",\n" + "                    \"value\": \"WA789456554\"\n"
				+ "                }\n" + "            ],\n" + "            \"active\": true,\n"
				+ "            \"name\": [\n" + "                {\n" + "                    \"use\": \"usual\",\n"
				+ "                    \"family\": [\n" + "                        \"Arabia\"\n"
				+ "                    ],\n" + "                    \"given\": [\n"
				+ "                        \"Lawrence\"\n" + "                    ]\n" + "                }\n"
				+ "            ],\n" + "            \"telecom\": [\n" + "                {\n"
				+ "                    \"system\": \"phone\",\n" + "                    \"value\": \"8016667788\"\n"
				+ "                }\n" + "            ],\n" + "            \"gender\": \"male\",\n"
				+ "            \"birthDate\": \"2018-04-22\",\n" + "            \"deceasedBoolean\": false,\n"
				+ "            \"address\": [\n" + "                {\n" + "                    \"line\": [\n"
				+ "                        \"356 City St.\"\n" + "                    ],\n"
				+ "                    \"city\": \"Pasco\",\n" + "                    \"state\": \"WA\",\n"
				+ "                    \"postalCode\": \"94323\"\n" + "                }\n" + "            ]\n"
				+ "        }\n" + "    ],\n" + "    \"resourceType\": \"Encounter\",\n"
				+ "    \"status\": \"arrived\",\n" + "    \"identifier\": [\n" + "        {\n"
				+ "            \"system\": \"http://collectivemedicaltech.com/Encounter\",\n"
				+ "            \"use\": \"secondary\",\n"
				+ "            \"value\": \"1a5658d7-5555-401b-9ef3-ac3f29d145ac5\"\n" + "        },\n" + "        {\n"
				+ "            \"use\": \"temp\",\n" + "            \"value\": \"M1254789\"\n" + "        }\n"
				+ "    ],\n" + "    \"text\": {\n" + "        \"status\": \"generated\",\n"
				+ "        \"div\": \"<div>Patient had an Inpatient encounter at Valley Health Test Hospital</div>\"\n"
				+ "    },\n" + "    \"serviceProvider\": {\n"
				+ "        \"reference\": \"#1275cf1d-12cb8-c123-bab2-60a365f4b4f1\"\n" + "    },\n"
				+ "    \"subject\": {\n" + "        \"reference\": \"#1a5658d7-0701-401b-9ef3-c17f2a345c67\"\n"
				+ "    },\n" + "    \"class\": {\n"
				+ "        \"system\": \"http://collectivemedicaltech.com/Encounter\",\n" + "        \"code\": \"I\",\n"
				+ "        \"display\": \"Inpatient\"\n" + "    },\n" + "    \"period\": {\n"
				+ "        \"start\": \"2018-09-08T14:21:00-07:00\"\n" + "    },\n" + "    \"type\": [\n"
				+ "        {\n" + "            \"coding\": [\n" + "                {\n"
				+ "                    \"system\": \"http://collectivemedicaltech.com/Encounter\",\n"
				+ "                    \"code\": \"101\",\n" + "                    \"display\": \"Gastroenterology\"\n"
				+ "                }\n" + "            ]\n" + "        }\n" + "    ],\n" + "    \"reason\": [\n"
				+ "        {\n" + "            \"text\": \"Stomach Problems\"\n" + "        }\n" + "    ],\n"
				+ "      \"diagnosis\": [{\n" + "        \"sequence\": 1,\n" + "        \"diagnosis\": {\n"
				+ "            \"system\": \"http://hl7.org/fhir/sid/icd-10\",\n" + "            \"code\": \"K210\"\n"
				+ "        }\n" + "     }]\n" + "}");
		List<SQSMessage> records = new ArrayList<SQSMessage>();
		records.add(message);
		records.add(message);
		records.add(message);
		records.add(message);
		records.add(message);
		records.add(message);
		records.add(message);
		records.add(message);
		records.add(message);
		records.add(message);
		records.add(message);
		records.add(message);
		records.add(message);
		records.add(message);
		records.add(message);
		records.add(message);
		records.add(message);
		records.add(message);
		records.add(message);
		records.add(message);
		records.add(message);
		records.add(message);
		
		SQSEvent x = new SQSEvent();
		x.setRecords(records);

		Context ctx = null;

		ProcessSQSEvents y = new ProcessSQSEvents();
		y.handleRequest(x, ctx);

	}

}