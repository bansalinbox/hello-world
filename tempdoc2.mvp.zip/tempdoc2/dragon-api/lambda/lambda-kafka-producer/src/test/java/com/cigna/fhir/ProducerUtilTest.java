package com.cigna.fhir;

import static org.junit.Assert.assertEquals;

import java.io.File;

import org.junit.Test;

import com.cigna.exception.FHIRServiceException;

public class ProducerUtilTest {

	@Test
	public void EnvironmentVariableExceptionWhenVariableIsNotPresent() {
		try {
			ProducerUtil.getRequiredEnv("Test");
		} catch (Exception e) {
			assertEquals("Did not found the envrionment variableName Test", e.getMessage());
		}

	}

	@Test
	public void EnvironmentVariableExceptionWhenVariableIsEmpty() {
		try {
			ProducerUtil.getRequiredEnv(" ");
		} catch (Exception e) {
			assertEquals("Varible name can not be empty", e.getMessage());
		}

	}

//	@Test
//	public void fileInputAsStreamWhenPathIsCorrect() throws FHIRServiceException {
//
//		File jksPath = ProducerUtil.fileInputAsStream("fhir.avsc");
//		assertEquals(
//				"/fhir.avsc",
//				jksPath.getAbsolutePath());
//	}

}
