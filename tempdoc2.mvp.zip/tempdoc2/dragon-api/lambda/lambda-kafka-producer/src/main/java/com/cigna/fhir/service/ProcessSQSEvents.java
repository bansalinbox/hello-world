package com.cigna.fhir.service;

import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.time.Duration;
import java.time.Instant;
import java.util.Base64;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.services.secretsmanager.AWSSecretsManager;
import com.amazonaws.services.secretsmanager.AWSSecretsManagerClientBuilder;
import com.amazonaws.services.secretsmanager.model.GetSecretValueRequest;
import com.amazonaws.services.secretsmanager.model.GetSecretValueResult;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.amazonaws.services.lambda.runtime.events.SQSEvent.MessageAttribute;
import com.amazonaws.services.lambda.runtime.events.SQSEvent.SQSMessage;
import com.cigna.exception.EnvironmentVariableException;
import com.cigna.exception.FHIRServiceException;
import com.cigna.fhir.ProducerUtil;

public class ProcessSQSEvents {
//	static final Logger logger = LogManager.getLogger(ProcessSQSEvents.class);

    public ProcessSQSEvents() throws IOException, EnvironmentVariableException {
        initKerberosFile();
    }

    public Void handleRequest(SQSEvent input, Context context)
            throws EnvironmentVariableException, FHIRServiceException, IOException {
        System.out.println("Executing ProcessSQSEvents handler");
        ProcessSQSEventsHandler(input);
        System.out.println("return is executed");
        return null;
    }

    private void ProcessSQSEventsHandler(SQSEvent input)
            throws EnvironmentVariableException, FHIRServiceException, IOException {
        String schemapath = null;
        String kafkaTopic = null;
        String testTopic = null;
        String testString = null;
        String rcd_ty = null;
        int producerTimneout;

        producerTimneout = Integer.parseInt(ProducerUtil.getRequiredEnv("PRODUCERTIMEOUT"));
        schemapath = ProducerUtil.getRequiredEnv("SCHEMAPATH");
        kafkaTopic = ProducerUtil.getRequiredEnv("TOPIC");
        testTopic = ProducerUtil.getRequiredEnv("TESTTOPIC");
        testString = ProducerUtil.getRequiredEnv("TESTSTRING");
        rcd_ty = ProducerUtil.getRequiredEnv("RCD_TY");

        Producer<String, byte[]> producer = KafkaProducerService.getProducer();

        KafkaProducerService service = new KafkaProducerService(kafkaTopic, testTopic, testString);

        service.setSchema(schemapath);
        service.setProducer(producer);

        // TODo put the metrics for the record count and processing time
        try {
            Instant startTime = Instant.now();
            int count = 0;
            for (SQSMessage msg : input.getRecords()) {
                String resourceType = "";
                Map<String, MessageAttribute> attributes = msg.getMessageAttributes();
                if (attributes != null && !attributes.isEmpty()) {
                    MessageAttribute attribute = attributes.get("method");
                    if (attribute != null) {
                        resourceType = attribute.getStringValue();
                    } else {
                        System.out.println("Resource type cannot be null, it need to be correct at the api gateway level");
                    }
                }
                String sqsMessage = new String(msg.getBody());
                ProducerRecord<String, byte[]> record;
                record = service.produceKafkaRecord(sqsMessage, resourceType, rcd_ty);
                service.sendKafkaRecord(record);
                count++;
            }
            Instant endTime = Instant.now();
            long delta = Duration.between(startTime, endTime).toMillis();
            System.out.println("Processed " + count + " in " + delta + " milliseconds");
        } finally {
            if (producer != null) {
                producer.close(producerTimneout, TimeUnit.MILLISECONDS);
            }
        }
    }

    public static void initKerberosFile() throws IOException, EnvironmentVariableException {
        AWSSecretsManager awsSecretsManager;

        if (false) {
            ProfileCredentialsProvider profileCredentialsProvider = new ProfileCredentialsProvider("saml");
            awsSecretsManager =
                    AWSSecretsManagerClientBuilder.standard()
                            .withRegion("us-east-1")
                            .withCredentials(profileCredentialsProvider)
                            .build();
        } else {
            awsSecretsManager =
                    AWSSecretsManagerClientBuilder.defaultClient();
        }

        GetSecretValueResult getSecretValueResult =
                awsSecretsManager
                        .getSecretValue(
                                new GetSecretValueRequest()
                                        .withSecretId(ProducerUtil.getRequiredEnv("KEYTAB_SECRET_ARN")));

        byte[] decodedBinarySecret = Base64.getDecoder().decode(getSecretValueResult.getSecretString());

        FileChannel fc = new FileOutputStream(ProducerUtil.getRequiredEnv("SASL_KERBEROS_KEYTAB_LOC")).getChannel();
        fc.write(ByteBuffer.wrap(decodedBinarySecret));
        fc.close();
    }
}
