package com.cigna.fhir.service;

import com.cigna.exception.EnvironmentVariableException;
import com.cigna.exception.FHIRServiceException;
import com.cigna.fhir.ProducerUtil;
import org.apache.avro.Schema;
import org.apache.avro.file.DataFileStream;
import org.apache.avro.file.DataFileWriter;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericDatumReader;
import org.apache.avro.generic.GenericDatumWriter;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.io.DatumReader;
import org.apache.avro.io.DatumWriter;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.concurrent.ExecutionException;

public class KafkaProducerService {
    private Schema schema;
    private Producer<String, byte[]> producer;
    private String kafkaTopicName;
    private String testTopic;
    private String testString;

    public KafkaProducerService(String kafkaTopicName, String testTopic, String testString) {
        this.kafkaTopicName = kafkaTopicName;
        this.testTopic = testTopic;
        this.testString = testString;
    }

    public static Producer<String, byte[]> getProducer() throws EnvironmentVariableException, FHIRServiceException {
        Producer<String, byte[]> producer = KafkaProducerConfig.createProducer();
        return producer;
    }

    public void setProducer(Producer<String, byte[]> producer) throws IOException, FHIRServiceException {
        this.producer = producer;
    }

    public void setSchema(String schemapath) throws IOException, FHIRServiceException {
        this.schema = ProducerUtil.getSchema(schemapath);
    }

    public ProducerRecord<String, byte[]> produceKafkaRecord(String payload, String resourceType, String rcd_ty) throws IOException {
        String topicName = payload.indexOf(testString) > -1 ? testTopic : kafkaTopicName;
        ProducerRecord<String, byte[]> record = new ProducerRecord<String, byte[]>(topicName,
                serializeProducerRecord(payload, resourceType, rcd_ty));
        return record;
    }

    /**
     * Searialze the string payload using the schema object, it will throw runtime exception when schema is not set
     *
     * @param payload
     * @return
     * @throws IOException
     */
    public byte[] serializeProducerRecord(String payload, String resourceType, String rcd_ty) throws IOException {

        GenericData.Record record = new GenericData.Record(schema);
        record.put("payload", payload.toString());
        record.put("dateCreated", (new Date()).toInstant().toString());
        record.put("resourceType", resourceType);
        record.put("rcd_ty", rcd_ty);

        DatumWriter<GenericRecord> datumWriter = new GenericDatumWriter<GenericRecord>(schema);
        ByteArrayOutputStream stream = new ByteArrayOutputStream();

        DataFileWriter<GenericRecord> dataFileWriter = new DataFileWriter<GenericRecord>(datumWriter);
        dataFileWriter.create(schema, stream);
        dataFileWriter.append(record);
        dataFileWriter.close();

        return stream.toByteArray();
    }

    public void sendKafkaRecord(ProducerRecord<String, byte[]> record) throws IOException, FHIRServiceException {
        RecordMetadata metadata;
        try {


            metadata = producer.send(record).get();
            System.out.println("Record sent to partition " + metadata.partition() + " with offset "
                    + metadata.offset());
        } catch (InterruptedException e) {
            throw new FHIRServiceException("InterruptedException happened when getting the metadata of the sent data", e);
        } catch (ExecutionException e) {
            throw new FHIRServiceException("ExecutionException happened when sending the message to kafka", e);
        }
    }

    public DataFileStream<GenericRecord> deserializeRecord(byte[] value) throws FHIRServiceException {
        ByteArrayInputStream stream = new ByteArrayInputStream(value);
        DatumReader<GenericRecord> datumReader = new GenericDatumReader<GenericRecord>(schema);
        DataFileStream<GenericRecord> dataFileReader = null;
        try {
            dataFileReader = new DataFileStream<GenericRecord>(stream, datumReader);
        } catch (IOException e) {
            String msg = "Exception happened while deserializeRecord the record";
            throw new FHIRServiceException(msg, e);
        }
        return dataFileReader;

    }

}
