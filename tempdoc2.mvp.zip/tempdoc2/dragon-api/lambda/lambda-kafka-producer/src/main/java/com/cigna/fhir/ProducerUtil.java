package com.cigna.fhir;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.cigna.exception.EnvironmentVariableException;
import com.cigna.exception.FHIRServiceException;
import org.apache.avro.Schema;

import java.io.*;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

public class ProducerUtil {
    static boolean defaultValueFlag = false;

    public static boolean getDefaultValueFlag() {
        return defaultValueFlag;
    }

    public static void setDefaultValueFlag(boolean value) {
        ProducerUtil.defaultValueFlag = value;
    }

    public static Schema getSchema(String schemaPath) throws IOException, FHIRServiceException {
        return new Schema.Parser().parse(fileInputAsStream(schemaPath));
    }

    public static File fileInputAsStream(String filePath) throws FHIRServiceException {
        File input = null;
        Path path = null;
        try {
            path = Paths.get(ProducerUtil.class.getResource("/").toURI());
            System.out.println(path);
        } catch (URISyntaxException e) {
            throw new FHIRServiceException("Exception happened while getting the file path for " + filePath, e);
        }
        String resourceLoc = path + "/" + filePath;
        input = new File(resourceLoc);
        return input;
    }

    /**
     * It will return the environment variable and check if the returned value is
     * empty or not null.
     *
     * @param name
     * @return
     */
    public static String getRequiredEnv(String name) throws EnvironmentVariableException {
        // Dont Forgot to change to false in Production
        String value = "";
        if (name != null && !name.equals("") && !name.trim().equals("")) {
            String envValue = "";
            if (ProducerUtil.defaultValueFlag) {
                envValue = setDefaultValues(name);
            } else {
                envValue = System.getenv(name);
            }
            if (envValue == null) {
                String errorMessage = "Did not found the envrionment variableName " + name;
                throw new EnvironmentVariableException(errorMessage);
            } else {
                value = envValue;
            }
        } else {
            String errorMessage = "Varible name can not be empty";
            throw new EnvironmentVariableException(errorMessage);
        }
        return value;
    }

    /**
     * This method is used to run the command inside of lambda in cloud
     *
     * @throws IOException
     * @throws InterruptedException
     Used for testing purposes to determine what binaries existed in lambda.
    static void listFile() throws IOException, InterruptedException {
        System.out.println("this is executed");
        final Process p = Runtime.getRuntime().exec("ls -sh /tmp/onlyonetime/test7.keytab");

        new Thread(new Runnable() {
            public void run() {
                BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));
                String line = null;

                try {
                    while ((line = input.readLine()) != null) {
                        System.out.println("Start output from linus----->");
                        System.out.println(line);
                        System.out.println("End output from linus----->");
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();

        p.waitFor();

        System.out.println("END from linus----->");
    }
     */
    /**
     * This method is used to set the environment variable for local run
     *
     * @param name
     * @return
     */
    public static String setDefaultValues(String name) {
        String localPath = "/Users/m44164/Documents/cmt/dev/";
        Map<String, String> kafkaDefaultValues = new HashMap<String, String>();
        kafkaDefaultValues.put("BROKER_LIST", "cilhdkfs0304.sys.cigna.com:9095,cilhdkfs0305.sys.cigna.com:9095");
        kafkaDefaultValues.put("SASL_MECHANISM", "GSSAPI");
        kafkaDefaultValues.put("TOPIC", "kafka-produce-test8");
        kafkaDefaultValues.put("SECURITY_PROTOCOL", "SASL_SSL");
        kafkaDefaultValues.put("SASL_KERBEROS_KEYTAB_LOC", localPath + "rtdesvc-1.sys.keytab");
        kafkaDefaultValues.put("KRB5_CONFIG", "/com/cigna/fhir/krb5-dev.conf");
        kafkaDefaultValues.put("PRINCIPAL", "rtdesvc@SILVER.COM");
        kafkaDefaultValues.put("SCHEMAPATH", "/com/cigna/fhir/fhir.avsc");
        kafkaDefaultValues.put("JKSPATH", localPath + "Cigna-1.sys.jks");
        kafkaDefaultValues.put("PRODUCERTIMEOUT", "60000");
        kafkaDefaultValues.put("RCD_TY", "fhir_encounter");

        return kafkaDefaultValues.get(name);

    }

    private void CheckOrCreateFile() {
        File tmpFile = new File("/tmp/onlyonetime/test7.keytab");
        System.out.println("check the CheckOrCreateFile");
        try {
            String clientRegion = "us-east-1";
            String bucketName = "dragon-api-secrets-sys";
            String key = "rtdesvc-dev.keytab";
            // AmazonS3 s3 = AmazonS3ClientBuilder.standard()
            // .withRegion(clientRegion)
            // .withCredentials(new ProfileCredentialsProvider("saml"))
            // .build();
            AmazonS3 s3 = AmazonS3ClientBuilder.standard().withRegion(clientRegion)
                    // .withCredentials(new ProfileCredentialsProvider())
                    .build();

            S3Object o = s3.getObject(bucketName, key);
            S3ObjectInputStream s3is = o.getObjectContent();

            BufferedReader reader = new BufferedReader(new InputStreamReader(s3is));
            StringBuffer sbf = new StringBuffer();

            String line = null;
            while ((line = reader.readLine()) != null) {
                System.out.println("Able to read from s3");
                sbf.append(line);
                System.out.println(line);
            }

            Files.createDirectories(Paths.get("/tmp/onlyonetime"));
            FileOutputStream fos = new FileOutputStream(tmpFile);
            byte[] read_buf = new byte[1024];
            int read_len = 0;
            while ((read_len = s3is.read(read_buf)) > 0) {
                fos.write(read_buf, 0, read_len);
            }
            s3is.close();
            fos.close();
        } catch (AmazonServiceException e) {
            System.err.println(e.getErrorMessage());
            // System.exit(1);
        } catch (FileNotFoundException e) {
            System.err.println(e.getMessage());
            // System.exit(1);
        } catch (IOException e) {
            System.err.println(e.getMessage());
            // System.exit(1);
        }

        if (tmpFile.exists()) {
            System.out.println("File exists");
        } else {
            System.out.println("File does not exists");
        }

    }

}
