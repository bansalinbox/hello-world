import * as AWS from 'aws-sdk';

//Setup variables before any other module initializations
var credentials = new AWS.SharedIniFileCredentials({profile: 'saml'});
AWS.config.credentials = credentials;
process.env.API_VERSION = '2012-10-08';

import { cis } from "./handler";
import { SQSEvent } from "aws-lambda";
import {msg1, msg2} from "./spec/sampleData/data";
process.env.FOLDER_LOC = "encounter/v1/raw/cmt/";
process.env.BUCKET_LOC="cmt-glue-table";

// @ts-ignore
let payload:SQSEvent = <SQSEvent>{
  "Records": [
    {
      "messageId": "df7fa69c-a066-4789-b667-d716243a2bfe",
      "receiptHandle": "AQEBqD3NgKB/rUL7CoEjP0NCVMhAwgnY09lr4gZV9XYiZlLsBf7MUYVtm4SRT32H0l+JgBDAZrs235va1EIOO1mUDGHqS1SWEaWPBBG46N9QpjF4AgLj68LQy/vkAwmDx2T3KTY1dObFqITL5VFXctS1Xv9xENPgbtah3/UW64KE2yEJ+ZdbML3HvM8GsgfGcLsCInySDFpCb9citKow5GgsjdfaLgq0261ydEYTpHMIsfGnT2oPA7d6AJwAZFh4pz5XRDS8sooUoAUDvodq0di3X9cyNSG5dnu6P97aOGhbAL8Dwg/fql+snZSRcEn84JEiYWkC0goahBTZnacFb6C0oYihu8pVfD5EGNB0NHDKsKfN0BjZsFUpcMeW6yoCmghPt3kV/7XZlD0Q6wQ1DDSua+3dQsSEqt/YLn9XxhKXiQw=",
      "body": msg1,
      "attributes": {
        "ApproximateReceiveCount": "4",
        "SentTimestamp": "1560969494836",
        "SenderId": "AIDAIT2UOQQY3AUEKVGXU",
        "ApproximateFirstReceiveTimestamp": "1560969494836"
      },
      "messageAttributes": {
        "method": {
          "stringValue": "encounter",
          "dataType": "String"
        }
      },
      "md5OfBody": "0539cd0a534eefb71e2b757bd811ad7f",
      "eventSource": "aws:sqs",
      "eventSourceARN": "arn:aws:sqs:us-east-1:003856232118:fhir-exchange-storage-queue-sergii",
      "awsRegion": "us-east-1"
    }
  ]
}

cis(payload, {}, (arguments1) => {
  console.log(arguments1)
});
