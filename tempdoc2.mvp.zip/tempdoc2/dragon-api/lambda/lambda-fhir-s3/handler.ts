import {SQSEvent} from "aws-lambda";
import FHIRS3 from "./FHIRS3";

let handler = async (event: SQSEvent, context, callback) => {
  try{
    let fhirs3 = new FHIRS3();
    await fhirs3.handler(event, context, callback);
    callback(null, "Data has been uploaded successfully")
  }catch (e) {
    console.error('UNEXPECTED EXCEPTION HAPPENED');
    callback(e)
  }
}
export {handler as cis};
