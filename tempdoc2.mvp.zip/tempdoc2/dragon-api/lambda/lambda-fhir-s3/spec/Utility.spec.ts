import Utility, {StandardError} from "../src/Util/Utility";

describe('Search and return fields', function () {
  describe('check the valid month', function () {
    it('month range should be valid', async function () {
      let value = Utility.checkDateFormat("12", "01", 1990)
      expect(value).toEqual(true);
    });
    it('month range should be throw Exception', async function () {
      try{
        let value = Utility.checkDateFormat("16", "01", 1990)
      }catch (e) {
        expect(e.message).toEqual('16, 01, 1990 is not valid format : ');
      }
    });
  });


  describe('check the valid day', function () {
    it('day range should be throw Exception', async function () {
      try{
        let value = Utility.checkDateFormat("16", "32", 1990)
      }catch (e) {
        expect(e.message).toEqual('16, 32, 1990 is not valid format : ');
      }
    });
  });

  describe('check the valid year', function () {
    it('day range should be throw Exception', async function () {
      try{
        let value = Utility.checkDateFormat("16", "01", 990)
      }catch (e) {
        expect(e.message).toEqual('16, 01, 990 is not valid format : ');
      }
    });
  });
});

describe('Append 0, if day and month is of single digit', function () {
    it('should append 0 ', async function () {
      let value = Utility.checkDayOrMonthLength(1)
      expect(value).toEqual("01");
    });
  it('should not append 0 ', async function () {
    let value = Utility.checkDayOrMonthLength(12)
    expect(value).toEqual("12");
  });
});


describe('Able to parse and check if required attribute is present or not', function () {

  let jsonString  = `{"key1" : "value1", "key2" : "value2"}`

  it('return value of the attribute', async function () {
    let value = Utility.checkRequiredValue(jsonString, "key1")
    expect(value).toEqual("value1");
  });
  it('throw exception, if key not found', async function () {
    try{
      Utility.checkRequiredValue(jsonString, "key3")
    }catch (e) {
      expect(e.name).toEqual('DataError')
      expect(e.message).toEqual('key3 attribute not present : ')
    }
  });
});
