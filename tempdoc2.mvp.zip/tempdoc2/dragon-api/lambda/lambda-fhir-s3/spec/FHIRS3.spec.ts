import Utility from "../src/Util/Utility";
import FHIRS3 from "../FHIRS3";
import {msg1} from "./sampleData/data";


describe('Check if the file name and folder structure is created correctly', function () {
  it('return value of the attribute', async function () {
    process.env.FOLDER_LOC = "encounter/v1/raw/cmt/";
    process.env.BUCKET_LOC="cmt-glue-table";
    let fhirS3 = new FHIRS3();
    let value = fhirS3.buildFileName(msg1);
    expect(value).toEqual("encounter/v1/raw/cmt/year=2019/mon=07/day=16/427074_2019-07-16T18:01:01.306Z.json");
  });
});
