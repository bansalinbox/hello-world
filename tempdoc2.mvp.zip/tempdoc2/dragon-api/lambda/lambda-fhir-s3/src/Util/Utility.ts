import * as uuid from "uuid/v1";
import moment = require("moment");
import {bool} from "aws-sdk/clients/signer";

export default class Utility {

  /**
   * It will get called to generate UUID with the default folder path if there some issue in generating the file name from the payload
   * @returns {string}
   */
  public static generateUUIDKey() {
    return "year=9999/" + uuid() + ".json";
  }

  /**
   * Parse then return the requird attribute from JSON, throw exception id field is not present.
   * @param msgJSON
   * @param {string} field
   * @returns {any}
   */
  public static checkRequiredValue(msgJSON: any, field: string) {
    let value = JSON.parse(msgJSON)[field];
    if (!value) {
      let msg = field + " attribute not present";
      throw this.error(StandardError.DataError, msg, new Error());
    }
    return value;
  }

  /**
   * Reformat the exception to custom exception
   * @param {string} name
   * @param {string} message
   * @param {Error} err
   * @returns {Error}
   */
  public static error(name: string, message: string, err: Error) {
    let errStack = null;
    if (err != null) {
      if (err.stack != null) {
        errStack = err.stack;
      }
    }
    let e = new Error();
    e.name = name;
    e.message = message + ' : ' + err.message;
    e.stack = errStack;
    return e;
  }

  /**
   * To build the unity for the folder structure, it will check the date format and if day and month is not 2 digit, moment will throw the exception
   * @param {string} month
   * @param {string} day
   * @param {number} year
   * @returns {boolean}
   */
  public static checkDateFormat(month: string, day: string, year: number) : boolean{
    let isValid = true;
    let reformatDt = month + "/" + day + "/" + year
    if (!moment(reformatDt, 'MM/DD/YYYY', true).isValid()) {
      isValid = false;
      let msg = month + ", " + day + ", " + year + " is not valid format";
      throw this.error(StandardError.DataError, msg, new Error());
    }
    return isValid;
  }

  /**
   * To build the unity for the folder structure, it will convert single digit date and month to 2 digit value by appending 0 to it.
   * @param {number} key
   * @returns {string}
   */
  public static checkDayOrMonthLength(key : number) : string{
    let value : string;
    if(key){
      if(key.toString().length < 2){
        value = "0" + key.toString()
      }else{
        value = key.toString()
      }
    }
    return value;
  }

}

export enum StandardError {
  AWSError = 'AWSError',
  DataError = 'DataError'
}

