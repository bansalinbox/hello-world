import * as AWS from "aws-sdk";
import {SQSEvent} from "aws-lambda";
import {StandardError} from "./src/Util/Utility";
import Utility from "./src/Util/Utility";

export default class FHIRS3 {

  public async handler(event: SQSEvent, context, callback) {
    let noOfRecords = event.Records.length
    console.info("No of records in the request is " + noOfRecords)
    for (let i = 0; i < noOfRecords; i++) {
      let msgBody = event.Records[i].body;
      let bucketName = process.env.BUCKET_LOC;
      let fileName = this.buildFileName(msgBody);
      await this.uploadToS3(bucketName, fileName, msgBody);
    }
  }

  /**
   * It will build the file and folder name based on the cmtCreatedDt and EID.
   * If any of the required filed is not present or date is not in the correct format, then it will generate a uuid and save to default folder location.
   * @param msgJSON
   * @returns {string}
   */
  public buildFileName(msgJSON: any): string {
    console.info("Going to build the file name for the message")
    let baseFolder = process.env.FOLDER_LOC;
    let fileName;
    let partitionKey;
    let payloadName;
    try {
      let cmtCreatedDate = Utility.checkRequiredValue(msgJSON, "cmtCreatedDt")
      let eid = Utility.checkRequiredValue(msgJSON, "EID");
      let dt = new Date(cmtCreatedDate);
      let year = dt.getFullYear();
      let month = Utility.checkDayOrMonthLength(dt.getMonth() + 1); // month starts with 0
      let day = Utility.checkDayOrMonthLength(dt.getDate());
      Utility.checkDateFormat(month, day, year);
      payloadName = eid + "_" + cmtCreatedDate + ".json";
      partitionKey = "year=" + year + "/" + "mon=" + month + "/" + "day=" + day;
    } catch (e) {
      fileName = baseFolder + Utility.generateUUIDKey();
      let msg = "Error happened while trying to create a file name from the payload, going to save the message into the bucket with the file name " + fileName;
      console.error(Utility.error(StandardError.DataError, msg, new Error()));
      return fileName;
    }
    fileName = baseFolder + partitionKey + "/" + payloadName;
    return fileName;
  }

  /**
   * It will upload the json to the sepecified bucket name, folder inside the bucket are the part of the filename.
   * @param {string} bucketName
   * @param {string} fileName
   * @param {string} fileData
   * @returns {Promise<void>}
   */
  public async uploadToS3(bucketName: string, fileName: string, fileData: string) {
    var params = {Bucket: bucketName, Key: fileName, Body: fileData};
    var s3bucket = new AWS.S3();
    try {
      let upload = await s3bucket.upload(params).promise();
      console.info(upload);
    } catch (e) {
      let msg = "Exception happened while uploading the message to bucket"
      throw Utility.error(StandardError.AWSError, msg, e)
    }
  }

}

