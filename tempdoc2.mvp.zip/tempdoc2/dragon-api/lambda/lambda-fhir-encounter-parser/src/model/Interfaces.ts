export interface IMetadata {
  cohort?: string,
  userId?: string,
  correlationId?: string
}

export interface IPayload {
  payload: string
}

