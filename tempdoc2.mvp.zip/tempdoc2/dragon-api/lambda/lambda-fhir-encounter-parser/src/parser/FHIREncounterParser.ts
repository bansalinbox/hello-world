import * as AWS from "aws-sdk";
import { Utility } from "../Utility";
import { IMetadata } from "../model/Interfaces";
//import date from "date-and-time";
const date = require('date-and-time');

export default class FHIREncounterParser {

  /**
   * It is specific for the encounter message, it parse the message and reformat it to specific for the encounter need.
   * @param {string} message
   * @returns {Promise<string>}
   */
  public parseEncounterMsg(message: string, metadata: IMetadata): [string, EncounterRespMapping] {
    let encounterVal: Encounter;
    let organisationVal: Organisation;
    let practitionerVal: Practitioner;
    let patientVal: Patient;
    let encounterRespMapping: EncounterRespMapping;
    let cdeCreatedDate: string ;
    let eid: string;
    let rowKey: string;
    let trackingKey: string;
    let cohort: string = metadata.cohort;
    let user: string = metadata.userId;
    let correlationId: string = metadata.correlationId;

    try {
      let encObj: any = JSON.parse(message);
      encounterVal = this.parseEncounter(encObj);

      rowKey = this.getRowKey(encounterVal, "NA", "NA");
      trackingKey = this.getTrackingKey(encounterVal.cmtId, rowKey);

      let containedList = encObj.contained;
      for (let contained of containedList) {
        if (contained.resourceType == "Organization") {
          organisationVal = this.parseOrganization(contained, trackingKey);
        }
        if (contained.resourceType == "Practitioner") {
          practitionerVal = this.parsePractitioner(contained, trackingKey);
        }
        if (contained.resourceType == "Patient") {
          patientVal = this.parsePatient(contained, trackingKey);
        }
        if (contained.resourceType == "Provenance") {
          cdeCreatedDate = contained.recorded;
        }
      }
      eid = patientVal.EID;

      rowKey = this.getRowKey(encounterVal, eid, cdeCreatedDate);
      trackingKey = this.getTrackingKey(encounterVal.cmtId, rowKey);

      let currentTime = new Date().toISOString();

      // TODO: build the rowkey once we get the updated payload sample form cmt with eid.
      encounterRespMapping = {
        rowKey: rowKey,
        EID: eid,
        source: "cmt", // need to fix this, it should not be hard code
        correlationId: correlationId,
        cmtCreatedDt: cdeCreatedDate,
        cohort: cohort,
        user: user,
        createdDate: currentTime,
        lastUpdatedDate: currentTime,
        organization: organisationVal,
        patient: patientVal,
        practitioner: practitionerVal,
        encounter: encounterVal
      };
    } catch (Exception) {
      // will not throw the exception back, because we will print the exception and move on.
      let msg = `Exception happened while mapping the encounter objects, key: ${trackingKey}, rowKey: ${rowKey}`;
      console.error(msg);
      console.error(Exception)
      console.log('Sending to DLQ');
      this.sendDLQ(message,metadata);
      return [trackingKey, null];
    }
    if (eid && cdeCreatedDate && encounterVal.cmtId)
    {
      return [trackingKey, encounterRespMapping];
    }
    else
    {
      let msg = `Required field missing, key: ${trackingKey}, rowKey: ${rowKey}`;
      console.error(msg);
      console.log('Sending to DLQ');
      this.sendDLQ(message,metadata);
      return [trackingKey, null];
    }
  }

  /**
   * Extract the encounter information from the payload object
   * @param encObj
   * @returns {Encounter}
   */
  public parseEncounter(encObj: any): Encounter {
    let encounterMapping: Encounter;
    let encCmtId: string;
    let startDt: string;
    let endDt: string;
    try {
      if (encObj) {
        let encIdentifierList = encObj.identifier;
        encCmtId = this.searchAndReturnSys(encIdentifierList, "http://collectivemedicaltech.com/Encounter");
        let encTempValue: string = this.searchAndReturnUse(encIdentifierList, "temp");
        let periodExtList=encObj.period.extension
        let offsetVal :string = encObj.period.extension ? this.searchAndReturnUrl(periodExtList,"http://hl7.org/fhir/StructureDefinition/tz-offset"): undefined
        console.log("offset-> " + offsetVal)
        if(offsetVal)
        {
          startDt = encObj.period.start ? this.convertToUTC(encObj.period.start,offsetVal) : undefined;
          endDt = encObj.period.end ? this.convertToUTC(encObj.period.end,offsetVal) : undefined;
        }
        else
        {
          startDt = encObj.period.start ? encObj.period.start: undefined;
          endDt = encObj.period.end ? encObj.period.end: undefined;
        }
        let diagList = encObj.diagnosis ? this.getDiagnosisList(encObj.diagnosis) : undefined;
        let diagTypeList = encObj.diagnosis ? this.getDiagnosisTypeList(encObj.diagnosis) : undefined;

        encounterMapping = {
          cmtId: encCmtId,
          otherId: encTempValue, // check with Matt
          status: encObj.status,
          text: encObj.text ? encObj.text.div : undefined,
          provider: encObj.serviceProvider ? encObj.serviceProvider.reference : undefined,
          subject: encObj.subject ? encObj.subject.reference : undefined,
          classCode: encObj.class ? encObj.class.code : undefined,
          classDesc: encObj.class ? encObj.class.display : undefined,
          startDate: startDt,
          endDate: endDt,
          reason: encObj.reason ? (encObj.reason[0] ? encObj.reason[0].text : undefined) : undefined,
          diagnosisList: diagList,
          diagnosisTypeList: diagTypeList
        }
      } else {
        let msg = "It should not happened, encounter object can not be undefined"
        throw Utility.error(StandardError.EncParserError, msg, new Error());
      }
    } catch (error) {
      let msg = `Exception happened while parsing the Encounter object from the message, cmtId : ${encCmtId}`
      throw Utility.error(StandardError.EncParserError, msg, error);
    }
    return encounterMapping;
  }

  public getDiagnosisList(diagList : any) : string{
    let diagFullList : string = "";
    for(let diag of diagList){
      if(diag.diagnosis){
        let diagCode = diag.diagnosis.code;
        diagFullList = diagFullList + diagCode + " | "
      }
    }
    return diagFullList.substring(0, diagFullList.length - 3);
  }

  public getDiagnosisTypeList(diagList : any) : string{
    let diagTypeFullList : string = "";
    for(let diag of diagList){
      if(diag.diagnosis){
        let diagTypeCode = diag.diagnosis.system;
        diagTypeFullList = diagTypeFullList + diagTypeCode + " | "
      }
    }
    return diagTypeFullList.substring(0, diagTypeFullList.length - 3);
  }
  /**
   * Extract the organization related information from the encounter payload
   * @param org
   * @returns {Organisation}
   */
  public  parseOrganization(org: any, trackingKey: string) {
    let OrgMapping: Organisation;
    try {
      if (org) {
        let OrgIdentifierList = org.identifier;
        let npi = this.searchAndReturnSys(OrgIdentifierList, "NPI");
        let tin = this.searchAndReturnSys(OrgIdentifierList, "TIN");
        OrgMapping = {
          name: org.name,
          cmtId: org.id,
          npi: npi,
          tin: tin
        }
      } else {
        let msg = `It should not happened, Organisation object can not be undefined, key : ${trackingKey}`
        throw Utility.error(StandardError.EncParserError, msg, new Error());
      }
    } catch (error) {
      let msg = `Exception happened while parsing the Organisation object from the message, Key : ${trackingKey}`
      throw Utility.error(StandardError.EncParserError, msg, error);
    }
    return OrgMapping;
  }

  /**
   * Extract the patient related information from the encounter payload
   * @param patient
   * @returns {Patient}
   */
  public parsePatient(patient: any, trackingKey: string) {
    let patientMapping: Patient;
    let address: AddressHBase;
    try {
      if (patient) {
        let otherID = this.searchAndReturnSys(patient.identifier, "medicaid");
        let eid = this.searchAndReturnSys(patient.identifier, "EID");
        let humanName: HumanName[] = patient.name;
        let phoneValue =  this.searchAndReturnSys(patient.telecom, "phone");
        let patientAdd: Address[] = patient.address;
        if(patientAdd[0]){
          let add1 = patientAdd[0];

          address = {
            line1 : (add1.line) ? add1.line[0] : undefined,
            line2: (add1.line) ? add1.line[1] : undefined,
            city: add1.city,
            state: add1.state,
            zip: add1.postalCode
          }
        }
        patientMapping = {
          cmtId: patient.id,
          EID: eid,
          otherId: otherID,
          active: patient.active,
          gender: patient.gender,
          dob: patient.birthDate,
          deceased: patient.deceasedBoolean,
          firstName: (humanName) ? (humanName[0] ? (humanName[0].given) ? humanName[0].given[0] : undefined : undefined) : undefined,
          lastName: (humanName) ? (humanName[0] ? (humanName[0].family) ? humanName[0].family[0] : undefined : undefined) : undefined,
          phone: phoneValue,
          address: address
        }

      } else {
        let msg = `It should not happened, patient object can not be undefined, key : ${trackingKey}`;
        throw Utility.error(StandardError.EncParserError, msg, new Error());
      }
    } catch (error) {
      let msg = `Exception happened while parsing the patient object from the message, Key : ${trackingKey}`
      throw Utility.error(StandardError.EncParserError, msg, error);
    }
    return patientMapping;
  }

  /**
   * Extract the practitioner related information from the encounter payload
   * @param practitioner
   * @returns {Practitioner}
   */
  public parsePractitioner(practitioner: any, trackingKey: string) {
    let practitionerMapping: Practitioner;
    let address: AddressHBase;
    try {
      if (practitioner) {
        let cmtId = this.searchAndReturnSys(practitioner.identifier, "http://collectivemedicaltech.com");

        let humanName: HumanName[] = practitioner.name;
        let phoneValue =  this.searchAndReturnSys(practitioner.telecom, "phone");
        let practitionerAdd: Address[] = practitioner.address;
        if(practitionerAdd[0]){
          let add1 = practitionerAdd[0];

          address = {
            line1 : (add1.line) ? add1.line[0] : undefined,
            line2: (add1.line) ? add1.line[1] : undefined,
            city: add1.city,
            state: add1.state,
            zip: add1.postalCode
          }
        }
        practitionerMapping = {
          cmtId: cmtId,
          firstName: (humanName) ? (humanName[0] ? (humanName[0].given) ? humanName[0].given[0] : undefined : undefined) : undefined,
          lastName: (humanName) ? (humanName[0] ? (humanName[0].family) ? humanName[0].family[0] : undefined : undefined) : undefined,
          phone: phoneValue,
          address: address
        }

      } else {
        let msg = `It should not happened, practitioner object can not be undefined, key : ${trackingKey}`;
        throw Utility.error(StandardError.EncParserError, msg, new Error());
      }
    } catch (error) {
      let msg = `Exception happened while parsing the patient object from the message, Key : ${trackingKey}`
      throw Utility.error(StandardError.EncParserError, msg, error);
    }
    return practitionerMapping;
  }

  /**
   * It extract the "value" field value from the System tag in an array of Systems.
   * @param arrayKey
   * @param {string} lookupKey
   * @returns {any}
   */
  public searchAndReturnSys(arrayKey: any, lookupKey: string) {
    for (let key of arrayKey) {
      if (key.system == lookupKey) {
        return key.value;
      }
    }
  }

  /**
   * It extract the "value" field value from the use tag in an array of use.
   * @param arrayKey
   * @param {string} lookupKey
   * @returns {any}
   */
  public searchAndReturnUse(arrayKey: any, lookupKey: string) {
    for (let key of arrayKey) {
      if (key.use == lookupKey) {
        return key.value;
      }
    }
  }

   /**
   * It extract the "value" field value from the use tag in an array of use.
   * @param arrayKey
   * @param {string} lookupKey
   * @returns {any}
   */
  public searchAndReturnUrl(arrayKey: any, lookupKey: string) {
    for (let key of arrayKey) {
      if (key.url == lookupKey) {
        return key.valueString;
      }
    }
  }

  public getRowKey(encounterVal: Encounter, eid: string,cdeCreatedDate: string ): string {
    return `encounter#${eid}#${encounterVal.startDate}#${encounterVal.endDate}#${cdeCreatedDate}`;
  }

  public getTrackingKey(cmdID: string, rowKey: string) {
    return `${cmdID}#${rowKey}`
  }

  public convertToUTC(localDate: string, offsetVal: string): string {
    try {
      let convertToUtcTimeFlag = true;
      let parsedDate = date.parse(localDate, 'YYYY-MM-DD HH:mm:ss', convertToUtcTimeFlag);
      let offset: string[] = offsetVal.split(':'); // split it at the colons
      offset.length == 1 ? offset.push("00") : "";
      let offsetmilliseconds = (Number(offset[0]) * 3600 +
                                Number(offset[1]) * 60 * Math.sign(Number(offset[0]))) * 1000;
      let utcTime = date.addMilliseconds(parsedDate, -offsetmilliseconds).toISOString();
      return utcTime;
    } catch (e) {
      let msg = `Exception happened while converting to UTC-> '${localDate}' with offset-> '${offsetVal}'`;
      console.error(msg);
      console.log(e)
      // throw Utility.error(StandardError.DLQ_ERROR, msg, e)
    }
  }
  public async sendDLQ(payload: string ,metadata :IMetadata) {
    let queueUrl = process.env.DLQ_URL;
    //console.log(process.env.DLQ_URL)
    //console.log(payload)
    var sqs = new AWS.SQS();
    var params = {
      MessageBody: payload,
      MessageAttributes: {
        'cohort': {
            DataType: 'String',
            // BinaryValue: Buffer.from('...') || 'STRING_VALUE' /* Strings will be Base-64 encoded on your behalf */,
            StringValue: metadata.cohort
        },
        'authorization': {
            DataType: 'String',
            // BinaryValue: Buffer.from('...') || 'STRING_VALUE' /* Strings will be Base-64 encoded on your behalf */,
            StringValue: metadata.userId
        }
       },
      QueueUrl: queueUrl,
      DelaySeconds: 10
    };

    try {
      let upload = await sqs.sendMessage(params).promise();
      console.info(upload);
    } catch (e) {
      let msg = "Exception happened while sending data to DLQ"
      //console.log(e)
      //console.log(msg)
      throw Utility.error(StandardError.DLQ_ERROR, msg, e)
    }
  }
}

enum StandardError {
  EncProcessorError = 'EncProcessorError',
  EncParserError = 'EncParserError',
  DLQ_ERROR = 'DLQ_ERROR'
}
