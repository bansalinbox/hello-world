//THIS TS/JS FILE CAN BE USED FOR DEBUG WITH REAL DYNAMO_DB.
require("source-map-support").install();

import * as AWS from 'aws-sdk';

import {SQSEvent} from "aws-lambda";
import {testMessage} from "./spec/sampleData/data"
import {cis} from "./handler";

var credentials = new AWS.SharedIniFileCredentials({profile: 'saml'});
AWS.config.credentials = credentials;


// @ts-ignore
let payload2 = <SQSEvent>{
  "Records": [
    {
      "messageId": "5f0946e7-63ed-4c8f-a2bd-85e9b849a6c4",
      "receiptHandle": "AQEBTedn59z7UsXUXqoONO7jxGxKHJN0UO4iTMcw5iKSVE3AK2CEjEJwyBpQDGb1ERo81eHqjOIOpKd4z3RabGOQQFhyxjN4NfORrvLnHnDwxNt2LUU1iuDmPN5aXYUWMjFfrkX0coOM4L2b9UAYrCY+r383uk/wS3pa+n6fWanNItgdDSwSz76K3mHWKMlk2GIV6+MihV0kQEo9Ke91AgqnJ0GuYVZaK/t/ohDqYm5x1MocvC5Fdu5gQ/jkJW4X87SLDwXkqUqVZnmBxKkGpIhW2Gy3fTowilDttXrHZFWiI5NNJLX5suhIoCIM0E9+MV2sg3tarRX6z0X8gj14HlYH+ArSFCQMyoSuwk6cTiA4x14jVyB0MDsQ9b9BdgIRdOcYajdmdHA0z5mUCtwVBPR5cwDH1LtBDb8FWfPk6M9bmYY=",
      "body": "{\"contained\":[{\"resourceType\":\"Organization\",\"id\":\"12345\",\"text\":{\"status\":\"generated\",\"div\":\"<div>My Location</div>\"},\"identifier\":[{\"system\":\"http://collectivemedicaltech.com\",\"value\":\"12345\"},{\"system\":\"NPI\",\"value\":\"1234567890\"},{\"system\":\"TIN\",\"value\":\"\"}],\"name\":\"My Location\"},{\"resourceType\":\"Patient\",\"id\":\"028276a5-5657-48f4-89f6-f5a8s6c23fa1\",\"identifier\":[{\"use\":\"usual\",\"system\":\"http://collectivemedicaltech.com/\",\"value\":\"028276a5-56s7-48f4-89f6-f5a8b6c23fa1\"},{\"use\":\"usual\",\"system\":\"medicaid\",\"value\":\"\"},{\"use\":\"usual\",\"system\":\"EID\",\"value\":\"1122334455\"}],\"active\":true,\"name\":[{\"use\":\"usual\",\"family\":[\"SMITH\"],\"given\":[\"JOHN\"]}],\"telecom\":[{\"system\":\"phone\",\"value\":\"1234567890\"}],\"gender\":\"1\",\"birthDate\":\"1975-09-12\",\"deceasedBoolean\":false,\"address\":[{\"line\":[\"10831 MEADOW LN\"],\"city\":\"PHILADELPHIA\",\"state\":\"PA\",\"postalCode\":\"19154\"}]}],\"resourceType\":\"Encounter\",\"status\":\"arrived\",\"identifier\":[{\"system\":\"http://collectivemedicaltech.com/Encounter\",\"use\":\"secondary\",\"value\":\"56\"},{\"use\":\"temp\",\"value\":\"10987654321\"}],\"text\":{\"status\":\"generated\",\"div\":\"<div>Patient had an outpatient encounter at Providence Milwaukie Hospital</div>\"},\"serviceProvider\":{\"reference\":\"1234567890\"},\"subject\":{\"reference\":\"3\"},\"class\":{\"system\":\"http://collectivemedicaltech.com/Encounter\",\"code\":\"O\",\"display\":\"outpatient\"},\"period\":{\"start\":\"2018-12-14 09:57:33\"},\"type\":[{\"coding\":[{\"system\":\"http://collectivemedicaltech.com/Encounter\",\"code\":\"O\",\"display\":\"outpatient\"}]}],\"reason\":[{\"text\":\"haha33\"}],\"diagnosis\":[{\"sequence\":1,\"diagnosis\":{\"system\":\"http://hl7.org/fhir/sid/icd-10\",\"code\":\"Acute kidney failure, unspecified (HCC)\"}},{\"sequence\":2,\"diagnosis\":{\"system\":\"http://hl7.org/fhir/sid/icd-10\",\"code\":\"NKKK\"}}]}",
      "attributes": {
        "ApproximateReceiveCount": "1",
        "SentTimestamp": "1560977325388",
        "SenderId": "AIDAIT2UOQQY3AUEKVGXU",
        "ApproximateFirstReceiveTimestamp": "1560977325395"
      },
      "messageAttributes": {
        "authorization": {
          "stringValue": "eyJraWQiOiJ6SDFtQmIzOVF3SmtJUTZGWGI4NVwvUnZNcFVUZ3BDXC8rRWoxNGlwQzZrbVk9IiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiI1bmEzdHJmOHYwaW0xdWNxZW5hN2Q3dDdiMSIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoiZW5jb3VudGVyXC9wb3N0IiwiYXV0aF90aW1lIjoxNTYwOTc0ODE1LCJpc3MiOiJodHRwczpcL1wvY29nbml0by1pZHAudXMtZWFzdC0xLmFtYXpvbmF3cy5jb21cL3VzLWVhc3QtMV9JaEVONnliTTMiLCJleHAiOjE1NjA5Nzg0MTUsImlhdCI6MTU2MDk3NDgxNSwidmVyc2lvbiI6MiwianRpIjoiNWQ5ZDExNmEtZjM4ZC00YTE0LWJiZjMtYzA2M2JhMzYxMjE0IiwiY2xpZW50X2lkIjoiNW5hM3RyZjh2MGltMXVjcWVuYTdkN3Q3YjEifQ.QGvmbK6pF_2xocXD-jnicVJcjbcjUaDNPkchVQEFF1paGwaz3j-h4cm4zXwoeahBFbugpvx4KMBT3LfGvmrEFLC1lcZDCdjCCB34_SU8aCqIahMth4-TWwbs1eIAgkwdIh_l78_mNXCl6KY_U1XPN-ucrzGgQgfjv_TniO5sRE-2oBEAB8WSKqIJ6VfuBZlwNjl0kyXhDs0TsXphDakELBJ8I-3n9Iici_UL45payybA0lljcI0u73W2XeRBP9GJTMqonaeWMNId42tTnGVoxAz3OSSvFYdHqBOTXPfufRHx1rx8n4oq2u5Kj_rMJ9t7UxMtzrRugrX4OT04tVcq7w",
          "stringListValues": [],
          "binaryListValues": [],
          "dataType": "String"
        },
        "method": {
          "stringValue": "encounter",
          "stringListValues": [],
          "binaryListValues": [],
          "dataType": "String"
        },
        "cohort": {
          "stringValue": "default",
          "stringListValues": [],
          "binaryListValues": [],
          "dataType": "String"
        }
      },
      "md5OfBody": "2b7c8e97260aa7c07fd0579b01d20bf5",
      "eventSource": "aws:sqs",
      "eventSourceARN": "arn:aws:sqs:us-east-1:003856232118:fhir-exchange-storage-queue-sergii",
      "awsRegion": "us-east-1"
    },
    {
      "messageId": "5f0946e7-63ed-4c8f-a2bd-85e9b849a6c4",
      "receiptHandle": "AQEBTedn59z7UsXUXqoONO7jxGxKHJN0UO4iTMcw5iKSVE3AK2CEjEJwyBpQDGb1ERo81eHqjOIOpKd4z3RabGOQQFhyxjN4NfORrvLnHnDwxNt2LUU1iuDmPN5aXYUWMjFfrkX0coOM4L2b9UAYrCY+r383uk/wS3pa+n6fWanNItgdDSwSz76K3mHWKMlk2GIV6+MihV0kQEo9Ke91AgqnJ0GuYVZaK/t/ohDqYm5x1MocvC5Fdu5gQ/jkJW4X87SLDwXkqUqVZnmBxKkGpIhW2Gy3fTowilDttXrHZFWiI5NNJLX5suhIoCIM0E9+MV2sg3tarRX6z0X8gj14HlYH+ArSFCQMyoSuwk6cTiA4x14jVyB0MDsQ9b9BdgIRdOcYajdmdHA0z5mUCtwVBPR5cwDH1LtBDb8FWfPk6M9bmYY=",
      "body": "{\"contained\":[{\"resourceType\":\"Organization\",\"id\":\"12345\",\"text\":{\"status\":\"generated\",\"div\":\"<div>My Location</div>\"},\"identifier\":[{\"system\":\"http://collectivemedicaltech.com\",\"value\":\"12345\"},{\"system\":\"NPI\",\"value\":\"1234567890\"},{\"system\":\"TIN\",\"value\":\"\"}],\"name\":\"My Location\"},{\"resourceType\":\"Patient\",\"id\":\"028276a5-5657-48f4-89f6-f5a8s6c23fa1\",\"identifier\":[{\"use\":\"usual\",\"system\":\"http://collectivemedicaltech.com/\",\"value\":\"028276a5-56s7-48f4-89f6-f5a8b6c23fa1\"},{\"use\":\"usual\",\"system\":\"medicaid\",\"value\":\"\"},{\"use\":\"usual\",\"system\":\"EID\",\"value\":\"1122334455\"}],\"active\":true,\"name\":[{\"use\":\"usual\",\"family\":[\"SMITH\"],\"given\":[\"JOHN\"]}],\"telecom\":[{\"system\":\"phone\",\"value\":\"1234567890\"}],\"gender\":\"1\",\"birthDate\":\"1975-09-12\",\"deceasedBoolean\":false,\"address\":[{\"line\":[\"10831 MEADOW LN\"],\"city\":\"PHILADELPHIA\",\"state\":\"PA\",\"postalCode\":\"19154\"}]}],\"resourceType\":\"Encounter\",\"status\":\"arrived\",\"identifier\":[{\"system\":\"http://collectivemedicaltech.com/Encounter\",\"use\":\"secondary\",\"value\":\"56\"},{\"use\":\"temp\",\"value\":\"10987654321\"}],\"text\":{\"status\":\"generated\",\"div\":\"<div>Patient had an outpatient encounter at Providence Milwaukie Hospital</div>\"},\"serviceProvider\":{\"reference\":\"1234567890\"},\"subject\":{\"reference\":\"3\"},\"class\":{\"system\":\"http://collectivemedicaltech.com/Encounter\",\"code\":\"O\",\"display\":\"outpatient\"},\"period\":{\"start\":\"2018-12-14 09:57:33\"},\"type\":[{\"coding\":[{\"system\":\"http://collectivemedicaltech.com/Encounter\",\"code\":\"O\",\"display\":\"outpatient\"}]}],\"reason\":[{\"text\":\"haha33\"}],\"diagnosis\":[{\"sequence\":1,\"diagnosis\":{\"system\":\"http://hl7.org/fhir/sid/icd-10\",\"code\":\"Acute kidney failure, unspecified (HCC)\"}},{\"sequence\":2,\"diagnosis\":{\"system\":\"http://hl7.org/fhir/sid/icd-10\",\"code\":\"NKKK\"}}]}",
      "attributes": {
        "ApproximateReceiveCount": "1",
        "SentTimestamp": "1560977325388",
        "SenderId": "AIDAIT2UOQQY3AUEKVGXU",
        "ApproximateFirstReceiveTimestamp": "1560977325395"
      },
      "messageAttributes": {
        "authorization": {
          "stringValue": "eyJraWQiOiJ6SDFtQmIzOVF3SmtJUTZGWGI4NVwvUnZNcFVUZ3BDXC8rRWoxNGlwQzZrbVk9IiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiI1bmEzdHJmOHYwaW0xdWNxZW5hN2Q3dDdiMSIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoiZW5jb3VudGVyXC9wb3N0IiwiYXV0aF90aW1lIjoxNTYwOTc0ODE1LCJpc3MiOiJodHRwczpcL1wvY29nbml0by1pZHAudXMtZWFzdC0xLmFtYXpvbmF3cy5jb21cL3VzLWVhc3QtMV9JaEVONnliTTMiLCJleHAiOjE1NjA5Nzg0MTUsImlhdCI6MTU2MDk3NDgxNSwidmVyc2lvbiI6MiwianRpIjoiNWQ5ZDExNmEtZjM4ZC00YTE0LWJiZjMtYzA2M2JhMzYxMjE0IiwiY2xpZW50X2lkIjoiNW5hM3RyZjh2MGltMXVjcWVuYTdkN3Q3YjEifQ.QGvmbK6pF_2xocXD-jnicVJcjbcjUaDNPkchVQEFF1paGwaz3j-h4cm4zXwoeahBFbugpvx4KMBT3LfGvmrEFLC1lcZDCdjCCB34_SU8aCqIahMth4-TWwbs1eIAgkwdIh_l78_mNXCl6KY_U1XPN-ucrzGgQgfjv_TniO5sRE-2oBEAB8WSKqIJ6VfuBZlwNjl0kyXhDs0TsXphDakELBJ8I-3n9Iici_UL45payybA0lljcI0u73W2XeRBP9GJTMqonaeWMNId42tTnGVoxAz3OSSvFYdHqBOTXPfufRHx1rx8n4oq2u5Kj_rMJ9t7UxMtzrRugrX4OT04tVcq7w",
          "stringListValues": [],
          "binaryListValues": [],
          "dataType": "String"
        },
        "method": {
          "stringValue": "encounter",
          "stringListValues": [],
          "binaryListValues": [],
          "dataType": "String"
        },
        "cohort": {
          "stringValue": "default",
          "stringListValues": [],
          "binaryListValues": [],
          "dataType": "String"
        }
      },
      "md5OfBody": "2b7c8e97260aa7c07fd0579b01d20bf5",
      "eventSource": "aws:sqs",
      "eventSourceARN": "arn:aws:sqs:us-east-1:003856232118:fhir-exchange-storage-queue-sergii",
      "awsRegion": "us-east-1"
    },
    {
      "messageId": "5f0946e7-63ed-4c8f-a2bd-85e9b849a6c4",
      "receiptHandle": "AQEBTedn59z7UsXUXqoONO7jxGxKHJN0UO4iTMcw5iKSVE3AK2CEjEJwyBpQDGb1ERo81eHqjOIOpKd4z3RabGOQQFhyxjN4NfORrvLnHnDwxNt2LUU1iuDmPN5aXYUWMjFfrkX0coOM4L2b9UAYrCY+r383uk/wS3pa+n6fWanNItgdDSwSz76K3mHWKMlk2GIV6+MihV0kQEo9Ke91AgqnJ0GuYVZaK/t/ohDqYm5x1MocvC5Fdu5gQ/jkJW4X87SLDwXkqUqVZnmBxKkGpIhW2Gy3fTowilDttXrHZFWiI5NNJLX5suhIoCIM0E9+MV2sg3tarRX6z0X8gj14HlYH+ArSFCQMyoSuwk6cTiA4x14jVyB0MDsQ9b9BdgIRdOcYajdmdHA0z5mUCtwVBPR5cwDH1LtBDb8FWfPk6M9bmYY=",
      "body": "{\"contained\":[{\"resourceType\":\"Organization\",\"id\":\"12345\",\"text\":{\"status\":\"generated\",\"div\":\"<div>My Location</div>\"},\"identifier\":[{\"system\":\"http://collectivemedicaltech.com\",\"value\":\"12345\"},{\"system\":\"NPI\",\"value\":\"1234567890\"},{\"system\":\"TIN\",\"value\":\"\"}],\"name\":\"My Location\"},{\"resourceType\":\"Patient\",\"id\":\"028276a5-5657-48f4-89f6-f5a8s6c23fa1\",\"identifier\":[{\"use\":\"usual\",\"system\":\"http://collectivemedicaltech.com/\",\"value\":\"028276a5-56s7-48f4-89f6-f5a8b6c23fa1\"},{\"use\":\"usual\",\"system\":\"medicaid\",\"value\":\"\"},{\"use\":\"usual\",\"system\":\"EID\",\"value\":\"1122334455\"}],\"active\":true,\"name\":[{\"use\":\"usual\",\"family\":[\"SMITH\"],\"given\":[\"JOHN\"]}],\"telecom\":[{\"system\":\"phone\",\"value\":\"1234567890\"}],\"gender\":\"1\",\"birthDate\":\"1975-09-12\",\"deceasedBoolean\":false,\"address\":[{\"line\":[\"10831 MEADOW LN\"],\"city\":\"PHILADELPHIA\",\"state\":\"PA\",\"postalCode\":\"19154\"}]}],\"resourceType\":\"Encounter\",\"status\":\"arrived\",\"identifier\":[{\"system\":\"http://collectivemedicaltech.com/Encounter\",\"use\":\"secondary\",\"value\":\"56\"},{\"use\":\"temp\",\"value\":\"10987654321\"}],\"text\":{\"status\":\"generated\",\"div\":\"<div>Patient had an outpatient encounter at Providence Milwaukie Hospital</div>\"},\"serviceProvider\":{\"reference\":\"1234567890\"},\"subject\":{\"reference\":\"3\"},\"class\":{\"system\":\"http://collectivemedicaltech.com/Encounter\",\"code\":\"O\",\"display\":\"outpatient\"},\"period\":{\"start\":\"2018-12-14 09:57:33\"},\"type\":[{\"coding\":[{\"system\":\"http://collectivemedicaltech.com/Encounter\",\"code\":\"O\",\"display\":\"outpatient\"}]}],\"reason\":[{\"text\":\"haha33\"}],\"diagnosis\":[{\"sequence\":1,\"diagnosis\":{\"system\":\"http://hl7.org/fhir/sid/icd-10\",\"code\":\"Acute kidney failure, unspecified (HCC)\"}},{\"sequence\":2,\"diagnosis\":{\"system\":\"http://hl7.org/fhir/sid/icd-10\",\"code\":\"NKKK\"}}]}",
      "attributes": {
        "ApproximateReceiveCount": "1",
        "SentTimestamp": "1560977325388",
        "SenderId": "AIDAIT2UOQQY3AUEKVGXU",
        "ApproximateFirstReceiveTimestamp": "1560977325395"
      },
      "messageAttributes": {
        "authorization": {
          "stringValue": "eyJraWQiOiJ6SDFtQmIzOVF3SmtJUTZGWGI4NVwvUnZNcFVUZ3BDXC8rRWoxNGlwQzZrbVk9IiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiI1bmEzdHJmOHYwaW0xdWNxZW5hN2Q3dDdiMSIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoiZW5jb3VudGVyXC9wb3N0IiwiYXV0aF90aW1lIjoxNTYwOTc0ODE1LCJpc3MiOiJodHRwczpcL1wvY29nbml0by1pZHAudXMtZWFzdC0xLmFtYXpvbmF3cy5jb21cL3VzLWVhc3QtMV9JaEVONnliTTMiLCJleHAiOjE1NjA5Nzg0MTUsImlhdCI6MTU2MDk3NDgxNSwidmVyc2lvbiI6MiwianRpIjoiNWQ5ZDExNmEtZjM4ZC00YTE0LWJiZjMtYzA2M2JhMzYxMjE0IiwiY2xpZW50X2lkIjoiNW5hM3RyZjh2MGltMXVjcWVuYTdkN3Q3YjEifQ.QGvmbK6pF_2xocXD-jnicVJcjbcjUaDNPkchVQEFF1paGwaz3j-h4cm4zXwoeahBFbugpvx4KMBT3LfGvmrEFLC1lcZDCdjCCB34_SU8aCqIahMth4-TWwbs1eIAgkwdIh_l78_mNXCl6KY_U1XPN-ucrzGgQgfjv_TniO5sRE-2oBEAB8WSKqIJ6VfuBZlwNjl0kyXhDs0TsXphDakELBJ8I-3n9Iici_UL45payybA0lljcI0u73W2XeRBP9GJTMqonaeWMNId42tTnGVoxAz3OSSvFYdHqBOTXPfufRHx1rx8n4oq2u5Kj_rMJ9t7UxMtzrRugrX4OT04tVcq7w",
          "stringListValues": [],
          "binaryListValues": [],
          "dataType": "String"
        },
        "method": {
          "stringValue": "encounter",
          "stringListValues": [],
          "binaryListValues": [],
          "dataType": "String"
        },
        "cohort": {
          "stringValue": "default",
          "stringListValues": [],
          "binaryListValues": [],
          "dataType": "String"
        }
      },
      "md5OfBody": "2b7c8e97260aa7c07fd0579b01d20bf5",
      "eventSource": "aws:sqs",
      "eventSourceARN": "arn:aws:sqs:us-east-1:003856232118:fhir-exchange-storage-queue-sergii",
      "awsRegion": "us-east-1"
    },
    {
      "messageId": "5f0946e7-63ed-4c8f-a2bd-85e9b849a6c4",
      "receiptHandle": "AQEBTedn59z7UsXUXqoONO7jxGxKHJN0UO4iTMcw5iKSVE3AK2CEjEJwyBpQDGb1ERo81eHqjOIOpKd4z3RabGOQQFhyxjN4NfORrvLnHnDwxNt2LUU1iuDmPN5aXYUWMjFfrkX0coOM4L2b9UAYrCY+r383uk/wS3pa+n6fWanNItgdDSwSz76K3mHWKMlk2GIV6+MihV0kQEo9Ke91AgqnJ0GuYVZaK/t/ohDqYm5x1MocvC5Fdu5gQ/jkJW4X87SLDwXkqUqVZnmBxKkGpIhW2Gy3fTowilDttXrHZFWiI5NNJLX5suhIoCIM0E9+MV2sg3tarRX6z0X8gj14HlYH+ArSFCQMyoSuwk6cTiA4x14jVyB0MDsQ9b9BdgIRdOcYajdmdHA0z5mUCtwVBPR5cwDH1LtBDb8FWfPk6M9bmYY=",
      "body": "{\"contained\":[{\"resourceType\":\"Organization\",\"id\":\"12345\",\"text\":{\"status\":\"generated\",\"div\":\"<div>My Location</div>\"},\"identifier\":[{\"system\":\"http://collectivemedicaltech.com\",\"value\":\"12345\"},{\"system\":\"NPI\",\"value\":\"1234567890\"},{\"system\":\"TIN\",\"value\":\"\"}],\"name\":\"My Location\"},{\"resourceType\":\"Patient\",\"id\":\"028276a5-5657-48f4-89f6-f5a8s6c23fa1\",\"identifier\":[{\"use\":\"usual\",\"system\":\"http://collectivemedicaltech.com/\",\"value\":\"028276a5-56s7-48f4-89f6-f5a8b6c23fa1\"},{\"use\":\"usual\",\"system\":\"medicaid\",\"value\":\"\"},{\"use\":\"usual\",\"system\":\"EID\",\"value\":\"1122334455\"}],\"active\":true,\"name\":[{\"use\":\"usual\",\"family\":[\"SMITH\"],\"given\":[\"JOHN\"]}],\"telecom\":[{\"system\":\"phone\",\"value\":\"1234567890\"}],\"gender\":\"1\",\"birthDate\":\"1975-09-12\",\"deceasedBoolean\":false,\"address\":[{\"line\":[\"10831 MEADOW LN\"],\"city\":\"PHILADELPHIA\",\"state\":\"PA\",\"postalCode\":\"19154\"}]}],\"resourceType\":\"Encounter\",\"status\":\"arrived\",\"identifier\":[{\"system\":\"http://collectivemedicaltech.com/Encounter\",\"use\":\"secondary\",\"value\":\"56\"},{\"use\":\"temp\",\"value\":\"10987654321\"}],\"text\":{\"status\":\"generated\",\"div\":\"<div>Patient had an outpatient encounter at Providence Milwaukie Hospital</div>\"},\"serviceProvider\":{\"reference\":\"1234567890\"},\"subject\":{\"reference\":\"3\"},\"class\":{\"system\":\"http://collectivemedicaltech.com/Encounter\",\"code\":\"O\",\"display\":\"outpatient\"},\"period\":{\"start\":\"2018-12-14 09:57:33\"},\"type\":[{\"coding\":[{\"system\":\"http://collectivemedicaltech.com/Encounter\",\"code\":\"O\",\"display\":\"outpatient\"}]}],\"reason\":[{\"text\":\"haha33\"}],\"diagnosis\":[{\"sequence\":1,\"diagnosis\":{\"system\":\"http://hl7.org/fhir/sid/icd-10\",\"code\":\"Acute kidney failure, unspecified (HCC)\"}},{\"sequence\":2,\"diagnosis\":{\"system\":\"http://hl7.org/fhir/sid/icd-10\",\"code\":\"NKKK\"}}]}",
      "attributes": {
        "ApproximateReceiveCount": "1",
        "SentTimestamp": "1560977325388",
        "SenderId": "AIDAIT2UOQQY3AUEKVGXU",
        "ApproximateFirstReceiveTimestamp": "1560977325395"
      },
      "messageAttributes": {
        "authorization": {
          "stringValue": "eyJraWQiOiJ6SDFtQmIzOVF3SmtJUTZGWGI4NVwvUnZNcFVUZ3BDXC8rRWoxNGlwQzZrbVk9IiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiI1bmEzdHJmOHYwaW0xdWNxZW5hN2Q3dDdiMSIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoiZW5jb3VudGVyXC9wb3N0IiwiYXV0aF90aW1lIjoxNTYwOTc0ODE1LCJpc3MiOiJodHRwczpcL1wvY29nbml0by1pZHAudXMtZWFzdC0xLmFtYXpvbmF3cy5jb21cL3VzLWVhc3QtMV9JaEVONnliTTMiLCJleHAiOjE1NjA5Nzg0MTUsImlhdCI6MTU2MDk3NDgxNSwidmVyc2lvbiI6MiwianRpIjoiNWQ5ZDExNmEtZjM4ZC00YTE0LWJiZjMtYzA2M2JhMzYxMjE0IiwiY2xpZW50X2lkIjoiNW5hM3RyZjh2MGltMXVjcWVuYTdkN3Q3YjEifQ.QGvmbK6pF_2xocXD-jnicVJcjbcjUaDNPkchVQEFF1paGwaz3j-h4cm4zXwoeahBFbugpvx4KMBT3LfGvmrEFLC1lcZDCdjCCB34_SU8aCqIahMth4-TWwbs1eIAgkwdIh_l78_mNXCl6KY_U1XPN-ucrzGgQgfjv_TniO5sRE-2oBEAB8WSKqIJ6VfuBZlwNjl0kyXhDs0TsXphDakELBJ8I-3n9Iici_UL45payybA0lljcI0u73W2XeRBP9GJTMqonaeWMNId42tTnGVoxAz3OSSvFYdHqBOTXPfufRHx1rx8n4oq2u5Kj_rMJ9t7UxMtzrRugrX4OT04tVcq7w",
          "stringListValues": [],
          "binaryListValues": [],
          "dataType": "String"
        },
        "method": {
          "stringValue": "encounter",
          "stringListValues": [],
          "binaryListValues": [],
          "dataType": "String"
        },
        "cohort": {
          "stringValue": "default",
          "stringListValues": [],
          "binaryListValues": [],
          "dataType": "String"
        }
      },
      "md5OfBody": "2b7c8e97260aa7c07fd0579b01d20bf5",
      "eventSource": "aws:sqs",
      "eventSourceARN": "arn:aws:sqs:us-east-1:003856232118:fhir-exchange-storage-queue-sergii",
      "awsRegion": "us-east-1"
    }
  ]
};

let payload = <SQSEvent>{
  Records:
    [{
      messageId: '04846962-ea9e-4213-abd9-2cc192be44fe',
      receiptHandle: 'AQEB3LRuRkHE9lESgn3a7QXBrO+I69KkaK1w3lFi44+OjZOVP5NZWiJ5SwCildMWdCuITdCAHZYV1MPO6OeSo4qJVgrtvMI4QqnWmCxSq5fWw9ctgJZPY3YMmeu56exnUmnUP3/hq0iDgOLTUnKLRfbgMtwzgY/AnMZU5bAuKJX+dZN7qMu15fkzYn8BCKjOr+A+6SEHSMvXjH9OEkhEW4VDYMOZzq/PPFzNCtRx8oAhiJkVKfJ9KELnSgIHIUUyiObhh8PheQ2LmtFHJDjuKrRglx4c2+7HsnUPQFDkNbFdIDsi6FgDSCFwhl+D9iSlJX113DDuu+hIOsvttNF4gJISxHC1klsFahiheYkJQ8KuD/iUZ9H55L53WCuhuoBZCIWkzr32HQ5A1HxstfyEFSem1u6YlxaCd50jwt7baO6cSGM=',
      body: testMessage,
      attributes: {},
      messageAttributes: {},
      md5OfBody: '6379edbbbf0b726f9f9e0d2a477404f2',
      eventSource: 'aws:sqs',
      eventSourceARN: 'arn:aws:sqs:us-east-1:003856232118:fhir-exchange-storage-queue',
      awsRegion: 'us-east-1'
    }
      // ,{ messageId: '04846962-ea9e-4213-abd9-2cc192be44fe',
      //   receiptHandle: 'AQEB3LRuRkHE9lESgn3a7QXBrO+I69KkaK1w3lFi44+OjZOVP5NZWiJ5SwCildMWdCuITdCAHZYV1MPO6OeSo4qJVgrtvMI4QqnWmCxSq5fWw9ctgJZPY3YMmeu56exnUmnUP3/hq0iDgOLTUnKLRfbgMtwzgY/AnMZU5bAuKJX+dZN7qMu15fkzYn8BCKjOr+A+6SEHSMvXjH9OEkhEW4VDYMOZzq/PPFzNCtRx8oAhiJkVKfJ9KELnSgIHIUUyiObhh8PheQ2LmtFHJDjuKrRglx4c2+7HsnUPQFDkNbFdIDsi6FgDSCFwhl+D9iSlJX113DDuu+hIOsvttNF4gJISxHC1klsFahiheYkJQ8KuD/iUZ9H55L53WCuhuoBZCIWkzr32HQ5A1HxstfyEFSem1u6YlxaCd50jwt7baO6cSGM=',
      //   body: msg2,
      //   attributes: {},
      //   messageAttributes: {},
      //   md5OfBody: '6379edbbbf0b726f9f9e0d2a477404f2',
      //   eventSource: 'aws:sqs',
      //   eventSourceARN: 'arn:aws:sqs:us-east-1:003856232118:fhir-exchange-storage-queue',
      //   awsRegion: 'us-east-1' }
      // ,{ messageId: '04846962-ea9e-4213-abd9-2cc192be44fe',
      //   receiptHandle: 'AQEB3LRuRkHE9lESgn3a7QXBrO+I69KkaK1w3lFi44+OjZOVP5NZWiJ5SwCildMWdCuITdCAHZYV1MPO6OeSo4qJVgrtvMI4QqnWmCxSq5fWw9ctgJZPY3YMmeu56exnUmnUP3/hq0iDgOLTUnKLRfbgMtwzgY/AnMZU5bAuKJX+dZN7qMu15fkzYn8BCKjOr+A+6SEHSMvXjH9OEkhEW4VDYMOZzq/PPFzNCtRx8oAhiJkVKfJ9KELnSgIHIUUyiObhh8PheQ2LmtFHJDjuKrRglx4c2+7HsnUPQFDkNbFdIDsi6FgDSCFwhl+D9iSlJX113DDuu+hIOsvttNF4gJISxHC1klsFahiheYkJQ8KuD/iUZ9H55L53WCuhuoBZCIWkzr32HQ5A1HxstfyEFSem1u6YlxaCd50jwt7baO6cSGM=',
      //   body: testMessage,
      //   attributes: {},
      //   messageAttributes: {},
      //   md5OfBody: '6379edbbbf0b726f9f9e0d2a477404f2',
      //   eventSource: 'aws:sqs',
      //   eventSourceARN: 'arn:aws:sqs:us-east-1:003856232118:fhir-exchange-storage-queue',
      //   awsRegion: 'us-east-1' }
    ]
};

// let obj = new FHIRProcessor();
// obj.handler(payload, {},  (arguments1) => {
//    console.log("Call back results : ",arguments1)
//  });

let payload3 = {
  "Records": [
    {
      "messageId": "5f0946e7-63ed-4c8f-a2bd-85e9b849a6c4",
      "receiptHandle": "AQEBTedn59z7UsXUXqoONO7jxGxKHJN0UO4iTMcw5iKSVE3AK2CEjEJwyBpQDGb1ERo81eHqjOIOpKd4z3RabGOQQFhyxjN4NfORrvLnHnDwxNt2LUU1iuDmPN5aXYUWMjFfrkX0coOM4L2b9UAYrCY+r383uk/wS3pa+n6fWanNItgdDSwSz76K3mHWKMlk2GIV6+MihV0kQEo9Ke91AgqnJ0GuYVZaK/t/ohDqYm5x1MocvC5Fdu5gQ/jkJW4X87SLDwXkqUqVZnmBxKkGpIhW2Gy3fTowilDttXrHZFWiI5NNJLX5suhIoCIM0E9+MV2sg3tarRX6z0X8gj14HlYH+ArSFCQMyoSuwk6cTiA4x14jVyB0MDsQ9b9BdgIRdOcYajdmdHA0z5mUCtwVBPR5cwDH1LtBDb8FWfPk6M9bmYY=",
      "body": "{\"contained\":[{\"resourceType\":\"Provenance\",\"recorded\":\"2019-08-07T14:49:44Z\"},{\"resourceType\":\"Organization\",\"id\":\"3f041b11-d3ae-46c5-a9d6-4f4349aca609\",\"text\":{\"status\":\"generated\",\"div\":\"<div>My Location</div>\"},\"identifier\":[{\"system\":\"org_cmt_id\",\"value\":\"wa_tst_facility\"},{\"system\":\"org_name\",\"value\":\"Testing Hospital\"},{\"system\":\"http://collectivemedicaltech.com\",\"value\":\"3f041b11-d3ae-46c5-a9d6-4f4349aca609\"},{\"system\":\"NPI\",\"value\":\"\"},{\"system\":\"TIN\",\"value\":\"\"}],\"name\":\"My Location\"},{\"resourceType\":\"Practitioner\",\"identifier\":[{\"system\":\"http://collectivemedicaltech.com\",\"value\":\"ac1e46a1-082b-4789-97e0-fee91b245d3e\"},{\"system\":\"NPI\",\"value\":\"x1234567-xxxx-1111-1987654bc123456\"}],\"name\":[{\"use\":\"usual\",\"family\":[\"DUCK\"],\"given\":[\"DONALD\"]}],\"telecom\":[{\"system\":\"phone\",\"value\":\"8675309\"}],\"address\":[{\"line\":[\"3434 Market St\"],\"city\":\"PHILADELPHIA\",\"state\":\"PA\",\"postalCode\":\"19113\"}]},{\"resourceType\":\"Patient\",\"id\":\"bb2ddddd-1824-403a-b267-daf1cf11aa11\",\"identifier\":[{\"use\":\"usual\",\"system\":\"http://collectivemedicaltech.com/\",\"value\":\"bb2ddddd-1824-403a-b267-daf1cf11aa11\"},{\"use\":\"usual\",\"system\":\"medicaid\",\"value\":\"\"},{\"use\":\"usual\",\"system\":\"EID\",\"value\":\"1234\"},{\"use\":\"usual\",\"system\":\"AMI\",\"value\":\"\"}],\"active\":true,\"name\":[{\"use\":\"usual\",\"family\":[\"TESTER\"],\"given\":[\"TEST\"]}],\"telecom\":[{\"system\":\"phone\",\"value\":\"2221115555\"}],\"gender\":\"F\",\"birthDate\":\"1911-11-11\",\"deceasedBoolean\":false,\"address\":[{\"line\":[\"9999 TEST AVE S\"],\"city\":\"TEST\",\"state\":\"WA\",\"postalCode\":\"98110\"}]}],\"resourceType\":\"Encounter\",\"status\":\"arrived\",\"identifier\":[{\"system\":\"http://collectivemedicaltech.com/Encounter\",\"use\":\"secondary\",\"value\":\"a7bdc0ec-02f3-4626-8066-701975acacac\"},{\"use\":\"temp\",\"value\":\"10249211111\"}],\"text\":{\"status\":\"generated\",\"div\":\"<div>Patient had an Inpatient encounter at test Facility</div>\"},\"serviceProvider\":{\"reference\":\"#wa_test\"},\"subject\":{\"reference\":\"#a7bdc0ec-02f3-4626-8066-701975acacac\"},\"class\":{\"system\":\"http://collectivemedicaltech.com/Encounter\",\"code\":\"I\",\"display\":\"Inpatient\"},\"period\":{\"start\":\"2019-10-11T14:20:03.931Z\"},\"type\":[{\"coding\":[{\"system\":\"http://collectivemedicaltech.com/Encounter\",\"code\":\"26\",\"display\":\"Test\"}]}],\"reason\":[{\"text\":\"\"}],\"diagnosis\":[{\"sequence\":1,\"diagnosis\":{\"system\":\"http://hl7.org/fhir/sid/icd-10\",\"code\":\"12345\"}},{\"sequence\":2,\"diagnosis\":{\"system\":\"http://hl7.org/fhir/sid/icd-10\",\"code\":\"6789\"}}]}",
      "attributes": {
        "ApproximateReceiveCount": "1",
        "SentTimestamp": "1560977325388",
        "SenderId": "AIDAIT2UOQQY3AUEKVGXU",
        "ApproximateFirstReceiveTimestamp": "1560977325395"
      },
      "messageAttributes": {
        "authorization": {
          "stringValue": "eyJraWQiOiJ6SDFtQmIzOVF3SmtJUTZGWGI4NVwvUnZNcFVUZ3BDXC8rRWoxNGlwQzZrbVk9IiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiI1bmEzdHJmOHYwaW0xdWNxZW5hN2Q3dDdiMSIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoiZW5jb3VudGVyXC9wb3N0IiwiYXV0aF90aW1lIjoxNTYwOTc0ODE1LCJpc3MiOiJodHRwczpcL1wvY29nbml0by1pZHAudXMtZWFzdC0xLmFtYXpvbmF3cy5jb21cL3VzLWVhc3QtMV9JaEVONnliTTMiLCJleHAiOjE1NjA5Nzg0MTUsImlhdCI6MTU2MDk3NDgxNSwidmVyc2lvbiI6MiwianRpIjoiNWQ5ZDExNmEtZjM4ZC00YTE0LWJiZjMtYzA2M2JhMzYxMjE0IiwiY2xpZW50X2lkIjoiNW5hM3RyZjh2MGltMXVjcWVuYTdkN3Q3YjEifQ.QGvmbK6pF_2xocXD-jnicVJcjbcjUaDNPkchVQEFF1paGwaz3j-h4cm4zXwoeahBFbugpvx4KMBT3LfGvmrEFLC1lcZDCdjCCB34_SU8aCqIahMth4-TWwbs1eIAgkwdIh_l78_mNXCl6KY_U1XPN-ucrzGgQgfjv_TniO5sRE-2oBEAB8WSKqIJ6VfuBZlwNjl0kyXhDs0TsXphDakELBJ8I-3n9Iici_UL45payybA0lljcI0u73W2XeRBP9GJTMqonaeWMNId42tTnGVoxAz3OSSvFYdHqBOTXPfufRHx1rx8n4oq2u5Kj_rMJ9t7UxMtzrRugrX4OT04tVcq7w",
          "stringListValues": [],
          "binaryListValues": [],
          "dataType": "String"
        },
        "method": {
          "stringValue": "encounter",
          "stringListValues": [],
          "binaryListValues": [],
          "dataType": "String"
        },
        "cohort": {
          "stringValue": "default",
          "stringListValues": [],
          "binaryListValues": [],
          "dataType": "String"
        }
      },
      "md5OfBody": "2b7c8e97260aa7c07fd0579b01d20bf5",
      "eventSource": "aws:sqs",
      "eventSourceARN": "arn:aws:sqs:us-east-1:003856232118:fhir-exchange-storage-queue-sergii",
      "awsRegion": "us-east-1"
    }]
};


// var payload4 ={
//   "Records": [
//     {
//       "messageId": "9527b32e-2cc5-473d-a79a-6c5289ea5b98",
//       "receiptHandle": "AQEBM6L+dmm8OfJCFX3QLBr3Myy7lxEk634IrqXpMKMneyp+N1hGalwNF5Vbkpxk3qz2Ob6WmpYzM4hzsSrd7JpNk98w44X1sX9VWqHoMEJohXGc9Uo4kQtT37XfQsNHVuyzWDJgVbFXGabo7FfrgZf4eefLde/+NbvlQPlXkXeA0B4jy0O8QZUmp5DHCwS+MQNWxW9lSBkPTXQL95n2lVrM3FYdkUZmgvJ2cOzeC6BYWw6/+4HwV2mEE/s9ChxA/YaBmomukP9qUxbNTomVVyta9DFEeH+D4NujI8RRAB1O+izqiN5lgSttRLR7CrJ23J/1F7x4Me39dpaMApYA2tbhF886SKhHn5+rRGFpNiBdHoCRiDS77ztKThTRnNi89KLiC7FnQc5iPXs03apiVI6wqtCxy8lAl+ROcjNSwjB4KF0=",
//       "body": "{\"class\":{\"code\":\"E\",\"display\":\"Emergency\",\"system\":\"http://collectivemedicaltech.com/Encounter\"},\"contained\":[{\"id\":\"cc13c973-62b8-445d-94b3-26e7bab736d9\",\"identifier\":[{\"system\":\"org_cmt_id\",\"value\":\"va_1598708513\"},{\"system\":\"org_name\",\"value\":\"HCA - Chippenham Hospital\"},{\"system\":\"http://collectivemedicaltech.com\",\"value\":\"cc13c973-62b8-445d-94b3-26e7bab736d9\"},{\"system\":\"NPI\",\"value\":\"\"},{\"system\":\"TIN\",\"value\":\"\"}],\"name\":\"My Location\",\"resourceType\":\"Organization\",\"text\":{\"div\":\"<div>My Location</div>\",\"status\":\"generated\"}},{\"address\":[{\"city\":\"\",\"line\":[\"\"],\"postalCode\":\"\",\"state\":\"\"}],\"identifier\":[{\"system\":\"http://collectivemedicaltech.com\",\"value\":\"ac1e46a1-082b-4789-97e0-fee91b245d39\"},{\"system\":\"NPI\",\"value\":\"\"}],\"name\":[{\"family\":[\"\"],\"given\":[\"\"],\"use\":\"usual\"}],\"resourceType\":\"Practitioner\",\"telecom\":[{\"system\":\"phone\",\"value\":\"\"}]},{\"recorded\":\"2020-03-26 01:35:01\",\"resourceType\":\"Provenance\"},{\"active\":true,\"address\":[{\"city\":\"SPRINGFIELD\",\"line\":[\"1234 SEASAME ST\"],\"postalCode\":\"23860\",\"state\":\"VA\"}],\"birthDate\":\"2015-08-16\",\"deceasedBoolean\":false,\"gender\":\"M\",\"id\":\"3911caf2-5f61-4926-b86f-ac2c472abcd9\",\"identifier\":[{\"system\":\"http://collectivemedicaltech.com/\",\"use\":\"usual\",\"value\":\"3911caf2-5f61-4926-b86f-ac2c472abc11\"},{\"system\":\"EID\",\"use\":\"usual\",\"value\":\"182265414\"},{\"system\":\"AMI\",\"use\":\"usual\",\"value\":\"\"},{\"system\":\"medicaid\",\"use\":\"usual\",\"value\":\"\"}],\"name\":[{\"family\":[\"SMITH\"],\"given\":[\"ROBERT\"],\"use\":\"usual\"}],\"resourceType\":\"Patient\",\"telecom\":[{\"system\":\"phone\",\"value\":\"8043841234\"}]}],\"diagnosis\":[{\"diagnosis\":{\"code\":\"\",\"system\":\"http://hl7.org/fhir/sid/icd-10\"},\"sequence\":1}],\"identifier\":[{\"system\":\"http://collectivemedicaltech.com/Encounter\",\"use\":\"secondary\",\"value\":\"448ac5ac-7ce7-4bd3-96d3-c02daa0f1509\"},{\"use\":\"temp\",\"value\":\"D35061983699\"}],\"period\":{\"end\":\"\",\"extension\":[{\"url\":\"http://hl7.org/fhir/StructureDefinition/tz-offset\",\"valueString\":\"-4\"}],\"start\":\"2020-03-25 21:29:00\"},\"reason\":[{\"text\":\"\"}],\"resourceType\":\"Encounter\",\"serviceProvider\":{\"reference\":\"#va_1598708519\"},\"status\":\"arrived\",\"subject\":{\"reference\":\"#448ac5ac-7ce7-4bd3-96d3-c02daa0f1509\"},\"text\":{\"div\":\"<div>Patient had an Emergency encounter at HCA - Chippenham Hospital</div>\",\"status\":\"generated\"},\"type\":[{\"coding\":[{\"code\":\"0\",\"display\":\"Emergency\",\"system\":\"http://collectivemedicaltech.com/Encounter\"}]}]}",
//       "attributes": {
//         "ApproximateReceiveCount": "1",
//         "AWSTraceHeader": "Root=1-5e7d18bf-fd3d331e09c831d94c60aaad",
//         "SentTimestamp": "1585256639615",
//         "SenderId": "AIDAIT2UOQQY3AUEKVGXU",
//         "ApproximateFirstReceiveTimestamp": "1585256639623"
//       },
//       "messageAttributes": {
//         "authorization": {
//           "stringValue": "Bearer eyJraWQiOiJ3K0hseTY5QmRRaXVDc0MzaXpUdlNGRUVZcjlvRjRZMWNLRERTcGZMayt3PSIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiIyOTRocGloaXJ1NjZhZGNmczdkNjNyMmJwZiIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoiZW5jb3VudGVyXC9wb3N0IiwiYXV0aF90aW1lIjoxNTg1MjU2MzE3LCJpc3MiOiJodHRwczpcL1wvY29nbml0by1pZHAudXMtZWFzdC0xLmFtYXpvbmF3cy5jb21cL3VzLWVhc3QtMV9oV1QwWG9ibDYiLCJleHAiOjE1ODUyNTk5MTcsImlhdCI6MTU4NTI1NjMxNywidmVyc2lvbiI6MiwianRpIjoiYWI2OGJkNWQtYjQyNi00YzhlLWJjNGYtNTJlZTYyNmM1YWFmIiwiY2xpZW50X2lkIjoiMjk0aHBpaGlydTY2YWRjZnM3ZDYzcjJicGYifQ.O0DCkuZ7bn8RNCzrVoVchNNMEsOpr1tlpeNgfEZJIUslMENkdsighdQMKo8zuBSlR_Xw7N5CJi5uxbTd1p6WhdYkz_6lwREV8j7ry5IPKpQSefuluiRo_VdAHTUIl5RNykHXpKD9Xs2U9mwHam-zHoy5DFSWfT_dx3w1VpPuM425p20ucBo20Tp08D-Qvq4oL6nXvicU8_vGI6Lt9miJnkWggCrBmAZndomlS0XJowLM2t37EZn_HXD6BY2mNkyajxlh9NqdpsIQTeXLBTZ2aJ41WJPPrzx6bU2U1ni2MYtyJI3uX5-EoEXY48Thua1HAJExUu6gteQPmNbFXFC8dA",
//           "stringListValues": [],
//           "binaryListValues": [],
//           "dataType": "String"
//         },
//         "method": {
//           "stringValue": "encounter",
//           "stringListValues": [],
//           "binaryListValues": [],
//           "dataType": "String"
//         },
//         "awsRequestId": {
//           "stringValue": "9ed9ee66-81ff-48b0-bf15-c266ae2d7198",
//           "stringListValues": [],
//           "binaryListValues": [],
//           "dataType": "String"
//         },
//         "cohort": {
//           "stringValue": "default",
//           "stringListValues": [],
//           "binaryListValues": [],
//           "dataType": "String"
//         }
//       },
//       "md5OfBody": "2372048819afd7243913035bddf17f37",
//       "md5OfMessageAttributes": "1f80648bd2a6380f4c371af2c818ea23",
//       "eventSource": "aws:sqs",
//       "eventSourceARN": "arn:aws:sqs:us-east-1:003856232118:fhir-transform-encounter-queue-watson",
//       "awsRegion": "us-east-1"
//     }
//   ]
// }
//
// cis(payload4, {}, (argument1, argument2) => {
//   console.log(argument1, argument2);
// });
//
//

