import FHIREncounterParser from "../src/parser/FHIREncounterParser";
import {testMessage} from "./sampleData/data";

describe('Search and return fields', function () {
  let fhirEncounterParser;
  let arrayKeyValue;

  beforeEach(function () {
    arrayKeyValue = [];
    arrayKeyValue[0] = {
      "use": "usual",
      "system": "http://collectivemedicaltech.com/",
      "value": "028276a5-5657-48f4-89f6-f5a8b6c23fa1"
    };
    arrayKeyValue[1] = {
      "use": "temp",
      "system": "medicaid",
      "value": "123"
    }
    fhirEncounterParser = new FHIREncounterParser();

  });

  describe('system field value', function () {

    it('should equal return the system value', async function () {

      const value = await fhirEncounterParser.searchAndReturnSys(arrayKeyValue, "http://collectivemedicaltech.com/")
      expect(value).toEqual("028276a5-5657-48f4-89f6-f5a8b6c23fa1");

    });
  });

  describe('use field value', function () {

    it('should equal return the use value', async function () {

      const value = await fhirEncounterParser.searchAndReturnUse(arrayKeyValue, "temp")
      expect(value).toEqual("123");
    });
  });
});


describe('Parse Encounter Message', function () {
  let fhirEncounterParser;

  beforeEach(function () {
    fhirEncounterParser = new FHIREncounterParser();
  });

  describe('should return rowkey and encounter mapping', function () {

    it('should equal all the parsed values [ENCOUNTER]', async function () {
      const value = await fhirEncounterParser.parseEncounterMsg(testMessage, {
        cohort: "cohort_dummy",
        userId: "user_dummy"
      });

      let jsonObj = value[1];
      let enc = jsonObj.encounter;
      let compareEnc = {
        "cmtId": "56",
        "otherId": "10987654321",
        "status": "arrived",
        "text": "<div>Patient had an outpatient encounter at Providence Milwaukie Hospital</div>",
        "provider": "1234567890",
        "subject": "3",
        "classCode": "O",
        "classDesc": "outpatient",
        "startDate": "2020-01-10T13:54:00.000Z",
        "reason": "haha33",
        "diagnosisList": "Acute kidney failure, unspecified (HCC) | NKKK",
        "endDate": undefined,
        "diagnosisTypeList": "http://hl7.org/fhir/sid/icd-10 | http://hl7.org/fhir/sid/icd-10"
        // "diag_1": "Acute kidney failure, unspecified (HCC)",
        // "diag_2": "NKKK"
      };
      expect(enc).toEqual(compareEnc);
    });

    it('should equal all the parsed values [PATIENT]', async function () {
      const value = await fhirEncounterParser.parseEncounterMsg(testMessage, {
        cohort: "cohort_dummy",
        userId: "user_dummy"
      });

      let jsonObj = value[1];
      let patient = jsonObj.patient;
      let adress = {
        "line1": "10831 MEADOW LN",
        line2: undefined,
        "city": "PHILADELPHIA",
        "state": "PA",
        "zip": "19154"
      };
      let comparePatient = {
        "cmtId": "028276a5-5657-48f4-89f6-f5a8b6c23fa1",
        "EID": "1122334455",
        "otherId": "",
        "active": true,
        "gender": "1",
        "dob": "1975-09-12",
        "deceased": false,
        "firstName": "JOHN",
        "lastName": "SMITH",
        "phone": "1234567890",
        "address": adress
      };
      expect(patient).toEqual(comparePatient);
    });

    it('should equal all the parsed values [ORGANIZATION]', async function () {
      const value = await fhirEncounterParser.parseEncounterMsg(testMessage, {
        cohort: "cohort_dummy",
        userId: "user_dummy"
      });

      let jsonObj = value[1];

      let organization = jsonObj.organization;
      let compareOrganization = {"name": "My Location", "cmtId": "12345", "npi": "1234567890", "tin": ""};
      expect(organization).toEqual(compareOrganization);
    });
  });

  describe('Converting Date to UTC Date', function () {

    let fhirEncounterParser: FHIREncounterParser;

    beforeEach(() => {
      fhirEncounterParser = new FHIREncounterParser();
    })

    it('offSetTime -5:00', async function () {
      let usualTime = "2020-03-25 21:29:00";
      let offSetTime = "-5:00";
      let expectedTime = "2020-03-26T02:29:00.000Z";

      expect(fhirEncounterParser.convertToUTC(usualTime, offSetTime)).toEqual(expectedTime);
    });

    it('test offSetTime -05:00', async function () {
      let usualTime = "2020-03-25 21:29:00";
      let offSetTime = "-05:00";
      let expectedTime = "2020-03-26T02:29:00.000Z";

      expect(fhirEncounterParser.convertToUTC(usualTime, offSetTime)).toEqual(expectedTime);
    });

    it('test 2 offSetTime -5', async function () {
      let usualTime = "2020-03-25 21:29:00";
      let offSetTime = "-5";
      let expectedTime = "2020-03-26T02:29:00.000Z";

      expect(fhirEncounterParser.convertToUTC(usualTime, offSetTime)).toEqual(expectedTime);
    });

    it('test 3, offset 4:00', async function () {
      let usualTime = "2020-03-21 21:29:00";
      let offSetTime = "4:00";
      let expectedTime = "2020-03-21T17:29:00.000Z";

      expect(fhirEncounterParser.convertToUTC(usualTime, offSetTime)).toEqual(expectedTime);
    });

    it('zero offset, offsetTime = 0:00', async function () {
      let usualTime = "2020-03-21 21:29:00";
      let offSetTime = "0:00";
      let expectedTime = "2020-03-21T21:29:00.000Z";

      expect(fhirEncounterParser.convertToUTC(usualTime, offSetTime)).toEqual(expectedTime);
    });

    it('zero offset, offsetTime = 0:00', async function () {
      let usualTime = "2020-03-21 21:29:00";
      let offSetTime = "0:00";
      let expectedTime = "2020-03-21T21:29:00.000Z";

      expect(fhirEncounterParser.convertToUTC(usualTime, offSetTime)).toEqual(expectedTime);
    });

    it('zero offset, offsetTime = 00:00', async function () {
      let usualTime = "2020-03-21 21:29:00";
      let offSetTime = "00:00";
      let expectedTime = "2020-03-21T21:29:00.000Z";

      expect(fhirEncounterParser.convertToUTC(usualTime, offSetTime)).toEqual(expectedTime);
    });

    it('zero offset, offsetTime 0', async function () {
      let usualTime = "2020-03-21 21:29:00";
      let offSetTime = "0";
      let expectedTime = "2020-03-21T21:29:00.000Z";

      expect(fhirEncounterParser.convertToUTC(usualTime, offSetTime)).toEqual(expectedTime);
    });

    it('positive offest, offsetTime 6', async function () {
      let usualTime = "2020-03-21 21:29:00";
      let offSetTime = "6";
      let expectedTime = "2020-03-21T15:29:00.000Z";

      expect(fhirEncounterParser.convertToUTC(usualTime, offSetTime)).toEqual(expectedTime);
    });

    it('positive offest, offsetTime +6', async function () {
      let usualTime = "2020-03-21 21:29:00";
      let offSetTime = "+6";
      let expectedTime = "2020-03-21T15:29:00.000Z";

      expect(fhirEncounterParser.convertToUTC(usualTime, offSetTime)).toEqual(expectedTime);
    });

    it('positive offest, offsetTime +06', async function () {
      let usualTime = "2020-03-21 21:29:00";
      let offSetTime = "+06";
      let expectedTime = "2020-03-21T15:29:00.000Z";

      expect(fhirEncounterParser.convertToUTC(usualTime, offSetTime)).toEqual(expectedTime);
    });

    it('positive offest, offsetTime 06', async function () {
      let usualTime = "2020-03-21 21:29:00";
      let offSetTime = "06";
      let expectedTime = "2020-03-21T15:29:00.000Z";

      expect(fhirEncounterParser.convertToUTC(usualTime, offSetTime)).toEqual(expectedTime);
    });

    it('positive offest, offsetTime +06:00', async function () {
      let usualTime = "2020-03-21 21:29:00";
      let offSetTime = "+06:00";
      let expectedTime = "2020-03-21T15:29:00.000Z";

      expect(fhirEncounterParser.convertToUTC(usualTime, offSetTime)).toEqual(expectedTime);
    });

    it('positive offest, offsetTime 06:00', async function () {
      let usualTime = "2020-03-21 21:29:00";
      let offSetTime = "06:00";
      let expectedTime = "2020-03-21T15:29:00.000Z";

      expect(fhirEncounterParser.convertToUTC(usualTime, offSetTime)).toEqual(expectedTime);
    });
  });
});


