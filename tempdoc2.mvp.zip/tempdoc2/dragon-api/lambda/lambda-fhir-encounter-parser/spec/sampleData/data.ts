export let msg1 = `{
    "contained": [
        {
            "resourceType": "Organization",
            "id": "12345",
            "text": {
                "status": "generated",
                "div": "<div>My Location</div>"
            },
            "identifier": [
                {
                    "system": "http://collectivemedicaltech.com",
                    "value": "12345"
                },
                {
                    "system": "NPI",
                    "value": "1234567890"
                },
                {
                    "system": "TIN",
                    "value": ""
                }
            ],
            "name": "My Location"
        },
        {
            "resourceType": "Patient",
            "id": "028276a5-5657-48f4-89f6-f5a8b6c23fa1",
            "identifier": [
                {
                    "use": "usual",
                    "system": "http://collectivemedicaltech.com/",
                    "value": "028276a5-5657-48f4-89f6-f5a8b6c23fa1"
                },
                {
                    "use": "usual",
                    "system": "medicaid",
                    "value": ""
                },
                {
                  "use": "usual",
                  "system": "EID",
                  "value": "1122334455"
                }
            ],
            "active": true,
            "name": [
                {
                    "use": "usual",
                    "family": [
                        "SMITH"
                    ]
                }
            ],
            "telecom": [
                {
                    "system": "phone",
                    "value": "1234567890"
                }
            ],
            "gender": "1",
            "birthDate": "1975-09-12",
            "deceasedBoolean": false,
            "address": [
                {
                    "line": [
                        "10831 MEADOW LN"
                    ],
                    "city": "PHILADELPHIA",
                    "state": "PA",
                    "postalCode": "19154"
                }
            ]
        }
    ],
    "resourceType": "Encounter",
    "status": "arrived",
    "identifier": [
        {
            "system": "http://collectivemedicaltech.com/Encounter",
            "use": "secondary",
            "value": "1"
        },
        {
            "use": "temp",
            "value": "10987654321"
        }
    ],
    "text": {
        "status": "generated",
        "div": "<div>Patient had an outpatient encounter at Providence Milwaukie Hospital</div>"
    },
    "serviceProvider": {
        "reference": "1234567890"
    },
    "subject": {
        "reference": "1"
    },
    "class": {
        "system": "http://collectivemedicaltech.com/Encounter",
        "code": "O",
        "display": "outpatient"
    },
    "period": {
        "start": "2018-12-14 09:57:33"
    },
    "type": [
        {
            "coding": [
                {
                    "system": "http://collectivemedicaltech.com/Encounter",
                    "code": "O",
                    "display": "outpatient"
                }
            ]
        }
    ],
    "reason": [
        {
            "text": "haha"
        }
    ],
    "diagnosis": [
        {
            "sequence": 1,
            "diagnosis": {
                "system": "http://hl7.org/fhir/sid/icd-10",
                "code": "Acute kidney failure, unspecified (HCC)"
            }
        }
    ]
}`;

export let msg2 = `{
    "contained": [
        {
            "resourceType": "Organization",
            "id": "12345",
            "text": {
                "status": "generated",
                "div": "<div>My Location</div>"
            },
            "identifier": [
                {
                    "system": "http://collectivemedicaltech.com",
                    "value": "12345"
                },
                {
                    "system": "NPI",
                    "value": "1234567890"
                },
                {
                    "system": "TIN",
                    "value": ""
                }
            ],
            "name": "My Location"
        },
        {
            "resourceType": "Patient",
            "id": "028276a5-5657-48f4-89f6-f5a8b6c23fa1",
            "identifier": [
                {
                    "use": "usual",
                    "system": "http://collectivemedicaltech.com/",
                    "value": "028276a5-5657-48f4-89f6-f5a8b6c23fa1"
                },
                {
                    "use": "usual",
                    "system": "medicaid",
                    "value": "oid"
                },
                {
                  "use": "usual",
                  "system": "EID",
                  "value": "427074"
                }
            ],
            "active": true,
            "name": [
                {
                    "use": "usual",
                    "family": [
                        "SMITH"
                    ],
                    "given": [
                        "JOHN"
                    ]
                }
            ],
            "telecom": [
                {
                    "system": "phone",
                    "value": "1234567890"
                }
            ],
            "gender": "1",
            "birthDate": "1975-09-12",
            "deceasedBoolean": false,
            "address": [
                {
                    "line": [
                        "10831 MEADOW LN"
                    ],
                    "city": "PHILADELPHIA",
                    "state": "PA",
                    "postalCode": "19154"
                }
            ]
        }
    ],
    "resourceType": "Encounter",
    "status": "arrived",
    "identifier": [
        {
            "system": "http://collectivemedicaltech.com/Encounter",
            "use": "secondary",
            "value": "2"
        },
        {
            "use": "temp",
            "value": "10987654321"
        }
    ],
    "text": {
        "status": "generated",
        "div": "<div>Patient had an outpatient encounter at Providence Milwaukie Hospital</div>"
    },
    "serviceProvider": {
        "reference": "1234567890"
    },
    "subject": {
        "reference": "2"
    },
    "class": {
        "system": "http://collectivemedicaltech.com/Encounter",
        "code": "O",
        "display": "outpatient"
    },
    "period": {
        "start": "2018-12-14 09:57:33"
    },
    "type": [
        {
            "coding": [
                {
                    "system": "http://collectivemedicaltech.com/Encounter",
                    "code": "O",
                    "display": "outpatient"
                }
            ]
        }
    ],
    "reason": [
        {
            "text": "haha2"
        }
    ],
    "diagnosis": [
        {
            "sequence": 1,
            "diagnosis": {
                "system": "http://hl7.org/fhir/sid/icd-10",
                "code": "Acute kidney failure, unspecified (HCC)"
            }
        }
    ]
}`;


export let msg3 = `{
    "contained": [
        {
            "resourceType": "Organization",
            "id": "12345",
            "text": {
                "status": "generated",
                "div": "<div>My Location</div>"
            },
            "identifier": [
                {
                    "system": "http://collectivemedicaltech.com",
                    "value": "12345"
                },
                {
                    "system": "NPI",
                    "value": "1234567890"
                },
                {
                    "system": "TIN",
                    "value": ""
                }
            ],
            "name": "My Location"
        },
        {
            "resourceType": "Patient",
            "id": "028276a5-5657-48f4-89f6-f5a8b6c23fa1",
            "identifier": [
                {
                    "use": "usual",
                    "system": "http://collectivemedicaltech.com/",
                    "value": "028276a5-5657-48f4-89f6-f5a8b6c23fa1"
                },
                {
                    "use": "usual",
                    "system": "medicaid",
                    "value": ""
                },
                {
                  "use": "usual",
                  "system": "EID",
                  "value": "1122334455"
                }
            ],
            "active": true,
            "name": [
                {
                    "use": "usual",
                    "family": [
                        "SMITH"
                    ],
                    "given": [
                        "JOHN"
                    ]
                }
            ],
            "telecom": [
                {
                    "system": "phone",
                    "value": "1234567890"
                }
            ],
            "gender": "1",
            "birthDate": "1975-09-12",
            "deceasedBoolean": false,
            "address": [
                {
                    "line": [
                        "10831 MEADOW LN"
                    ],
                    "city": "PHILADELPHIA",
                    "state": "PA",
                    "postalCode": "19154"
                }
            ]
        }
    ],
    "resourceType": "Encounter",
    "status": "arrived",
    "identifier": [
        {
            "system": "http://collectivemedicaltech.com/Encounter",
            "use": "secondary",
            "value": "3"
        },
        {
            "use": "temp",
            "value": "10987654321"
        }
    ],
    "text": {
        "status": "generated",
        "div": "<div>Patient had an outpatient encounter at Providence Milwaukie Hospital</div>"
    },
    "serviceProvider": {
        "reference": "1234567890"
    },
    "subject": {
        "reference": "3"
    },
    "class": {
        "system": "http://collectivemedicaltech.com/Encounter",
        "code": "O",
        "display": "outpatient"
    },
    "period": {
        "start": "2018-12-14 09:57:33"
    },
    "type": [
        {
            "coding": [
                {
                    "system": "http://collectivemedicaltech.com/Encounter",
                    "code": "O",
                    "display": "outpatient"
                }
            ]
        }
    ],
    "reason": [
        {
            "text": "haha3"
        }
    ],
    "diagnosis": [
        {
            "sequence": 1,
            "diagnosis": {
                "system": "http://hl7.org/fhir/sid/icd-10",
                "code": "Acute kidney failure, unspecified (HCC)"
            }
        }
    ]
}`;

export let testMessage = `{
    "contained": [
        {
            "resourceType": "Provenance",
            "recorded": "2019-06-24T09: 05: 07.740Z"
          },
        {
            "resourceType": "Organization",
            "id": "12345",
            "text": {
                "status": "generated",
                "div": "<div>My Location</div>"
            },
            "identifier": [
                {
                    "system": "http://collectivemedicaltech.com",
                    "value": "12345"
                },
                {
                    "system": "NPI",
                    "value": "1234567890"
                },
                {
                    "system": "TIN",
                    "value": ""
                }
            ],
            "name": "My Location"
        },
        {
            "resourceType": "Patient",
            "id": "028276a5-5657-48f4-89f6-f5a8b6c23fa1",
            "identifier": [
                {
                    "use": "usual",
                    "system": "http://collectivemedicaltech.com/",
                    "value": "028276a5-5657-48f4-89f6-f5a8b6c23fa1"
                },
                {
                    "use": "usual",
                    "system": "medicaid",
                    "value": ""
                },
                {
                  "use": "usual",
                  "system": "EID",
                  "value": "1122334455"
                }
            ],
            "active": true,
            "name": [
                {
                    "use": "usual",
                    "family": [
                        "SMITH"
                    ],
                    "given": [
                        "JOHN"
                    ]
                }
            ],
            "telecom": [
                {
                    "system": "phone",
                    "value": "1234567890"
                }
            ],
            "gender": "1",
            "birthDate": "1975-09-12",
            "deceasedBoolean": false,
            "address": [
                {
                    "line": [
                        "10831 MEADOW LN"
                    ],
                    "city": "PHILADELPHIA",
                    "state": "PA",
                    "postalCode": "19154"
                }
            ]
        }
    ],
    "resourceType": "Encounter",
    "status": "arrived",
    "identifier": [
        {
            "system": "http://collectivemedicaltech.com/Encounter",
            "use": "secondary",
            "value": "56"
        },
        {
            "use": "temp",
            "value": "10987654321"
        }
    ],
    "text": {
        "status": "generated",
        "div": "<div>Patient had an outpatient encounter at Providence Milwaukie Hospital</div>"
    },
    "serviceProvider": {
        "reference": "1234567890"
    },
    "subject": {
        "reference": "3"
    },
    "class": {
        "system": "http://collectivemedicaltech.com/Encounter",
        "code": "O",
        "display": "outpatient"
    },
    "period": {
        "start": "2020-01-10 05:54:00",
        "end": "",
        "extension": [
          {
          "url": "http://hl7.org/fhir/StructureDefinition/tz-offset",
          "valueString": "-08:00"
          }
        ]
    },
    "type": [
        {
            "coding": [
                {
                    "system": "http://collectivemedicaltech.com/Encounter",
                    "code": "O",
                    "display": "outpatient"
                }
            ]
        }
    ],
    "reason": [
        {
            "text": "haha33"
        }
    ],
    "diagnosis": [
        {
            "sequence": 1,
            "diagnosis": {
                "system": "http://hl7.org/fhir/sid/icd-10",
                "code": "Acute kidney failure, unspecified (HCC)"
            }
        },
        {
            "sequence": 2,
            "diagnosis": {
                "system": "http://hl7.org/fhir/sid/icd-10",
                "code": "NKKK"
            }
        }        
    ]
}`;
