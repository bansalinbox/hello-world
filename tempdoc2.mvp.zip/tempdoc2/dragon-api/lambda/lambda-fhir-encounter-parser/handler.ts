require("source-map-support").install();

import {SQSEvent} from "aws-lambda";
import FhirParser from "./FhirParser";

let handler = async (event: SQSEvent, context, callback) => {
  try{
    let obj = new FhirParser();
    await obj.handler(event, context, callback);
  }catch (e) {
    console.error('UNEXPECTED EXCEPTION HAPPENED')
    callback(e);
  }
}

export {handler as cis};
