import FHIREncounterParser from "./src/parser/FHIREncounterParser";
import { SQSEvent, SQSRecord } from "aws-lambda";
import SNS = require("aws-sdk/clients/sns");
import { IMetadata } from "./src/model/Interfaces";
import { Utility } from "./src/Utility";

export default class FhirParser {
  private COHORT_NAME = process.env.COHORT_NAME;
  private AUTHORIZATION_TOKEN_NAME = process.env.AUTHORIZATION_TOKEN_NAME;
  private CORRELATION_ID = process.env.CORRELATION_ID;
  private FAN_OUT_SNS_TOPIC_ARN = process.env.FAN_OUT_SNS_TOPIC_ARN;
  private SNS = new SNS({region: process.env.SNS_REGION})

  public async handler(event: SQSEvent, context, callback) {
    let parsedMsgs: Array<any> = [];
    let sucessRowKeys: string[] = [];
    let errorMsgs: string[] = [];
    let parser = new FHIREncounterParser();
    let recordAgg = event.Records;
    let totalRecord = recordAgg.length;
    for (let i = 0; i < totalRecord; i++) {
      let parsedMsgTuple = parser.parseEncounterMsg(recordAgg[i].body, this.extractMetadata(recordAgg[i]));
      if (parsedMsgTuple[1]) {
        sucessRowKeys.push(parsedMsgTuple[0]);
        parsedMsgs.push(parsedMsgTuple[1]);
      } else {
        errorMsgs.push(parsedMsgTuple[0]);
      }
    }

    let report = {
      TotalRecords: totalRecord,
      SuccessTotal: parsedMsgs.length,
      SuccessKeys: sucessRowKeys,
      ErrorTotal: errorMsgs.length,
      ErrorKeys: errorMsgs
    };

    console.log(report);

    let snsPayloads = parsedMsgs.map(value => {
      return {
        Message: JSON.stringify(value),
        TopicArn: this.FAN_OUT_SNS_TOPIC_ARN
      }
    }).map(snsPayload => {
      return this.SNS.publish(snsPayload).promise();
    });


    await Promise.all(snsPayloads).then(value => {
      console.log(value);
      callback(null, report);
    }).catch(reason => {
      callback(reason);
    });
  }

  public extractMetadata(recordAgg: SQSRecord): IMetadata {
    let metadata: IMetadata = {
      cohort: recordAgg.messageAttributes[this.COHORT_NAME] ? recordAgg.messageAttributes[this.COHORT_NAME].stringValue : null,
      userId: recordAgg.messageAttributes[this.AUTHORIZATION_TOKEN_NAME] ? Utility.getClientIdFromJWT(recordAgg.messageAttributes[this.AUTHORIZATION_TOKEN_NAME].stringValue) : null,
      correlationId: recordAgg.messageAttributes[this.CORRELATION_ID] ? recordAgg.messageAttributes[this.CORRELATION_ID].stringValue : null
    };

    return metadata;
  }
}
