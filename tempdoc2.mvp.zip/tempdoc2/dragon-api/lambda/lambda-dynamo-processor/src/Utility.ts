const uuidv1 = require('uuid/v1');
import * as JWT from 'jsonwebtoken'

export class Utility {

  public getIdentifiers(encounterPayload) {
    let encounterArray = encounterPayload.identifier;
    let identifierArray = [];
    let encounterArrayLength = encounterArray.length;
    for (let i = 0; i < encounterArrayLength; i++) {
      identifierArray.push(encounterArray[i].value);
    }
    return identifierArray;
  }


  public getPartitionKey(date: Date): string {
    let month = '' + (date.getMonth() + 1),
      day = '' + date.getDate(),
      year = date.getFullYear();

    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;

    return [year, month, day].join('-');
  }

  public getTTL(hours: number): number {
    let deltaTime: number = hours/*hours*/ * 60/*minutes*/ * 60 /*seconds*/;
    let ttl = Math.floor(Date.now() / 1000) + deltaTime;
    return ttl;
  }

  public getHash(): string {
    return uuidv1();
  }

  public logCustomError(customErrorType, reason: Error) {
    let customError = {
      customErrorType: customErrorType,
      name: reason.name,
      message: reason.message,
      stack: reason.stack
    };
    console.log(JSON.stringify(customError));
  }

  public getClientIdFromJWT(jwt: string): string {
    const bearer = "Bearer ";
    if (jwt && jwt.indexOf(bearer) == 0) {
      jwt = jwt.substr(bearer.length);
    }
    let jwtDecode = JWT.decode(jwt);
    return jwtDecode ? jwtDecode.sub : "UNKNOWN_ERROR";
  }
}
