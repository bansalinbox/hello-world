export interface StorageRow {
  datePartition: string,
  sortKey: string,
  cohort?: string,
  cognitoClientId?: string,
  identifiers: Array<string>,
  payload: any,
  createdAt: string,
  expirationTTL?: number,
  correlationId: string
}

export interface RepositoryConfig {
  ttl: number
}


export interface encounterDTO {
  encounter: any,
  attributes: { cohort?: string, authorization?: string, correlationId?: string }
}
