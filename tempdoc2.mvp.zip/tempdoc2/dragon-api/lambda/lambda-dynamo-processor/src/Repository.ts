import { DynamoDB } from 'aws-sdk';
import { Utility } from "./Utility";
import { encounterDTO, RepositoryConfig, StorageRow } from "./Interfaces";

export class DynamoDBRepository {
  private dynamo: DynamoDB;
  private utility: Utility;
  private config: RepositoryConfig;

  constructor(dynamo: DynamoDB, utility: Utility, config: RepositoryConfig) {
    this.dynamo = dynamo;
    this.utility = utility;
    this.config = config;
  }

  public batchSaveEncounter(items: Array<StorageRow>, tableName: string) {
    let putRecords = items.map((row) => {
      return {
        PutRequest: {
          Item: DynamoDB.Converter.marshall(row, {convertEmptyValues: true})
        }
      }
    });

    let params = {RequestItems: {}};
    params.RequestItems[tableName] = putRecords;

    return this.dynamo.batchWriteItem(params).promise();
  }

  public formatEncountersForBathSave(items: Array<encounterDTO>): StorageRow[] {
    let currentDate = new Date();

    let result = items.map((item) => {
      let row: StorageRow = {
        datePartition: this.utility.getPartitionKey(currentDate),
        sortKey: item.attributes.correlationId || this.utility.getHash(),
        correlationId: item.attributes.correlationId,
        identifiers: this.utility.getIdentifiers(item.encounter),
        createdAt: currentDate.toJSON(),
        expirationTTL: this.utility.getTTL(this.config.ttl),
        payload: item.encounter
      };

      if (item.attributes && item.attributes.cohort) {
        row.cohort = item.attributes.cohort;
      }

      if (item.attributes && item.attributes.authorization) {
        row.cognitoClientId = this.utility.getClientIdFromJWT(item.attributes.authorization);
      }

      return row;
    });
    return result;
  }
}
