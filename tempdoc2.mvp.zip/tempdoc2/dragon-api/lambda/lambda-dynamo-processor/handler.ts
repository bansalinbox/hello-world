require("source-map-support").install();

import { BatchWriteItemOutput } from "aws-sdk/clients/dynamodb";
import { Utility } from "./src/Utility";
import { DynamoDBRepository } from "./src/Repository";
import { DynamoDB } from 'aws-sdk';
import { SQSEvent } from "aws-lambda";

const dynamodb = new DynamoDB();
const utility = new Utility();
const dynamoDBRepository = new DynamoDBRepository(dynamodb, utility, {ttl: +process.env.STORAGE_TABLE_TTL});
const storageTableName = process.env.STORAGE_TABLE_NAME;
const COHORT_NAME = process.env.COHORT_NAME;
const AUTHORIZATION_TOKEN_NAME = process.env.AUTHORIZATION_TOKEN_NAME;
const CORRELATION_ID = process.env.CORRELATION_ID;

let handler = (event: SQSEvent, context, callback) => {
  try {

    let encounters = event.Records.map((record) => {
      let encounter = JSON.parse(record.body);
      return {
        encounter: encounter,
        attributes: {
          cohort: record.messageAttributes[COHORT_NAME] ? record.messageAttributes[COHORT_NAME].stringValue : null,
          authorization: record.messageAttributes[AUTHORIZATION_TOKEN_NAME] ? record.messageAttributes[AUTHORIZATION_TOKEN_NAME].stringValue : null,
          correlationId: record.messageAttributes[CORRELATION_ID] ? record.messageAttributes[CORRELATION_ID].stringValue : null
        }
      };
    });

    let batch = dynamoDBRepository.formatEncountersForBathSave(encounters);
    dynamoDBRepository.batchSaveEncounter(batch, storageTableName)
      .then(function (output: BatchWriteItemOutput) {

        if (Object.keys(output.UnprocessedItems).length) {
          utility.logCustomError("UnprocessedItemsException", <Error>{message: "Error occurred during batch save"});
          callback(new Error("Error occurred during batch save"));
        }

      })
      .catch(reason => {
        utility.logCustomError("BatchSaveException", reason);
        callback(reason);
      })
  } catch (reason) {
    utility.logCustomError("UnhandledException", reason);
    callback(reason);
  }
};

export { handler as cis };

