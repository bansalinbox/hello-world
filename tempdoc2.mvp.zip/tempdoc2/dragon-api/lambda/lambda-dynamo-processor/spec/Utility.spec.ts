import {Utility} from "../src/Utility";

describe('Utility Method tests', function () {
    let utility;

    beforeEach(function () {
      utility = new Utility();

    });


    // The following tests will confirm the getPartitionKey() function returns date
    // in correct format to be used as the datePartition key in dynamoDB table
    describe('partition key', function () {

      it('should equal 2019-01-01', function () {
        const januaryIndex = 0;
        const date = new Date(2019, januaryIndex, 1);
        const result = utility.getPartitionKey(date);
        const expectedPartitionKey = "2019-01-01";
        expect(result).toEqual(expectedPartitionKey);

      });

      it('should equal 2020-11-16', function () {
        const novemberIndex = 10;
        const date = new Date(2020, novemberIndex, 16);
        const result = utility.getPartitionKey(date);
        const expectedPartitionKey = "2020-11-16";
        expect(result).toEqual(expectedPartitionKey);
      });

    });


  describe('jwt token', function () {

    it('should parse token with Bearer', function () {
      const token_with_bearer = "Bearer eyJraWQiOiJ6SDFtQmIzOVF3SmtJUTZGWGI4NVwvUnZNcFVUZ3BDXC8rRWoxNGlwQzZrbVk9IiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiI1bmEzdHJmOHYwaW0xdWNxZW5hN2Q3dDdiMSIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoiZW5jb3VudGVyXC9wb3N0IiwiYXV0aF90aW1lIjoxNTYwOTc0ODE1LCJpc3MiOiJodHRwczpcL1wvY29nbml0by1pZHAudXMtZWFzdC0xLmFtYXpvbmF3cy5jb21cL3VzLWVhc3QtMV9JaEVONnliTTMiLCJleHAiOjE1NjA5Nzg0MTUsImlhdCI6MTU2MDk3NDgxNSwidmVyc2lvbiI6MiwianRpIjoiNWQ5ZDExNmEtZjM4ZC00YTE0LWJiZjMtYzA2M2JhMzYxMjE0IiwiY2xpZW50X2lkIjoiNW5hM3RyZjh2MGltMXVjcWVuYTdkN3Q3YjEifQ.QGvmbK6pF_2xocXD-jnicVJcjbcjUaDNPkchVQEFF1paGwaz3j-h4cm4zXwoeahBFbugpvx4KMBT3LfGvmrEFLC1lcZDCdjCCB34_SU8aCqIahMth4-TWwbs1eIAgkwdIh_l78_mNXCl6KY_U1XPN-ucrzGgQgfjv_TniO5sRE-2oBEAB8WSKqIJ6VfuBZlwNjl0kyXhDs0TsXphDakELBJ8I-3n9Iici_UL45payybA0lljcI0u73W2XeRBP9GJTMqonaeWMNId42tTnGVoxAz3OSSvFYdHqBOTXPfufRHx1rx8n4oq2u5Kj_rMJ9t7UxMtzrRugrX4OT04tVcq7w";
      const expected = "5na3trf8v0im1ucqena7d7t7b1";
      const result = utility.getClientIdFromJWT(token_with_bearer);
      expect(expected).toEqual(result);
    });

    it('should parse token without Bearer', function () {
      const token = "eyJraWQiOiJ6SDFtQmIzOVF3SmtJUTZGWGI4NVwvUnZNcFVUZ3BDXC8rRWoxNGlwQzZrbVk9IiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiI1bmEzdHJmOHYwaW0xdWNxZW5hN2Q3dDdiMSIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoiZW5jb3VudGVyXC9wb3N0IiwiYXV0aF90aW1lIjoxNTYwOTc0ODE1LCJpc3MiOiJodHRwczpcL1wvY29nbml0by1pZHAudXMtZWFzdC0xLmFtYXpvbmF3cy5jb21cL3VzLWVhc3QtMV9JaEVONnliTTMiLCJleHAiOjE1NjA5Nzg0MTUsImlhdCI6MTU2MDk3NDgxNSwidmVyc2lvbiI6MiwianRpIjoiNWQ5ZDExNmEtZjM4ZC00YTE0LWJiZjMtYzA2M2JhMzYxMjE0IiwiY2xpZW50X2lkIjoiNW5hM3RyZjh2MGltMXVjcWVuYTdkN3Q3YjEifQ.QGvmbK6pF_2xocXD-jnicVJcjbcjUaDNPkchVQEFF1paGwaz3j-h4cm4zXwoeahBFbugpvx4KMBT3LfGvmrEFLC1lcZDCdjCCB34_SU8aCqIahMth4-TWwbs1eIAgkwdIh_l78_mNXCl6KY_U1XPN-ucrzGgQgfjv_TniO5sRE-2oBEAB8WSKqIJ6VfuBZlwNjl0kyXhDs0TsXphDakELBJ8I-3n9Iici_UL45payybA0lljcI0u73W2XeRBP9GJTMqonaeWMNId42tTnGVoxAz3OSSvFYdHqBOTXPfufRHx1rx8n4oq2u5Kj_rMJ9t7UxMtzrRugrX4OT04tVcq7w";
      const expected = "5na3trf8v0im1ucqena7d7t7b1";
      const result = utility.getClientIdFromJWT(token);
      expect(expected).toEqual(result);
    });

    it('should return error string in case of corrupted token with Bearer word', function () {
      const token = "Bearer CORRUPTEDeyJraWQiOiJ6SDFtQmIzOVF3SmtJUTZGWGI4NVwvUnZNcFVUZ3BDXC8rRWoxNGlwQzZrbVk9IiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiI1bmEzdHJmOHYwaW0xdWNxZW5hN2Q3dDdiMSIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoiZW5jb3VudGVyXC9wb3N0IiwiYXV0aF90aW1lIjoxNTYwOTc0ODE1LCJpc3MiOiJodHRwczpcL1wvY29nbml0by1pZHAudXMtZWFzdC0xLmFtYXpvbmF3cy5jb21cL3VzLWVhc3QtMV9JaEVONnliTTMiLCJleHAiOjE1NjA5Nzg0MTUsImlhdCI6MTU2MDk3NDgxNSwidmVyc2lvbiI6MiwianRpIjoiNWQ5ZDExNmEtZjM4ZC00YTE0LWJiZjMtYzA2M2JhMzYxMjE0IiwiY2xpZW50X2lkIjoiNW5hM3RyZjh2MGltMXVjcWVuYTdkN3Q3YjEifQ.QGvmbK6pF_2xocXD-jnicVJcjbcjUaDNPkchVQEFF1paGwaz3j-h4cm4zXwoeahBFbugpvx4KMBT3LfGvmrEFLC1lcZDCdjCCB34_SU8aCqIahMth4-TWwbs1eIAgkwdIh_l78_mNXCl6KY_U1XPN-ucrzGgQgfjv_TniO5sRE-2oBEAB8WSKqIJ6VfuBZlwNjl0kyXhDs0TsXphDakELBJ8I-3n9Iici_UL45payybA0lljcI0u73W2XeRBP9GJTMqonaeWMNId42tTnGVoxAz3OSSvFYdHqBOTXPfufRHx1rx8n4oq2u5Kj_rMJ9t7UxMtzrRugrX4OT04tVcq7w";
      const expected = "UNKNOWN_ERROR";
      const result = utility.getClientIdFromJWT(token);
      expect(expected).toEqual(result);
    });

    it('should return error string in case of corrupted token', function () {
      const token = "CORRUPTEDeyJraWQiOiJ6SDFtQmIzOVF3SmtJUTZGWGI4NVwvUnZNcFVUZ3BDXC8rRWoxNGlwQzZrbVk9IiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiI1bmEzdHJmOHYwaW0xdWNxZW5hN2Q3dDdiMSIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoiZW5jb3VudGVyXC9wb3N0IiwiYXV0aF90aW1lIjoxNTYwOTc0ODE1LCJpc3MiOiJodHRwczpcL1wvY29nbml0by1pZHAudXMtZWFzdC0xLmFtYXpvbmF3cy5jb21cL3VzLWVhc3QtMV9JaEVONnliTTMiLCJleHAiOjE1NjA5Nzg0MTUsImlhdCI6MTU2MDk3NDgxNSwidmVyc2lvbiI6MiwianRpIjoiNWQ5ZDExNmEtZjM4ZC00YTE0LWJiZjMtYzA2M2JhMzYxMjE0IiwiY2xpZW50X2lkIjoiNW5hM3RyZjh2MGltMXVjcWVuYTdkN3Q3YjEifQ.QGvmbK6pF_2xocXD-jnicVJcjbcjUaDNPkchVQEFF1paGwaz3j-h4cm4zXwoeahBFbugpvx4KMBT3LfGvmrEFLC1lcZDCdjCCB34_SU8aCqIahMth4-TWwbs1eIAgkwdIh_l78_mNXCl6KY_U1XPN-ucrzGgQgfjv_TniO5sRE-2oBEAB8WSKqIJ6VfuBZlwNjl0kyXhDs0TsXphDakELBJ8I-3n9Iici_UL45payybA0lljcI0u73W2XeRBP9GJTMqonaeWMNId42tTnGVoxAz3OSSvFYdHqBOTXPfufRHx1rx8n4oq2u5Kj_rMJ9t7UxMtzrRugrX4OT04tVcq7w";
      const expected = "UNKNOWN_ERROR";
      const result = utility.getClientIdFromJWT(token);
      expect(expected).toEqual(result);
    });

    it('should return error string in case if token empty', function () {
      const token = "";
      const expected = "UNKNOWN_ERROR";
      const result = utility.getClientIdFromJWT(token);
      expect(expected).toEqual(result);
    });


    it('should return error string in case if token null', function () {
      const token = null;
      const expected = "UNKNOWN_ERROR";
      const result = utility.getClientIdFromJWT(token);
      expect(expected).toEqual(result);
    });

    it('should return error string in case if token undefined', function () {
      const token = undefined;
      const expected = "UNKNOWN_ERROR";
      const result = utility.getClientIdFromJWT(token);
      expect(expected).toEqual(result);
    });

  });

  // The following tests will confirm the getIdentifiers() function will transform
  // encounter payload to combine/extract identifiers as sortKey in dynamoDB table
  describe('sort key', function () {

    it('should be combination of identifiers as array ["1a5658d7-5555-401b-9ef3-ac3f29d145ac5","W2136715"]',
      function () {
      const encounter = {
        "contained": [
          {
            "resourceType": "Organization",
            "id": "a1289d72-12cb8-c123-bab2-60a365f4b4f1",
            "text": {
              "status": "generated",
              "div": "<div>My Location</div>"
            },
            "identifier": [
              {
                "system": "http://collectivemedicaltech.com",
                "value": "a1289d72-12cb8-c123-bab2-60a365f4b4f1"
              },
              {
                "system": "NPI",
                "value": "23456548"
              },
              {
                "system": "TIN",
                "value": "12565556"
              }
            ],
            "name": "My Location"
          }
        ],
        "resourceType": "Encounter",
        "status": "arrived",
        "identifier": [
          {
            "system": "http://collectivemedicaltech.com/Encounter",
            "use": "secondary",
            "value": "1a5658d7-5555-401b-9ef3-ac3f29d145ac5"
          },
          {
            "use": "temp",
            "value": "W2136715"
          }
        ],
        "reason": [
          {
            "text": "Heart Problems"
          }
        ],
        "diagnosis": [{
          "sequence": 1,
          "diagnosis": {
            "system": "http://hl7.org/fhir/sid/icd-10",
            "code": "I0981"
          }
        }]
      };

      const result = utility.getIdentifiers(encounter);
      const expectedResult = ["1a5658d7-5555-401b-9ef3-ac3f29d145ac5","W2136715"];
      result.sort();
      expectedResult.sort();
      expect(result).toEqual(expectedResult);

    });


    it('should be combination of identifiers as array ["e3dcedfe-5d16-415a-b4b7-xxxxxxx","44700351432","3543905830958390458","3f041b11-d3ae-46c5-a9d6-xxxxxxx"]',
      function () {
      const encounter =  {
        "contained" : [
          {
            "resourceType" : "Organization",
            "id" : "3f041b11-d3ae-46c5-a9d6-xxxxxxx",
            "text" : {
              "status" : "generated",
              "div" : "<div>My Location</div>"
            },
            "identifier" : [
              {
                "system" : "http://collectivemedicaltech.com",
                "value" : "3f041b11-d3ae-46c5-a9d6-xxxxxx"
              },
              {
                "system" : "NPI",
                "value" : ""
              },
              {
                "system" : "TIN",
                "value" : ""
              }
            ],
            "name" : "My Location"
          }
        ],
        "resourceType" : "Encounter",
        "status" : "finished",
        "identifier" : [
          {
            "system" : "http://collectivemedicaltech.com/Encounter",
            "use" : "secondary",
            "value" : "e3dcedfe-5d16-415a-b4b7-xxxxxxx"
          },
          {
            "use" : "temp",
            "value" : "44700351432"
          },
          {
            "use" : "test1",
            "value" : "3543905830958390458"
          },
          {
            "value" : "3f041b11-d3ae-46c5-a9d6-xxxxxxx"
          }
        ],
        "text" : {
          "status" : "generated",
          "div" : "<div>Patient had an Emergency encounter at Adventist Health Portland</div>"
        },
        "serviceProvider" : {
          "reference" : "#or_amc"
        },
        "subject" : {
          "reference" : "#e3dcedfe-5d16-415a-b4b7-xxxxxxx"
        },
        "class" : {
          "system" : "http://collectivemedicaltech.com/Encounter",
          "code" : "E",
          "display" : "Emergency"
        },
        "period" : {
          "end" : "201901170524"
        },
        "type" : [
          {
            "coding" : [
              {
                "system" : "http://collectivemedicaltech.com/Encounter",
                "code" : "0",
                "display" : "Emergency"
              }
            ]
          }
        ],
        "reason" : [
          {
            "text" : "CP"
          }
        ],
        "diagnosis" : [
          {
            "sequence" : 1,
            "diagnosis" : {
              "system" : "http://hl7.org/fhir/sid/icd-10",
              "code" : ""
            }
          }
        ]
      };

      const result = utility.getIdentifiers(encounter);
      const expectedResult = ["e3dcedfe-5d16-415a-b4b7-xxxxxxx","44700351432","3543905830958390458","3f041b11-d3ae-46c5-a9d6-xxxxxxx"];
      result.sort();
      expectedResult.sort();
      expect(result).toEqual(expectedResult);

    });

  });



});
