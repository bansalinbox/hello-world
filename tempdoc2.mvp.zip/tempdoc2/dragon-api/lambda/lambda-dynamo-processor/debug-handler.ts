//THIS TS/JS FILE CAN BE USED FOR DEBUG WITH REAL DYNAMO_DB.

import * as AWS from 'aws-sdk';

//Setup variables before any other module initializations
var credentials = new AWS.SharedIniFileCredentials({profile: 'saml'});
AWS.config.credentials = credentials;
process.env.API_VERSION = '2012-10-08';
process.env.OPPORTUNITY_TABLE_NAME = 'dev-c3po-opportunity';
process.env.REGION = 'us-east-1';
process.env.AWS_REGION = 'us-east-1';
process.env.OPPORTUNITY_TTL = '24';
process.env.STORAGE_TABLE_NAME ="fhir-exchange-storage-kristie"
process.env.STORAGE_TABLE_TTL= "720"

import { cis } from "./handler";
import { SQSEvent } from "aws-lambda";

// @ts-ignore
let payload:SQSEvent = <SQSEvent>{
  "Records": [
    {
      "messageId": "df7fa69c-a066-4789-b667-d716243a2bfe",
      "receiptHandle": "AQEBqD3NgKB/rUL7CoEjP0NCVMhAwgnY09lr4gZV9XYiZlLsBf7MUYVtm4SRT32H0l+JgBDAZrs235va1EIOO1mUDGHqS1SWEaWPBBG46N9QpjF4AgLj68LQy/vkAwmDx2T3KTY1dObFqITL5VFXctS1Xv9xENPgbtah3/UW64KE2yEJ+ZdbML3HvM8GsgfGcLsCInySDFpCb9citKow5GgsjdfaLgq0261ydEYTpHMIsfGnT2oPA7d6AJwAZFh4pz5XRDS8sooUoAUDvodq0di3X9cyNSG5dnu6P97aOGhbAL8Dwg/fql+snZSRcEn84JEiYWkC0goahBTZnacFb6C0oYihu8pVfD5EGNB0NHDKsKfN0BjZsFUpcMeW6yoCmghPt3kV/7XZlD0Q6wQ1DDSua+3dQsSEqt/YLn9XxhKXiQw=",
      "body": "{\"contained\":[{\"resourceType\":\"Organization\",\"id\":\"36658eda-12cb8-4504-bab2-60a365f4b4f1\",\"text\":{\"status\":\"generated\",\"div\":\"<div>My Location</div>\"},\"identifier\":[{\"system\":\"http://collectivemedicaltech.com\",\"value\":\"36658eda-12cb8-4504-bab2-60a365f4b4f1\"},{\"system\":\"NPI\",\"value\":\"234579887\"},{\"system\":\"TIN\",\"value\":\"98765412\"}],\"name\":\"My Location\"},{\"resourceType\":\"Patient\",\"id\":\"88565412-0701-401b-9ef3-c13f29d4545a\",\"identifier\":[{\"use\":\"usual\",\"system\":\"http://collectivemedicaltech.com/\",\"value\":\"88565412-0701-401b-9ef3-c13f29d4545a\"},{\"use\":\"usual\",\"system\":\"medicaid\",\"value\":\"WA789456361\"}],\"active\":true,\"name\":[{\"use\":\"usual\",\"family\":[\"Brain\"],\"given\":[\"Pinky\"]}],\"telecom\":[{\"system\":\"phone\",\"value\":\"8015558899\"}],\"gender\":\"female\",\"birthDate\":\"2018-07-24\",\"deceasedBoolean\":false,\"address\":[{\"line\":[\"124 Test St.\"],\"city\":\"Kennewick\",\"state\":\"WA\",\"postalCode\":\"94321\"}]}],\"resourceType\":\"Encounter\",\"status\":\"finished\",\"identifier\":[{\"system\":\"http://collectivemedicaltech.com/Encounter\",\"use\":\"secondary\",\"value\":\"1\"},{\"use\":\"temp\",\"value\":\"5\"}],\"text\":{\"status\":\"generated\",\"div\":\"<div>Patient had an Emergency encounter at Valley Health Test Hospital</div>\"},\"serviceProvider\":{\"reference\":\"#36658eda-12cb8-4504-bab2-60a365f4b4f1\"},\"subject\":{\"reference\":\"#1a5658d7-0701-401b-9ef3-c13f29d4545a\"},\"class\":{\"system\":\"http://collectivemedicaltech.com/Encounter\",\"code\":\"E\",\"display\":\"Emergency\"},\"period\":{\"start\":\"2018-07-17T16:00:00-07:00\",\"end\":\"2018-07-21T11:08:00-07:00\"},\"type\":[{\"coding\":[{\"system\":\"http://collectivemedicaltech.com/Encounter\",\"code\":\"269\",\"display\":\"Vascular Surgery\"}]}],\"reason\":[{\"text\":\"Knee Pain\"}],\"diagnosis\":[{\"sequence\":1,\"diagnosis\":{\"system\":\"http://hl7.org/fhir/sid/icd-10\",\"code\":\"W56.02XA\"}}]}",
      "attributes": {
        "ApproximateReceiveCount": "4",
        "SentTimestamp": "1560969494836",
        "SenderId": "AIDAIT2UOQQY3AUEKVGXU",
        "ApproximateFirstReceiveTimestamp": "1560969494836"
      },
      "messageAttributes": {
        "method": {
          "stringValue": "encounter",
          "dataType": "String"
        }
      },
      "md5OfBody": "0539cd0a534eefb71e2b757bd811ad7f",
      "eventSource": "aws:sqs",
      "eventSourceARN": "arn:aws:sqs:us-east-1:003856232118:fhir-exchange-storage-queue-sergii",
      "awsRegion": "us-east-1"
    }
  ]
}

// @ts-ignore
let payload2:SQSEvent = <SQSEvent>{
  "Records": [
    {
      "messageId": "5f0946e7-63ed-4c8f-a2bd-85e9b849a6c4",
      "receiptHandle": "AQEBTedn59z7UsXUXqoONO7jxGxKHJN0UO4iTMcw5iKSVE3AK2CEjEJwyBpQDGb1ERo81eHqjOIOpKd4z3RabGOQQFhyxjN4NfORrvLnHnDwxNt2LUU1iuDmPN5aXYUWMjFfrkX0coOM4L2b9UAYrCY+r383uk/wS3pa+n6fWanNItgdDSwSz76K3mHWKMlk2GIV6+MihV0kQEo9Ke91AgqnJ0GuYVZaK/t/ohDqYm5x1MocvC5Fdu5gQ/jkJW4X87SLDwXkqUqVZnmBxKkGpIhW2Gy3fTowilDttXrHZFWiI5NNJLX5suhIoCIM0E9+MV2sg3tarRX6z0X8gj14HlYH+ArSFCQMyoSuwk6cTiA4x14jVyB0MDsQ9b9BdgIRdOcYajdmdHA0z5mUCtwVBPR5cwDH1LtBDb8FWfPk6M9bmYY=",
      "body": "{\"contained\":[{\"resourceType\":\"Organization\",\"id\":\"12345\",\"text\":{\"status\":\"generated\",\"div\":\"<div>My Location</div>\"},\"identifier\":[{\"system\":\"http://collectivemedicaltech.com\",\"value\":\"12345\"},{\"system\":\"NPI\",\"value\":\"1234567890\"},{\"system\":\"TIN\",\"value\":\"\"}],\"name\":\"My Location\"},{\"resourceType\":\"Patient\",\"id\":\"028276a5-5657-48f4-89f6-f5a8s6c23fa1\",\"identifier\":[{\"use\":\"usual\",\"system\":\"http://collectivemedicaltech.com/\",\"value\":\"028276a5-56s7-48f4-89f6-f5a8b6c23fa1\"},{\"use\":\"usual\",\"system\":\"medicaid\",\"value\":\"\"},{\"use\":\"usual\",\"system\":\"EID\",\"value\":\"1122334455\"}],\"active\":true,\"name\":[{\"use\":\"usual\",\"family\":[\"SMITH\"],\"given\":[\"JOHN\"]}],\"telecom\":[{\"system\":\"phone\",\"value\":\"1234567890\"}],\"gender\":\"1\",\"birthDate\":\"1975-09-12\",\"deceasedBoolean\":false,\"address\":[{\"line\":[\"10831 MEADOW LN\"],\"city\":\"PHILADELPHIA\",\"state\":\"PA\",\"postalCode\":\"19154\"}]}],\"resourceType\":\"Encounter\",\"status\":\"arrived\",\"identifier\":[{\"system\":\"http://collectivemedicaltech.com/Encounter\",\"use\":\"secondary\",\"value\":\"56\"},{\"use\":\"temp\",\"value\":\"10987654321\"}],\"text\":{\"status\":\"generated\",\"div\":\"<div>Patient had an outpatient encounter at Providence Milwaukie Hospital</div>\"},\"serviceProvider\":{\"reference\":\"1234567890\"},\"subject\":{\"reference\":\"3\"},\"class\":{\"system\":\"http://collectivemedicaltech.com/Encounter\",\"code\":\"O\",\"display\":\"outpatient\"},\"period\":{\"start\":\"2018-12-14 09:57:33\"},\"type\":[{\"coding\":[{\"system\":\"http://collectivemedicaltech.com/Encounter\",\"code\":\"O\",\"display\":\"outpatient\"}]}],\"reason\":[{\"text\":\"haha33\"}],\"diagnosis\":[{\"sequence\":1,\"diagnosis\":{\"system\":\"http://hl7.org/fhir/sid/icd-10\",\"code\":\"Acute kidney failure, unspecified (HCC)\"}},{\"sequence\":2,\"diagnosis\":{\"system\":\"http://hl7.org/fhir/sid/icd-10\",\"code\":\"NKKK\"}}]}",
      "attributes": {
        "ApproximateReceiveCount": "1",
        "SentTimestamp": "1560977325388",
        "SenderId": "AIDAIT2UOQQY3AUEKVGXU",
        "ApproximateFirstReceiveTimestamp": "1560977325395"
      },
      "messageAttributes": {
        "authorization": {
          "stringValue": "eyJraWQiOiJ6SDFtQmIzOVF3SmtJUTZGWGI4NVwvUnZNcFVUZ3BDXC8rRWoxNGlwQzZrbVk9IiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiI1bmEzdHJmOHYwaW0xdWNxZW5hN2Q3dDdiMSIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoiZW5jb3VudGVyXC9wb3N0IiwiYXV0aF90aW1lIjoxNTYwOTc0ODE1LCJpc3MiOiJodHRwczpcL1wvY29nbml0by1pZHAudXMtZWFzdC0xLmFtYXpvbmF3cy5jb21cL3VzLWVhc3QtMV9JaEVONnliTTMiLCJleHAiOjE1NjA5Nzg0MTUsImlhdCI6MTU2MDk3NDgxNSwidmVyc2lvbiI6MiwianRpIjoiNWQ5ZDExNmEtZjM4ZC00YTE0LWJiZjMtYzA2M2JhMzYxMjE0IiwiY2xpZW50X2lkIjoiNW5hM3RyZjh2MGltMXVjcWVuYTdkN3Q3YjEifQ.QGvmbK6pF_2xocXD-jnicVJcjbcjUaDNPkchVQEFF1paGwaz3j-h4cm4zXwoeahBFbugpvx4KMBT3LfGvmrEFLC1lcZDCdjCCB34_SU8aCqIahMth4-TWwbs1eIAgkwdIh_l78_mNXCl6KY_U1XPN-ucrzGgQgfjv_TniO5sRE-2oBEAB8WSKqIJ6VfuBZlwNjl0kyXhDs0TsXphDakELBJ8I-3n9Iici_UL45payybA0lljcI0u73W2XeRBP9GJTMqonaeWMNId42tTnGVoxAz3OSSvFYdHqBOTXPfufRHx1rx8n4oq2u5Kj_rMJ9t7UxMtzrRugrX4OT04tVcq7w",
          "stringListValues": [],
          "binaryListValues": [],
          "dataType": "String"
        },
        "method": {
          "stringValue": "encounter",
          "stringListValues": [],
          "binaryListValues": [],
          "dataType": "String"
        },
        "cohort": {
          "stringValue": "default",
          "stringListValues": [],
          "binaryListValues": [],
          "dataType": "String"
        }
      },
      "md5OfBody": "2b7c8e97260aa7c07fd0579b01d20bf5",
      "eventSource": "aws:sqs",
      "eventSourceARN": "arn:aws:sqs:us-east-1:003856232118:fhir-exchange-storage-queue-sergii",
      "awsRegion": "us-east-1"
    }
  ]
}


cis(payload2, {}, (arguments1) => {
  console.log(arguments1)
});
