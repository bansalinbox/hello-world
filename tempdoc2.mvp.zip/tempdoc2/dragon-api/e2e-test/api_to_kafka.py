from fastavro import reader, parse_schema
import io
import json
import os
import requests
import sys
import time
from confluent_kafka import Consumer, KafkaError
from requests.auth import HTTPBasicAuth
from io import StringIO

# Terminal Coloring
class termColors:
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'

# Reusable items
fhirEncounterHttpMethod = "POST"
goodRequestFail = False
badRequestBodyFail = False
badRequestHeaderFail = False
kafkaTopic = "FhirPayloadDev"
client_id = os.environ['APP_CLIENT_ID']
client_secret = os.environ['APP_CLIENT_SECRET']
ca_path = os.environ['REQUESTS_CA_BUNDLE']
authURL = "https://cigna-fhir-exchange.auth.us-east-1.amazoncognito.com/oauth2/token?grant_type=client_credentials&scope=encounter/post"
encounterURL = "https://bwr31ks4ri.execute-api.us-east-1.amazonaws.com/sys/Encounter"
timeToWait = 5
numberOfTests = 100 # Default for performance testing

session = requests.Session()
session.verify = True

# Example JSON Bodies
# Bad Body has 'resourceType' removed
fhirEncounterGoodBody = '{"contained":[{"resourceType":"Organization","id":"a1289d72-12cb8-c123-bab2-60a365f4b4f1","text":{"status":"generated","div":"<div>My Location</div>"},"identifier":[{"system":"http://collectivemedicaltech.com","value":"a1289d72-12cb8-c123-bab2-60a365f4b4f1"},{"system":"NPI","value":"23456548"},{"system":"TIN","value":"12565556"}],"name":"My Location"},{"resourceType":"Patient","id":"88565412-0701-401b-9ef3-c17f2a345c67","identifier":[{"use":"usual","system":"http://collectivemedicaltech.com/","value":"88565412-0701-401b-9ef3-c17f2a345c67"},{"use":"usual","system":"medicaid","value":"WA789456554"}],"active":true,"name":[{"use":"usual","family":["Arabia"],"given":["Lawrence"]}],"telecom":[{"system":"phone","value":"8016667788"}],"gender":"male","birthDate":"2018-04-22","deceasedBoolean":false,"address":[{"line":["356 City St."],"city":"Pasco","state":"WA","postalCode":"94323"}]}],"resourceType":"Encounter","status":"arrived","identifier":[{"system":"http://collectivemedicaltech.com/Encounter","use":"secondary","value":"1a5658d7-5555-401b-9ef3-ac3f29d145ac5"},{"use":"temp","value":"M1254789"}],"text":{"status":"generated","div":"<div>Patient had an Inpatient encounter at Valley Health Test Hospital</div>"},"serviceProvider":{"reference":"#1275cf1d-12cb8-c123-bab2-60a365f4b4f1"},"subject":{"reference":"#1a5658d7-0701-401b-9ef3-c17f2a345c67"},"class":{"system":"http://collectivemedicaltech.com/Encounter","code":"I","display":"Inpatient"},"period":{"start":"2018-09-08T14:21:00-07:00"},"type":[{"coding":[{"system":"http://collectivemedicaltech.com/Encounter","code":"101","display":"Gastroenterology"}]}],"reason":[{"text":"Stomach Problems"}],"diagnosis":[{"sequence":1,"diagnosis":{"system":"http://hl7.org/fhir/sid/icd-10","code":"K210"}}]}'
fhirEncounterBadBody = '{"contained":[{"id":"a1289d72-12cb8-c123-bab2-60a365f4b4f1","text":{"status":"generated","div":"<div>My Location</div>"},"identifier":[{"system":"http://collectivemedicaltech.com","value":"a1289d72-12cb8-c123-bab2-60a365f4b4f1"},{"system":"NPI","value":"23456548"},{"system":"TIN","value":"12565556"}],"name":"My Location"},{"resourceType":"Patient","id":"88565412-0701-401b-9ef3-c17f2a345c67","identifier":[{"use":"usual","system":"http://collectivemedicaltech.com/","value":"88565412-0701-401b-9ef3-c17f2a345c67"},{"use":"usual","system":"medicaid","value":"WA789456554"}],"active":true,"name":[{"use":"usual","family":["Arabia"],"given":["Lawrence"]}],"telecom":[{"system":"phone","value":"8016667788"}],"gender":"male","birthDate":"2018-04-22","deceasedBoolean":false,"address":[{"line":["356 City St."],"city":"Pasco","state":"WA","postalCode":"94323"}]}],"resourceType":"Encounter","status":"arrived","identifier":[{"system":"http://collectivemedicaltech.com/Encounter","use":"secondary","value":"1a5658d7-5555-401b-9ef3-ac3f29d145ac5"},{"use":"temp","value":"M1254789"}],"text":{"status":"generated","div":"<div>Patient had an Inpatient encounter at Valley Health Test Hospital</div>"},"serviceProvider":{"reference":"#1275cf1d-12cb8-c123-bab2-60a365f4b4f1"},"subject":{"reference":"#1a5658d7-0701-401b-9ef3-c17f2a345c67"},"class":{"system":"http://collectivemedicaltech.com/Encounter","code":"I","display":"Inpatient"},"period":{"start":"2018-09-08T14:21:00-07:00"},"type":[{"coding":[{"system":"http://collectivemedicaltech.com/Encounter","code":"101","display":"Gastroenterology"}]}],"reason":[{"text":"Stomach Problems"}],"diagnosis":[{"sequence":1,"diagnosis":{"system":"http://hl7.org/fhir/sid/icd-10","code":"K210"}}]}'

# For how the tests did
goodRequestFail = False
badRequestBodyFail = False
badRequestHeaderFail = False

# Avro schema
avroSchema = {
    "type": "record",
    "namespace" : "com.cigna.v1_0",
    "name": "FHIR",
    "fields": [
        {
            "name": "payload",
            "type": "string"
        },
        {
            "name": "dateCreated",
            "type": "string"
        },
        {
            "name": "resourceType",
            "type": "string"
        }
    ]
}

parsedAvroSchema = parse_schema(avroSchema)
access_token = None

def get_token():
    auth_headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    login = requests.post(authURL, headers=auth_headers, auth=(client_id, client_secret), verify=False)
    loginJson = json.loads(login.text)
    return loginJson["access_token"]

access_token = get_token()

# Bad headers removes the access_token
encounterGoodHeaders = { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + access_token }
encounterBadHeaders = { 'Content-Type': 'application/json' }

def call_api(fhirHeaders, fhirPayload):
    encounterData = requests.post(encounterURL, headers=fhirHeaders, data=fhirPayload, verify=False)
    return encounterData.status_code

def setup_kafka():
    print("")
    print("Subscribing to Kafka topic: " + kafkaTopic)
    consumer = Consumer({
        'bootstrap.servers': "cilhdkfs0304.sys.cigna.com:9092,cilhdkfs0305.sys.cigna.com:9092",
        'group.id': 'FhirPayload',
        'enable.auto.commit': False,
        # 'sasl.mechanisms': 'GSSAPI',
        # 'ssl.ca.location': '/Users/b88049/Downloads/config_CARoot_int.pem',
        # 'security.protocol': 'sasl_ssl',
        # 'security.protocol': 'ssl',
        'api.version.request': True,
        'broker.version.fallback': '0.9.0',
        # 'sasl.kerberos.kinit.cmd': ' kinit -k -t /Users/b88049/Downloads/rtdesvc.keytab rtdesvc@SILVER.COM;',
    })

    consumer.subscribe([kafkaTopic])
    print("Subscribed to topic")

    return consumer

def call_and_check_topic(fhirHeaders, fhirPayload, badRequest):
    found = False
    timesUp = False
    apiCalled = False
    startTime = time.time()

    # Keep looping until time expires or the message is found
    print("Start polling topic")
    while not found and not timesUp:
        fhirMsg = consumer.poll(10)

        if not apiCalled:
            print("Calling API")
            call_api(fhirHeaders, fhirPayload)
            apiCalled = True

        if fhirMsg is None:
            print("FHIR Message is empty")
        elif fhirMsg.error() is None:
            bytes_reader = io.BytesIO(fhirMsg.value())
            for record in reader(bytes_reader, parsedAvroSchema):
                foundGoodPayload = False
                foundGoodEncounter = False


                if "payload" in record:
                    fhirPayload = json.loads(record["payload"])
                    if "contained" in fhirPayload:
                        if "id" in fhirPayload["contained"][0]:
                            foundGoodPayload = True

                if "resourceType" in record:
                    print("Found resourceType")
                    foundGoodEncounter = True

            return foundGoodPayload # and foundGoodEncounter
        elif fhirMsg.error() is not None:
            if fhirMsg.error().code() == KafkaError._PARTITION_EOF:
                print("Partition EOF for partition: " + str(fhirMsg.partition()) + " offset: " + str(fhirMsg.offset()))
            else:
                print("Error Message")
                print("    Topic: " + str(fhirMsg.topic()))
                print("    Partition: " + str(fhirMsg.partition()))
                print("    Offset: " + str(fhirMsg.offset()))
                print(fhirMsg.error())
                return False
        else:
            print("Something very wrong has happened")
            print(fhirMsg)
            return False

        currTime = time.time()

        if (currTime - startTime) >= timeToWait:
            timesUp = True

            if (not badRequest):
                print(termColors.FAIL + "ERROR: " + termColors.ENDC + "Timeout")
            else:
                print(termColors.OKBLUE + "INFO: " + termColors.ENDC + "Timeout")

            return False

    return False

def good_api_request():
    print("")
    print(termColors.OKBLUE + "SEND A GOOD REQUEST" + termColors.ENDC)
    print("")

    # Call the API and check Kafka to see if the message made it
    if (call_and_check_topic(encounterGoodHeaders, fhirEncounterGoodBody, False)):
        print("Found message")
    else:
        print("Message not found")
        goodRequestFail = True

def bad_request_body():
    print("")
    print(termColors.OKBLUE + "FAIL A BAD REQUEST BODY" + termColors.ENDC)
    print("")

    if (not call_and_check_topic(encounterGoodHeaders, fhirEncounterBadBody, True)):
        print("Message not found")
    else:
        print("Found message")
        badRequestBodyFail = True

def bad_request_header():
    print("")
    print(termColors.OKBLUE + "FAIL A BAD REQUEST HEADER" + termColors.ENDC)
    print("")

    if (not call_and_check_topic(encounterBadHeaders, fhirEncounterGoodBody, True)):
        print("Message not found")
    else:
        print("Found message")
        badRequestHeaderFail = True

def print_status_msg(status):
    if status:
        return termColors.OKGREEN + "OK:" + termColors.ENDC
    else:
        return termColors.FAIL + "FAIL:" + termColors.ENDC

print(termColors.OKBLUE + "RUNNING END-TO-END TESTING" + termColors.ENDC)

consumer = setup_kafka()
good_api_request()
bad_request_body()
bad_request_header()
consumer.close()

print("")
print(print_status_msg(not goodRequestFail) + termColors.OKBLUE + " SEND A GOOD REQUEST" + termColors.ENDC)
print(print_status_msg(not badRequestBodyFail) + termColors.OKBLUE + " FAIL A BAD REQUEST BODY" + termColors.ENDC)
print(print_status_msg(not badRequestHeaderFail) + termColors.OKBLUE + " FAIL A BAD REQUEST HEADER" + termColors.ENDC)

if goodRequestFail or badRequestBodyFail or badRequestHeaderFail:
    print(termColors.FAIL + "SOME TESTS FAILED")
    sys.exit(1)
else:
    print(termColors.OKGREEN + "TESTS COMPLETED SUCCESSFULLY" + termColors.ENDC)

sys.exit()
