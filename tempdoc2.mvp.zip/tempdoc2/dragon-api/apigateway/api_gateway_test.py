import boto3
import sys

# Boto clients and settings
boto3.setup_default_session(profile_name = 'saml')
apigateway = boto3.client('apigateway')
sqs = boto3.client('sqs')

# Terminal Coloring 
class termColors:
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'

# Reusable items
fhirEncounterApiId = "q845baa472"
fhirEncounterResourceId = "4vosvq"
fhirEncounterHttpMethod = "POST"
fhirEncounterQueue = "https://sqs.us-east-1.amazonaws.com/003856232118/CmtTest"
goodRequestFail = False
badRequestBodyFail = False
badRequestHeaderFail = False

# Example JSON Bodies 
# Bad Body has 'resourceType' removed
fhirEncounterGoodBody = '{"contained":[{"resourceType":"Organization","id":"a1289d72-12cb8-c123-bab2-60a365f4b4f1","text":{"status":"generated","div":"<div>My Location</div>"},"identifier":[{"system":"http://collectivemedicaltech.com","value":"a1289d72-12cb8-c123-bab2-60a365f4b4f1"},{"system":"NPI","value":"23456548"},{"system":"TIN","value":"12565556"}],"name":"My Location"},{"resourceType":"Patient","id":"88565412-0701-401b-9ef3-c17f2a345c67","identifier":[{"use":"usual","system":"http://collectivemedicaltech.com/","value":"88565412-0701-401b-9ef3-c17f2a345c67"},{"use":"usual","system":"medicaid","value":"WA789456554"}],"active":true,"name":[{"use":"usual","family":["Arabia"],"given":["Lawrence"]}],"telecom":[{"system":"phone","value":"8016667788"}],"gender":"male","birthDate":"2018-04-22","deceasedBoolean":false,"address":[{"line":["356 City St."],"city":"Pasco","state":"WA","postalCode":"94323"}]}],"resourceType":"Encounter","status":"arrived","identifier":[{"system":"http://collectivemedicaltech.com/Encounter","use":"secondary","value":"1a5658d7-5555-401b-9ef3-ac3f29d145ac5"},{"use":"temp","value":"M1254789"}],"text":{"status":"generated","div":"<div>Patient had an Inpatient encounter at Valley Health Test Hospital</div>"},"serviceProvider":{"reference":"#1275cf1d-12cb8-c123-bab2-60a365f4b4f1"},"subject":{"reference":"#1a5658d7-0701-401b-9ef3-c17f2a345c67"},"class":{"system":"http://collectivemedicaltech.com/Encounter","code":"I","display":"Inpatient"},"period":{"start":"2018-09-08T14:21:00-07:00"},"type":[{"coding":[{"system":"http://collectivemedicaltech.com/Encounter","code":"101","display":"Gastroenterology"}]}],"reason":[{"text":"Stomach Problems"}],"diagnosis":[{"sequence":1,"diagnosis":{"system":"http://hl7.org/fhir/sid/icd-10","code":"K210"}}]}'
fhirEncounterBadBody = '{"contained":[{"id":"a1289d72-12cb8-c123-bab2-60a365f4b4f1","text":{"status":"generated","div":"<div>My Location</div>"},"identifier":[{"system":"http://collectivemedicaltech.com","value":"a1289d72-12cb8-c123-bab2-60a365f4b4f1"},{"system":"NPI","value":"23456548"},{"system":"TIN","value":"12565556"}],"name":"My Location"},{"resourceType":"Patient","id":"88565412-0701-401b-9ef3-c17f2a345c67","identifier":[{"use":"usual","system":"http://collectivemedicaltech.com/","value":"88565412-0701-401b-9ef3-c17f2a345c67"},{"use":"usual","system":"medicaid","value":"WA789456554"}],"active":true,"name":[{"use":"usual","family":["Arabia"],"given":["Lawrence"]}],"telecom":[{"system":"phone","value":"8016667788"}],"gender":"male","birthDate":"2018-04-22","deceasedBoolean":false,"address":[{"line":["356 City St."],"city":"Pasco","state":"WA","postalCode":"94323"}]}],"resourceType":"Encounter","status":"arrived","identifier":[{"system":"http://collectivemedicaltech.com/Encounter","use":"secondary","value":"1a5658d7-5555-401b-9ef3-ac3f29d145ac5"},{"use":"temp","value":"M1254789"}],"text":{"status":"generated","div":"<div>Patient had an Inpatient encounter at Valley Health Test Hospital</div>"},"serviceProvider":{"reference":"#1275cf1d-12cb8-c123-bab2-60a365f4b4f1"},"subject":{"reference":"#1a5658d7-0701-401b-9ef3-c17f2a345c67"},"class":{"system":"http://collectivemedicaltech.com/Encounter","code":"I","display":"Inpatient"},"period":{"start":"2018-09-08T14:21:00-07:00"},"type":[{"coding":[{"system":"http://collectivemedicaltech.com/Encounter","code":"101","display":"Gastroenterology"}]}],"reason":[{"text":"Stomach Problems"}],"diagnosis":[{"sequence":1,"diagnosis":{"system":"http://hl7.org/fhir/sid/icd-10","code":"K210"}}]}'

def good_request():
    print("")
    print(termColors.OKBLUE + "SEND A GOOD REQUEST" + termColors.ENDC)
    print("")

    beforeMessageCount = sqs.get_queue_attributes(
        QueueUrl = fhirEncounterQueue,
        AttributeNames = ['ApproximateNumberOfMessages']
    )

    print("Current number of messages: " + beforeMessageCount["Attributes"]["ApproximateNumberOfMessages"])

    apiresponse = apigateway.test_invoke_method(
        restApiId = fhirEncounterApiId,
        resourceId = fhirEncounterResourceId,
        httpMethod = fhirEncounterHttpMethod,
        body = fhirEncounterGoodBody,
        headers = {
            'Authorization': 'string'
        }
    )

    print("Response code from server: " + str(apiresponse["status"]))

    if (apiresponse["status"] == 200):
        print(print_status_msg(True) + " API Gateway")
    else: 
        print(print_status_msg(False) + " API Gateway had a response code other than 200")
        goodRequestFail = True

    afterMessageCount = sqs.get_queue_attributes(
        QueueUrl = fhirEncounterQueue,
        AttributeNames = ['ApproximateNumberOfMessages']
    )

    print("Current number of messages: " + afterMessageCount["Attributes"]["ApproximateNumberOfMessages"])

    if (int(afterMessageCount["Attributes"]["ApproximateNumberOfMessages"]) == (int(beforeMessageCount["Attributes"]["ApproximateNumberOfMessages"]) + 1)):
        print(print_status_msg(True) + " SQS messages increased by 1")
    else: 
        print(print_status_msg(False) + " Wrong SQS message count")
        goodRequestFail = False

def bad_request_body():
    print("")
    print(termColors.OKBLUE + "FAIL A BAD REQUEST BODY" + termColors.ENDC)
    print("")

    beforeMessageCount = sqs.get_queue_attributes(
        QueueUrl = fhirEncounterQueue,
        AttributeNames = ['ApproximateNumberOfMessages']
    )

    print("Current number of messages: " + beforeMessageCount["Attributes"]["ApproximateNumberOfMessages"])

    apiresponse = apigateway.test_invoke_method(
        restApiId = fhirEncounterApiId,
        resourceId = fhirEncounterResourceId,
        httpMethod = fhirEncounterHttpMethod,
        body = fhirEncounterBadBody,
        headers = {
            'Authorization': 'string'
        }
    )

    print("Response code from server: " + str(apiresponse["status"]))

    if (apiresponse["status"] != 200):
        print(print_status_msg(True) + " API Gateway failed properly")
    else: 
        print(print_status_msg(False) + " API Gateway did not validate message body properly")
        badRequestBodyFail = True

    afterMessageCount = sqs.get_queue_attributes(
        QueueUrl = fhirEncounterQueue,
        AttributeNames = ['ApproximateNumberOfMessages']
    )

    print("Current number of messages: " + afterMessageCount["Attributes"]["ApproximateNumberOfMessages"])

    if (afterMessageCount["Attributes"]["ApproximateNumberOfMessages"] == beforeMessageCount["Attributes"]["ApproximateNumberOfMessages"]):
        print(print_status_msg(True) + " SQS Messages stayed the same")
    else: 
        print(print_status_msg(False) + " SQS Messages changed")
        badRequestBodyFail = True

def bad_request_header():
    print("")
    print(termColors.OKBLUE + "FAIL A BAD REQUEST HEADER" + termColors.ENDC)
    print("")

    beforeMessageCount = sqs.get_queue_attributes(
        QueueUrl = fhirEncounterQueue,
        AttributeNames = ['ApproximateNumberOfMessages']
    )

    print("Current number of messages: " + beforeMessageCount["Attributes"]["ApproximateNumberOfMessages"])

    apiresponse = apigateway.test_invoke_method(
        restApiId = fhirEncounterApiId,
        resourceId = fhirEncounterResourceId,
        httpMethod = fhirEncounterHttpMethod,
        body = fhirEncounterGoodBody
    )

    print("Response code from server: " + str(apiresponse["status"]))
    if (apiresponse["status"] != 200):
        print(print_status_msg(True) + " API Gateway failed properly")
    else: 
        print(print_status_msg(False) + " API Gateway did not validate message body properly")
        badRequestHeaderFail = True

    afterMessageCount = sqs.get_queue_attributes(
        QueueUrl = fhirEncounterQueue,
        AttributeNames = ['ApproximateNumberOfMessages']
    )

    print("Current number of messages: " + afterMessageCount["Attributes"]["ApproximateNumberOfMessages"])

    if (afterMessageCount["Attributes"]["ApproximateNumberOfMessages"] == beforeMessageCount["Attributes"]["ApproximateNumberOfMessages"]):
        print(print_status_msg(True) + " SQS Messages stayed the same")
    else: 
        print(print_status_msg(False) + " SQS Messages changed")
        badRequestHeaderFail = True

def print_status_msg(status):
    if status:
        return termColors.OKGREEN + "OK:" + termColors.ENDC
    else:
        return termColors.FAIL + "FAIL:" + termColors.ENDC

good_request()
bad_request_body()
bad_request_header()

print("")
print(print_status_msg(not goodRequestFail) + termColors.OKBLUE + " SEND A GOOD REQUEST" + termColors.ENDC)
print(print_status_msg(not badRequestBodyFail) + termColors.OKBLUE + " FAIL A BAD REQUEST BODY" + termColors.ENDC)
print(print_status_msg(not badRequestHeaderFail) + termColors.OKBLUE + " FAIL A BAD REQUEST HEADER" + termColors.ENDC)

if goodRequestFail or badRequestBodyFail or badRequestHeaderFail:
    print(termColors.FAIL + "SOME TESTS FAILED")
    sys.exit(1)
else:
    print(termColors.OKGREEN + "TESTS COMPLETED SUCCESSFULLY" + termColors.ENDC)


sys.exit()
