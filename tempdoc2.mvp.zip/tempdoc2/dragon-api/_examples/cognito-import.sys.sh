#!/usr/bin/env sh

#terraform import module.cognito.aws_cognito_user_pool.pool USER_POOL_ID
#terraform import module.cognito.aws_cognito_user_pool_domain.domain DOMAINE_NAME
#terraform import module.cognito.aws_cognito_resource_server.server  "UserPoolID|Identifier"
#terraform import aws_cognito_user_pool_client.client 'UserPoolID/client-id'

USER_POOL_ID
terraform import module.cognito.aws_cognito_user_pool.pool us-east-1_ccJJAeKdH
terraform import module.cognito.aws_cognito_user_pool_domain.domain cigna-fhir-exchange-kristie
terraform import module.cognito.aws_cognito_resource_server.server  "us-east-1_ccJJAeKdH|encounter"
terraform import  module.cognito.aws_cognito_user_pool_client.client 'us-east-1_ccJJAeKdH/703pptdqhmv9soq59f9actn9ul'
