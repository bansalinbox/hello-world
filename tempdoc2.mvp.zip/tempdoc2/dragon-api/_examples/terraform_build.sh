#!/usr/bin/env sh

ENV_COMPUTED_NAME = 'sys'

pushd lambda/lambda-dynamo-processor
npm i
npm run webpack
aws s3 cp s3://dragon-api-secrets-${ENV_COMPUTED_NAME}/cigna.pem ./.webpack --profile saml
pushd ./.webpack/
zip -r lambda.zip .
popd
popd

pushd lambda/lambda-auth-rotation
npm i
npm run webpack
aws s3 cp s3://dragon-api-secrets-${ENV_COMPUTED_NAME}/cigna.pem ./.webpack --profile saml
pushd ./.webpack/
zip -r lambda.zip .
popd
popd

echo "Packaging lambda ${FOLDER_PATH} to ${ENV_COMPUTED_NAME} config..."
cd ${FOLDER_PATH}
aws s3 cp s3://dragon-api-secrets-${ENV_COMPUTED_NAME}/rtdesvc-${ENV_COMPUTED_NAME}.keytab .
aws s3 cp s3://dragon-api-secrets-${ENV_COMPUTED_NAME}/cigna-certs.${ENV_COMPUTED_NAME}.jks .
mkdir -p com/cigna/fhir && cp rtdesvc-${ENV_COMPUTED_NAME}.keytab com/cigna/fhir/rtdesvc.keytab && zip -u target/lambda-kafka-producer-${APP_VERSION}.jar com/cigna/fhir/rtdesvc.keytab
mkdir -p com/cigna/fhir && cp cigna-certs.${ENV_COMPUTED_NAME}.jks com/cigna/fhir/cigna-certs.jks && zip -u target/lambda-kafka-producer-${APP_VERSION}.jar com/cigna/fhir/cigna-certs.jks


lambda/lambda-kafka-producer
