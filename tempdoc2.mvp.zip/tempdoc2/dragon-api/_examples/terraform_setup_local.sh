#This is an example how to setup terraform for local run with all variables
#Run these commands in terraform root folder

TERRAFORM_COMMAND="plan"
TERRAFORM_COMMAND="init"
TERRAFORM_COMMAND="destroy"
TERRAFORM_COMMAND="apply"
STAGE_NAME="ff1"
CONFIG_NAME_DEFAULT="sys"
ENV_COMPUTED_NAME="sys"
FHIR_INGRESS_SNS_NAME="fhir-exchange-ingress-sns-${STAGE_NAME}"
ENABLE_CLOUDWATCH_ALERTS="false"
APP_DATA_TO_KAFKA_IMAGE_NAME="fhir-dragon-api"
ENABLE_CMT_ELIGIBILITY_MODULE="false"

terraform ${TERRAFORM_COMMAND} \
   -var stage=${STAGE_NAME} \
   -var env=${ENV_COMPUTED_NAME} \
   -var enable_cloudwatch_alarms=${ENABLE_CLOUDWATCH_ALERTS} \
   -var enable_cmt_eligibility_module=${ENABLE_CMT_ELIGIBILITY_MODULE} \
   -var data_to_kafka_image_name=${APP_DATA_TO_KAFKA_IMAGE_NAME} \
   -var-file=../terraform-env-config/${CONFIG_NAME_DEFAULT}.tfvars \
   -var-file=../terraform-env-config/${CONFIG_NAME_DEFAULT}-shared.tfvars \
   -var fhir_ingress_sns_name=${FHIR_INGRESS_SNS_NAME} \
   -lock=false                                        \
   -target=module.data_to_kafka
