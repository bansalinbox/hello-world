# DynamoDB

We store data in `fhir-exchange-storage-{env}` table with TTL 30 days. 

Table structure:

```json5
 {
   datePartition: string,
   sortKey: string,
   identifiers: Array<string>,
   payload: any,
   createdAt: string,
   expirationTTL?: number
 }
```

`identifiers` - string set where identifiers are extracted from FHIR object