# Lambda
Gateway for com.amazonaws.us-east-1.dynamodb should be created to allow Lambda talk from vpc to DynamoDB.
 
## Lambda:Dynamo processor
This lambda takes payload from SQS and saves it into DynamoDB.

Environment variables that should be set for Node.js Lambda runtime:  

      NODE_EXTRA_CA_CERTS: '/var/task/cigna.pem' 

`cigna.pem` file should be included in lambda build process.
`cigna.pem` - is stored in s3 bucket( `dragon-api-secrets-sys`, `dragon-api-secrets-pvs`, `dragon-api-secrets-prod`)

## Lambda:Http server lambda

##### Certificate 
Certificate should be provided for call to Http Server in open shift. It should be added to S3 bucket( diferent than current cigna.pem). 
##### Route 53 (dns resolution)
Record in Route 53 should be created for http server.  
To get IPs use this command.  
```
nslookup {ENV}-fhir-httpserver.oscp-ext-a.silver.com
```  
`{ENV}` - environment prefix/suffix.

## Lambda:Secret Auth Rotation
This lambda is using `Cognito` and `Secret Manager inside`  
##### Cognito
Security group should allow all outgoing traffic for that lambda (TCP and UDP).  
Subnet is properly configured.   

##### SM
for SM Endpoint should be created and port 443 is opened (TCP).

## Logging 

|Environment|CloudWatch Log Group|
|-----------|--------------------|
|Dev|[/aws/lambda/fhir-exchange-dynamo-data-processor-sys](https://console.aws.amazon.com/cloudwatch/home?region=us-east-1#logStream:group=/aws/lambda/fhir-exchange-dynamo-data-processor-sys;streamFilter=typeLogStreamPrefix)|
|PVS|[/aws/lambda/fhir-exchange-dynamo-data-processor-pvs](https://console.aws.amazon.com/cloudwatch/home?region=us-east-1#logStream:group=/aws/lambda/fhir-exchange-dynamo-data-processor-pvs;streamFilter=typeLogStreamPrefix)|
|Prod|[/aws/lambda/fhir-exchange-dynamo-data-processor-prod](https://console.aws.amazon.com/cloudwatch/home?region=us-east-1#logStream:group=/aws/lambda/fhir-exchange-dynamo-data-processor-prod;streamFilter=typeLogStreamPrefix)|


## Kafka producer

The Lambda function takes input from the SQS and pushes the messages to a Kafka topic in Cigna's data center. 

> **NOTE:** Sometimes the SQS capability that triggers the Lambda function is not "enabled" after deployment. This can be fixed by logging into the AWS Console with a role of at least `SUPPORTADMIN` and hitting the toggle switch to enable the trigger. 

### Lambda Information / Kafka Connection Information 

* **Lambda Execution Role** - `arn:aws:lambda:{region}:{CISAccountNumber}:function:fhir-exchange-kafka-producer-{env}` provides: 
    * Read/Write Access to SQS queue `fhir-exchange-queue-{env}`
    * Write Access to CloudWatch (see Logging section below for more details)
* **VPC** - Runs in `CIS-CMT-DEV-USEast1-VPC` (`vpc-06d60a861b092c43f`)
* **Kafka Topic** - `FhirPayload{Env}`
* **Kafka Timeout** - 60000
* **SASL_SSL Information**
    * *Kerberos Login* - `rtdesvc`
    * *SASL_SSL Mechanism* - GSSAPI

> **NOTE:** DNS resolution between the Cigna data center and AWS does not yet exist. This requires routing to be established in Route 53 as private hosted zones. The Kafka brokers are configured in Route 53 as part of a one-time configuration. Any additional Kakfa brokers require both firewall access requests from AWS to Cigna and adding the new broker server names to the private hosted zone in Route 53. For the list of current Kafka servers, please see the link for "Current Kafka Infrastructure" in the "Firewall Requests" section below. 

### Firewall Requests

In order to post messages to Kafka, the Lambda function requires access to LDAP servers and **ALL** Kafka brokers. Below are relevant lists for what firewall requests were put into place to support sending messages to Kafka.

* [Current Kafka Infrastructure](https://confluence.sys.cigna.com/display/AIS/Kafka+-+AIS+Infrastructure)
* [Firewall Requests for Development](https://confluence.sys.cigna.com/display/CLIS/DEVELOPMENT)
* [Firewall Requests for Test](https://confluence.sys.cigna.com/display/CLIS/RTDE+Test+account)
* [Firewall Requests for Prod](https://confluence.sys.cigna.com/display/CLIS/RTDE+Prod+account)

### Avro

Rather than only push the message based on the payload from the third party, the Lambda function sends additional metadata as part of the Avro schema. The below is the Avro specification (AVSC) that is sent on the Kafka Topic. A few notes: 

* `resourceType` - The API resource this data represents (e.g. Encounter)
* `payload` - Data received from the API resource
* `rcd_ty` - Field required by the Big Data team to persist to HBase/Hive
* `dateCreated` - The date/time that the request is received

```JSON
{
    "type": "record",
    "namespace" : "com.cigna.v1_0",
    "name": "FHIR",
    "fields": [
        {
            "name": "resourceType",
            "type": "string"
        },
        {
            "name": "payload",
            "type": "string"
        },
        {
            "name": "rcd_ty",
            "type": "string"
        },
        {
            "name": "dateCreated",
            "type": "string"
        }
    ]
};
```

### Logging 

|Environment|CloudWatch Log Group|
|-----------|--------------------|
|Dev|[/aws/lambda/fhir-exchange-kafka-producer-sys](https://console.aws.amazon.com/cloudwatch/home?region=us-east-1#logStream:group=/aws/lambda/fhir-exchange-kafka-producer-sys;streamFilter=typeLogStreamPrefix)|
|PVS|[/aws/lambda/fhir-exchange-kafka-producer-pvs](https://console.aws.amazon.com/cloudwatch/home?region=us-east-1#logStream:group=/aws/lambda/fhir-exchange-kafka-producer-pvs;streamFilter=typeLogStreamPrefix)|
|Prod|[/aws/lambda/fhir-exchange-kafka-producer-prod](https://console.aws.amazon.com/cloudwatch/home?region=us-east-1#logStream:group=/aws/lambda/fhir-exchange-kafka-producer-prod;streamFilter=typeLogStreamPrefix)|

## Secret Management (S3)

AWS Secret Manager provides the ability to manage secrets. However, secrets are stored as string data. The keytab file needed for login to LDAP/Kerberos is a binary file, which prevents the Dragon API from using it directly. Instead, when the Lambda is being built, the secrets are pulled from the S3 bucket and inserted into the JAR. This is what is uploaded to Lambda for execution. This also ensures that secrets are not stored in GitLab. 

|Environment|S3 Bucket|
|-----------|---------|
|Dev|[dev-fhir-secret-bucket](https://s3.console.aws.amazon.com/s3/buckets/dev-fhir-secret-bucket/?region=us-east-1&tab=overview)|
|PVS|[pvs-fhir-secret-bucket](https://s3.console.aws.amazon.com/s3/buckets/pvs-fhir-secret-bucket/?region=us-east-1&tab=overview)|
|Prod|[prod-fhir-secret-bucket](https://s3.console.aws.amazon.com/s3/buckets/prod-fhir-secret-bucket/?region=us-east-1&tab=overview)|
