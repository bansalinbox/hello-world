# KMS

CMK key is used in SSE for: `sns`, `sqs` and also in `lambda` to decrypt messages from sqs. 
Instead of using CMK key directly we are using alias name.