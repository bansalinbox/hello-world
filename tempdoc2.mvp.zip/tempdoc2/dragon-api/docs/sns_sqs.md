# SNS & SQS

The goal of APIs with a POST method is to get data back to Cigna for additional processing and analysis. To do so, the Lambda is invoked by SQS, which then takes the message and sends to a Kafka topic in Cigna. 

```visjsdiagram
    "args": {
        "width": "800",
        "height": "500"
    },
    "nodes": [
        {"id": 1, "size": 30, "image": "https://d2m4acy5lozmcy.cloudfront.net/app-services/ApplicationServices_AmazonAPIGateway.svg", "font": { "size": 12, "face": "Roboto" }, "label": "API Gateway\n(HeavenGate)", "shape": "image", "margin": 35 },
        {"id": 2, "size": 30, "image": "https://d2m4acy5lozmcy.cloudfront.net/messaging/Messaging_AmazonSQS.svg", "font": { "size": 12, "face": "Roboto" }, "label": "fhir-exchange-queue-{env}\n(SQS)", "shape": "image", "margin": 35 },
        {"id": 3, "size": 30, "image": "https://d2m4acy5lozmcy.cloudfront.net/compute/Compute_AWSLambda.svg", "font": { "size": 12, "face": "Roboto" }, "label": "fhir-exchange-kafka-producer-{env}\n(Lambda)", "shape": "image", "margin": 35 },
        {"id": 4, "size": 30, "image": "https://d2m4acy5lozmcy.cloudfront.net/storage/Storage_AmazonS3.svg", "font": { "size": 12, "face": "Roboto" }, "label": "{env}-fhir-secret-bucket\n(S3)", "shape": "image", "margin": 35 },
        {"id": 5, "group": "cigna", "size": 30, "image": "https://d2m4acy5lozmcy.cloudfront.net/general/General_traditionalserver.svg", "font": { "size": 12, "face": "Roboto" }, "label": "LDAP Server", "shape": "image", "margin": 35 },
        {"id": 6, "group": "cigna", "size": 30, "image": "https://www.vectorlogo.zone/logos/apache_kafka/apache_kafka-vertical.svg", "font": { "size": 12, "face": "Roboto" }, "label": "FhirPayload{env}", "shape": "image", "margin": 35 },
        {"id": 7, "group": "cigna", "size": 30, "image": "https://d2m4acy5lozmcy.cloudfront.net/general/General_genericdatabase.svg", "font": { "size": 12, "face": "Roboto" }, "label": "pda_inbound", "shape": "image", "margin": 35 },
        {"id": 8, "size": 30, "image": "https://d2m4acy5lozmcy.cloudfront.net/mgmt-tools/ManagementTools_AmazonCloudWatch.svg", "font": { "size": 12, "face": "Roboto" }, "label": "CloudWatch", "shape": "image", "margin": 35 },         
        {"id": 9, "size": 30, "image": "https://d2m4acy5lozmcy.cloudfront.net/security-id-compliance/SecurityIdentityCompliance_AWSKMS.svg", "font": { "size": 12, "face": "Roboto" }, "label": "fhir-exchange-{env}\n(KMS)", "shape": "image", "margin": 35 }, 
        {"id": 10, "size": 30, "image": "https://d2m4acy5lozmcy.cloudfront.net/messaging/Messaging_AmazonSNS.svg", "font": { "size": 12, "face": "Roboto" }, "label": "fhir-exchange-ingress-sns-{env}\n(SNS)", "shape": "image", "margin": 35 },
        {"id": 11, "size": 30, "image": "https://d2m4acy5lozmcy.cloudfront.net/messaging/Messaging_AmazonSQS.svg", "font": { "size": 12, "face": "Roboto" }, "label": "fhir-exchange-storage-queue-{env}\n(SQS)", "shape": "image", "margin": 35 },
        {"id": 12, "size": 30, "image": "https://d2m4acy5lozmcy.cloudfront.net/database/Database_AmazonDynamoDB.svg", "font": { "size": 12, "face": "Roboto" }, "label": "fhir-exchange-storage-{env}\n(DynamoDB)", "shape": "image", "margin": 35 },
        {"id": 13, "size": 30, "image": "https://d2m4acy5lozmcy.cloudfront.net/compute/Compute_AWSLambda.svg", "font": { "size": 12, "face": "Roboto" }, "label": "fhir-exchange-dynamo-data-processor-{env}\n(Lambda)", "shape": "image", "margin": 35 }
    ],
    "edges": [
        {"from": 1, "to": 10, "color": {"color": "black", "inherit": false}},
        {"from": 10, "to": 2, "color": {"color": "black", "inherit": false}},
        {"from": 10, "to": 11, "color": {"color": "black", "inherit": false}},
        {"from": 11, "to": 13, "color": {"color": "black", "inherit": false}},
        {"from": 13, "to": 12, "color": {"color": "black", "inherit": false}},
        {"from": 2, "to": 3, "color": {"color": "black", "inherit": false}},
        {"from": 3, "to": 4, "color": {"color": "black", "inherit": false}},
        {"from": 3, "to": 5, "color": {"color": "black", "inherit": false}},
        {"from": 3, "to": 6, "color": {"color": "black", "inherit": false}},
        {"from": 6, "to": 7, "color": {"color": "black", "inherit": false}},
        {"from": 3, "to": 8, "color": {"color": "black", "inherit": false}},
        {"from": 2, "to": 9, "color": {"color": "black", "inherit": false}},
        {"from": 4, "to": 9, "color": {"color": "black", "inherit": false}},
        {"from": 9, "to": 10, "color": {"color": "black", "inherit": false}},
        {"from": 9, "to": 11, "color": {"color": "black", "inherit": false}}
    ],
    "options": {
        "layout": {
            "randomSeed": 187605
        }        
    }
```

## SNS Configuration

The SNS topic receives messages from the API Gateway and forwards them to the SQS queues listed below. A naming convention of `fhir-exchange-ingress-sns-{env}` is used for the topic. SSE is enabled for the topic. 

## SQS Configuration

There are a few highlights that are a part of the SQS Configuration

* **Naming** - SQS naming follows a format of `fhir-exchange-*queue-{env}` where `{env}` is the particular environment for that queue
* **Server Side Encryption (SSE)** - Uses an AWS KMS Customer Master Key. The CMK name is `fhir-exchange-{env}`
* **Batch Processing Size** - Lambdas are charged for a minimum execution time. Rather than have an individual Lambda spin up for each invocation, SQS can send 10 messages at a time rather than individual messages. This is an intelligent invocation that invokes the Lambda when messages are present or up to 10 at a single invocation. 

### fhir-exchange-queue

This Queue is connected to `lambda-kafka-producer` lambda.

### fhir-exchange-storage-queue

This Queue is connected to `lambda-dynamo-producer` lambda.