# Deployment

There are several options how to deployment:

### 0. Before deployment
- If you deploy from your local machine, make sure that an S3 bucket is created for [Terraform](https://terraform.io).
- If you deploy from the GitLab pipeline, make sure that your S3 bucket is created by the deployment job
- Make sure that you have AWSServiceRoleForECS iam service role in your account, can be added with:
`aws iam create-service-linked-role --aws-service-name ecs.amazonaws.com`

### From gitlab ci

#### sys, pvs, master branches
When you merge to one of this branches pipeline will be created.  
`sys branch` corresponds to `SYS environment`.    
`pvs branch` corresponds to `PVS environment`.    
`master branch` corresponds to `PROD environment`.    
  
Just press buttons and magic will happen.  

> To make you life like an adventure there are some other options, enjoy:

#### Run CI from your favorite (feature) branch. For `SYS` and `PVS` environment
So, you are so brave to get a new task and you probably created feature branch, I hope you use also naming convention `feature/Task_Number_Some_short_description`, right?

Than you can specify in commit message this key words:  
##### To select environment to deploy:  
`[deploy-sys]` - will create pipeline for SYS environment.  
`[deploy-pvs]` - will create pipeline for PVS environment.  

##### To modify name of resources, this is helpful if you want to create new aws pipeline  
`[stage-YOURCUSTOMENAME]` - will add YOURCUSTOMENAME to resource name.   

##### Run Pipeline button in CI 
You can create gitlab pipeline from any branch.  
FOR `sys, pvs, master branch` you can override stage and config by setting those env variables:  
`SLS_STAGE` - set config name. `SLS_STAGE` overrides value of `[stage-YOURCUSTOMENAME]` if that present in commit message  
`SLS_CONFIG` - set stage name. `SLS_CONFIG` overrides value of `[config-...]` if that present in commit message  

Keep in mind if you create gitlab pipeline for any other branch It will run only if there is a text `[deploy-sys]` or `[deploy-pvs]` in last commit message.  
Also 

### Commit message examples
`Launch jobs via commit messages [deploy-sys]`  
`Launch jobs via commit messages [deploy-pvs][config-sys][stage-nametest]`  
`Launch jobs via commit messages [deploy-pvs][config-sys]`  
 