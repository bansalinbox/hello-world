# Cognito

Cogntio allows the Dragon API to create IDs and secrets for each partner with which Cigna wants to exchange data. This coupled with OAuth scopes allows Cigna to control access to operations for each partner at a detailed level. The Dragon API uses a User Pool with defined clients. Below discusses the various pieces of configuration to support the Dragon API. 

## App Client

Since the Dragon API is working with third party partners rather than individual customers, "app clients" are created. In order for the proper OAuth scopes to be associatd to a client, "App Client Settings" are defined. The required settings are "Client Credentials" and Custom Scopes are associated to the "App Client"  

> **NOTE:** A single read permission must be granted for the app client. This can and should be something that would never be populated such as website. 

## Cognito Domain

For the app pool an Amazon Cognito domain is defined. This is done because the Cloudfront distribution owns `*.fhir.cigna.com`. For each environment a domain is defined as `https://cigna-fhir-exchange-{env}.auth.us-east-1.amazoncognito.com`.

## Resource Servers 

A resource server is where custom scopes are defined. Each method defined in API Gateway will need a corresponding resrouce in Cognito and each HTTP Verb in API Gateway has a corresponding scope name. For the purposes of the Dragon API, custom scopes are defined using the following format `{resource}/{method}` (e.g. `encounter/post`). 

### Cognito User Pools
As of 10/23/2018, there is no cloud formation support for App Client configuration. This means a user will have to manually create App Clients in Cognito for any 3rd party we support.

This article describes the steps needed:
https://medium.com/@awskarthik82/part-1-securing-aws-api-gateway-using-aws-cognito-oauth2-scopes-410e7fb4a4c0

There is a work around though. Users have implemented custom AWS resources to generate the App Client automatically. See the following resources:  
[Stack overflow answer](https://stackoverflow.com/questions/49524493/cloudformation-cognito-how-to-setup-app-client-settings-domain-and-federated/50980165#50980165)  
[AWS Custom Resource doc](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/template-custom-resources.html)  
[GitHub code example](https://github.com/rosberglinhares/CloudFormationCognitoCustomResources)  
