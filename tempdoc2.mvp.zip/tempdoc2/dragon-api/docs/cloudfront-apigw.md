# Cloudfront and API Gateway

AKA leveraging HeavenGate

```visjsdiagram
    "args": {
        "width": "600",
        "height": "500"
    },
    "nodes": [
        {"id": 1, "size": 30, "image": "https://d2m4acy5lozmcy.cloudfront.net/general/General_client.svg", "font": { "size": 12, "face": "Roboto" }, "label": "Third Party", "shape": "image", "margin": 35 },
        {"id": 2, "size": 30, "image": "https://d2m4acy5lozmcy.cloudfront.net/network-cdn/NetworkingContentDelivery_AmazonCloudFront.svg", "font": { "size": 12, "face": "Roboto" }, "label": "Cloudfront\n(HeavenGate)", "shape": "image", "margin": 35 },
        {"id": 3, "size": 30, "image": "https://d2m4acy5lozmcy.cloudfront.net/app-services/ApplicationServices_AmazonAPIGateway.svg", "font": { "size": 12, "face": "Roboto" }, "label": "API Gateway\n(HeavenGate)", "shape": "image", "margin": 35 },
        {"id": 4, "size": 30, "image": "https://d2m4acy5lozmcy.cloudfront.net/mgmt-tools/ManagementTools_AmazonCloudWatch.svg", "font": { "size": 12, "face": "Roboto" }, "label": "CloudWatch\n(HeavenGate)", "shape": "image", "margin": 35 },
        {"id": 5, "size": 40, "image": "https://d2m4acy5lozmcy.cloudfront.net/mobile/MobileServices_AmazonCognito.svg", "font": { "size": 12, "face": "Roboto" }, "label": "Cognito\n(DragonOps)", "shape": "image", "margin": 35 },
        {"id": 6, "size": 30, "image": "https://d2m4acy5lozmcy.cloudfront.net/security-id-compliance/SecurityIdentityCompliance_AWSWAF.svg", "font": { "size": 12, "face": "Roboto" }, "label": "WAF\n(HeavenGate)", "shape": "image", "margin": 35 },
        {"id": 7, "size": 30, "image": "https://d2m4acy5lozmcy.cloudfront.net/storage/Storage_AmazonS3.svg", "font": { "size": 12, "face": "Roboto" }, "label": "S3\n(HeavenGate)", "shape": "image", "margin": 35 }
    ],
    "edges": [
        {"from": 1, "to": 2, "color": {"color": "black", "inherit": false}},
        {"from": 2, "to": 3, "color": {"color": "black", "inherit": false}},
        {"from": 2, "to": 6, "color": {"color": "black", "inherit": false}},
        {"from": 3, "to": 5, "color": {"color": "black", "inherit": false}},
        {"from": 3, "to": 4, "color": {"color": "black", "inherit": false}},
        {"from": 2, "to": 7, "color": {"color": "black", "inherit": false}}
    ],
    "options": {
        "layout": {
            "randomSeed": 696516
        }        
    }
```
In the diagram above, any references to HeavenGate and DragonOps reference the following Cigna AWS account numbers by environment

|Environment|HeavenGate Account|DragonOps Account|
|-----------|--------|--------------|
|Dev|003856232118|003856232118|
|PVS|994414768466|371667142743|
|Prod|931246597913|796192334444|

## HeavenGate

HeavenGate is a project created by the CIS Platform Engineering team to support external integration. The initial primary use case is myCigna APIs. However, the dragon-api is also able to leverage the same work to enable HL7 FHIR compliant APIs. In the case of the dragon-api, the integration use cases support Clinical Data Exchange and EHR Integration 

## Cloudfront (HeavenGate)

Cloudfront serves as a mechanism to ensure that all traffic to Cigna API Gateways goes through a Cigna designated DNS entries. This is achieved through the use of an API Key that automatically rotates and is automatically synchronized between the Cloudfront distribution and the API Gateway. This configuration is managed through the HeavenGate project. For the Dragon API, the Cloudfront distribution uses `*.fhir.cigna.com` where the `*.` prefix is used for lower environments. The production instance is `fhir.cigna.com`. 

### Origin

For the Dragon API, the origin points to the API Gateway instance that is configured. HeavenGate uses a 'whitelist' capability to limit the headers that flow externally to the API Gateway. This is meant to reduce the possible attack service by using only headers that Cigna needs to process and API request. 

### Behaviors 

There is only one (default) behavior that currently exists in our Cloudfront distribution. Everything is forwarded to the API Gateway, which handles resolution of the request. Only certain headers are passed to the API Gateway. The whitelisted headers are below: 

* Accept
* Accept-Encoding
* Accept-Language
* Access-Control-Request-Headers
* Access-Control-Request-Method
* Authorization 
* Content-Language
* Content-Length
* Content-Type
* If-Modified-Since
* Origin
* X-Cigna-*

### X-API-Key

Cloudfront provides a way to ensure that outside resources cannot directly access the API Gateway endpoints. Using a header called `X-API-Key`, Cloudfront and API Gateway rotate a valid key between them. Without a valid `X-API-Key` header originating from the Cloudfront distribution, the API Gateway denies the request. This allows the teams to put additional logging and security mechanisms in Cloudfront and ensure that all traffic goes through Cloudfront. 

### Web Application Firewall (WAF)

The HeavenGate Cloudfront distribution has a WAF attached to it. AWS WAF provides a security measure against common malicious patterns. In the lower environments, WAF is also configured to only allow internal traffic or traffic from specific IPs or IP ranges. 

### Logging 

HeavenGate sends Cloudfront logs to an S3 bucket. The logs are in a Gzipped format and contain basic request information (e.g. HTTP verb, HTTP response code, path, etc.). Below is a quick reference for environments and buckets

|Environment|FHIR URL|S3 Bucket Link|
|-----------|--------|--------------|
|Dev|a.fhir.cigna.com|[d-heavengate-s3bucketaccesslogs-1l761m5zn4p7y.s3.amazonaws.com](https://s3.console.aws.amazon.com/s3/buckets/d-heavengate-s3bucketaccesslogs-1l761m5zn4p7y/?region=us-east-1&tab=overview)|
|PVS|v.fhir.cigna.com|[v-heavengate-s3bucketaccesslogs-g8dvzx7gqg2r.s3.amazonaws.com](https://s3.console.aws.amazon.com/s3/buckets/v-heavengate-s3bucketaccesslogs-g8dvzx7gqg2r/?region=us-east-1&tab=overview)|
|Prod|fhir.cigna.com|[p-heavengate-s3bucketaccesslogs-sjt2iu9cps7w.s3.amazonaws.com](https://s3.console.aws.amazon.com/s3/buckets/p-heavengate-s3bucketaccesslogs-sjt2iu9cps7w/?region=us-east-1&tab=overview)|

## API Gateway (HeavenGate)

For the Dragon API, a set of methods off of the `/fhir` path is setup for use. All methods also include the `OPTIONS` method to account for the need of CORS Headers. Each method under FHIR implements a Method Request, Integration Request, Integration Response, and Method Response. The below describes the implementation of Method Request and Integration Request as the others are left in a vanilla configuration.

### Method Request

There are a few notes about the Method Request: 

* **Authorization** - Integrates with Cognito through a defined authorizer. Cognito User Pools are defined using the AWS region and a unique string. The format is typically `{region}_{UID}` (e.g. `us-east-1_KR5MLjnbE`). This causes a header of `Authorization` to be required and pass in a valid `access_token` obtained by logging into Cognito.
* **OAuth Scopes** - Defines what scope this particular method requires. Dragon API scopes are defined in this way: `{resource}/{method}` (e.g. `encounter/post`)
* **Request Body** - Defines the Swagger definition that validates incoming requests. 

### Integration Request

For POST requests to the Dragon API, requests are sent to SNS and than to an SQS queue that invokes a Lambda function. The below discusses various pieces of this configuration: 

* **Action** - Indicates what SNS action is used.
* **Execution Role** - An execution role that allows the API Gateway to send a message to the SNS.

> **NOTE:** In dev, HeavenGate and DragonOps use the same account. However, in test and prod, a different account is used. This requires cross account privileges. Since the request is originating from the HeavenGate account, the cross account role needs to be created in their account. The IAM role name follows the format: `arn:aws:iam::{HeavenGateAccountNumber}:role/fhir-exchange-cross-account-us-east-1-{env}`

* **URL Query String Parameters** - In the case of the Dragon API, this is a static mapping that indicates what type of resource is being processed. This gives the Lambda function context that is sent with the data payload. Also, the payload of the API request is mapped using `method.request.body`

|Name|Mapped From|
|----|-----------|
|Topic|''arn:aws:sns:us-east-1::fhir-exchange-ingress-sns-*''|
|Message|method.request.body|
|MessageAttributes.entry.1.Value.DataType|'String'|
|MessageAttributes.entry.1.Value.StringValue|'encounter'|
|MessageAttributes.entry.1.Name|'method'|

### Logging

HeavenGate sends logging for API Gateway to CloudWatch. Below is a mapping of environment to CloudWatch Log Groups. 

|Environment|CloudWatch Group|
|-----------|----------------|
|Dev|[dev-GatewayAccessLogs](https://console.aws.amazon.com/cloudwatch/home?region=us-east-1#logStream:group=dev-GatewayAccessLogs)|
|PVS|[pvs-GatewayAccessLogs](https://console.aws.amazon.com/cloudwatch/home?region=us-east-1#logStream:group=pvs-GatewayAccessLogs)|
|Prod|[prod-GatewayAccessLogs](https://console.aws.amazon.com/cloudwatch/home?region=us-east-1#logStream:group=prod-GatewayAccessLogs)|