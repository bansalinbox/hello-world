# Clinical Data Exchange - Data Pipelines

A project for creating data pipelines related to Clinical Data Exchange. Uses D&A Datastore as a source for data for eligibility work. Uses data from the Dragon API for reporting data.