import {StartJobRunRequest} from "aws-sdk/clients/glue";
import {DeleteItemInput, PutItemInput, QueryInput} from "aws-sdk/clients/dynamodb";
import Service from "./Service";
import DBUtility, {JobState} from "./DBUtility";
import {Util} from "./Util";


/**
 * isPlanCreated need to be passed from step function as first activity, once it is created,
 * it will not created again as runner send the status of this activity as done via token.
 * @param event
 * @param context
 * @param callback
 */
let handler = async (event, context, callback) => {
    console.info("start of the lambda");
    console.log(event);
    let token : string = event.token;
    let stepName : string = event.stepName;
    Util.checkRequiredValue(token, "token");
    Util.checkRequiredValue(stepName, "stepName");

    let service = new Service();
    await service.checkRequiredFields();
    switch (stepName) {
        case process.env.ICOLL_JOB_NAME:
            console.info(`Going to execute ${stepName}`);
            let baseBucketName = process.env.TBL_BASE_BUCKET_NM;
            let srcFldrName = process.env.ICOLL_SRC_FLDR;
            let destFldrName = process.env.ICOLL_DEST_FLDR;
            try{
                let copyProcess = await service.copyFiles(baseBucketName, srcFldrName, destFldrName);
                console.info(`Step ${stepName} is completed and going to update the step function`);
                await service.updateSfnSuccess(token);
                console.info(`${stepName} : updating the step function is done`);
            }catch (e) {
                console.error(`Step ${stepName} failed so going to make the step as failed`);
                console.error(e);
                await service.updateSfnFailure(token);
            }
            break;
        case process.env.RENAME_JOB_NAME:
            console.info(`Going to execute ${stepName}`);
            try{
                let renameProcess = await service.renameFile();
                console.info(`Step ${stepName} is completed and going to update the step function`);
                await service.updateSfnSuccess(token);
                console.info(`${stepName} : updating the step function is done`);
            }catch (e) {
                console.error(`Step ${stepName} failed so going to make the step as failed`);
                console.error(e);
                await service.updateSfnFailure(token);
            }
            break;
    }
};

export {handler as cis};
