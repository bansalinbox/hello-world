import * as AWS from "aws-sdk";
import Service from "./Service";

export class Util {

    public static checkRequiredEnvironmentValue(value: string, key: string) {
        if (!value) {
            let msg = `${key} is not set as environment variable`;
            throw this.error(StandardError.DataError, msg, new Error());
        }
        return value;
    }

    public static checkRequiredValue(value: string, key: string) {
        if (!value) {
            let msg = `${key} param is missing `;
            throw this.error(StandardError.DataError, msg, new Error());
        }
        return value;
    }

    /**
     * Reformat the exception to custom exception
     * @param {string} name
     * @param {string} message
     * @param {Error} err
     * @returns {Error}
     */
    public static error(name: string, message: string, err: Error) {
        let errStack = null;
        if (err != null) {
            if (err.stack != null) {
                errStack = err.stack;
            }
        }
        let e = new Error();
        e.name = name;
        e.message = message + ' : ' + err.message;
        e.stack = errStack;
        console.error(e);
        return e;
    }
}
export enum StandardError {
    AWSError = 'AWSError',
    DataError = 'DataError'
}


