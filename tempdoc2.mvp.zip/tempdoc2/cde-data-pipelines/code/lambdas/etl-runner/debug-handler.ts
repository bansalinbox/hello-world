import {Util} from "./Util";

require("source-map-support").install();
import * as AWS from 'aws-sdk';
import { cis } from "./handler";
import Service from "./Service";


//Setup variables before any other module initializations
var credentials = new AWS.SharedIniFileCredentials({profile: 'saml'});
AWS.config.credentials = credentials;
AWS.config.region = 'us-east-1';

process.env.API_VERSION = '2012-10-08';
let state_arn = 'arn:aws:states:us-east-1:003856232118:stateMachine:fhir-cmt-eligibility-process-m44164';
let state_arn_adt = 'arn:aws:states:us-east-1:003856232118:stateMachine:fhir-cmt-elig-sfn-adt-m44164';
process.env.TRACKER_TBL_NAME = 'fhir-etl-job-tracker-m44164';
process.env.ACTIVITY_BASE_URL = 'arn:aws:states:us-east-1:003856232118:activity:';
var suffix = "-m44164";
let activity_list = `fhir_CreateJobPlan${suffix},fhir_ibor_indiv_idnty_main${suffix},fhir_ccw_cust_acc_dtl_ssn_main${suffix},fhir_cde_cmt_eligibility_main${suffix},fhir_RenameFiles${suffix}`;
let activity_list_adt = `fhir_CreateJobPlan_adt${suffix},fhir_cmt_elig_adt_main${suffix}`;
process.env.FILE_NAME= "CMT_Eligibility";
process.env.OUTPUT_FLDR_STARTS = "output/"
process.env.INPUT_FLDR_STARTS = "input/"
process.env.OUTPUT_BUCKET_NAME = "fhir-glue-cmt-file-m44164"
process.env.RENAME_JOB_NAME = `fhir_RenameFiles${suffix}`
process.env.PLAN_JOB_NAME= `fhir_CreateJobPlan_adt${suffix}`
process.env.CLOUDWATCH_RUNNER_RULE_NAME= `fhir-lambda_runner_rule-m44164`
process.env.RETRY_CNT = "1"
process.env.MAX_RETRIES = "1"

// var activitesList = process.env.ACTIVITY_LIST.split(',');
// let event= {
//   STATE_MACHINE_ARN: state_arn_adt,
//   ACTIVITY_LIST: activity_list_adt
// };
// cis(event, {}, (arguments1) => {
//   console.log(arguments1)
// });

// let s = new Service(['a'], new Date().toISOString(), "")
// let v = s.renameFile();

// let bucketName = "fhir-glue-tables-dev";
// let inputFolderStarts =  "";
// let outputFolderName = "";
// activity_list.split(",")

// let service = new Service(activity_list.split(","), "2020-05-26T15:45:50.960Z", "");
// service.checkActivityInDBAndUpdateStepFunctionIfCompleted();

// let t = new Util();
// t.test();

// public async test(){
//     let activity_lists = `fhir_CreateJobPlan-m44164,fhir_ibor_indiv_idnty_main-m44164,fhir_ccw_cust_acc_dtl_ssn_main-m44164,fhir_cde_cmt_eligibility_main-m44164,fhir_RenameFiles-m44164`;
//     var activitesList = activity_lists.split(',');
//     let s  = new Service(activitesList,"","");
//     //await s.copyFiles("fhir-glue-tables-dev","fhir_db_m44164/fhir_icoll_pat_alignment_temp","fhir_db_m44164/fhir_icoll_pat_alignment");
//     //await s.copyFiles("test-delete-11","aa/","aa");
//     await s.renameFile();
//
// }
