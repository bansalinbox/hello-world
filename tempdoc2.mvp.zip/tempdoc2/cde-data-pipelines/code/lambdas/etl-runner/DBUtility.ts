import * as AWS from "aws-sdk";
import {DynamoDB} from "aws-sdk";
import {Util} from "./Util";

export default class DBUtility {

    public tableName = Util.checkRequiredEnvironmentValue(process.env.TRACKER_TBL_NAME, "TRACKER_TBL_NAME");

    public async findActivityInDB(pk: string, activityName: string) {
        let dynamodb = new AWS.DynamoDB();
        let params = {

            ExpressionAttributeNames: {
                "#rt": "run_time",
                "#ac": "activity_cd"
            },
            ExpressionAttributeValues: {
                ":rt": {
                    S: pk
                },
                ":ac": {
                    S: activityName
                }
            },
            KeyConditionExpression: "#rt = :rt and #ac = :ac",
            TableName: this.tableName
        };
        let result = await dynamodb.query(params).promise();
        return result;
    }

    public async updateActivityTaskIdAndChangeStatusToStarted(runTime: string, activityName: string, colName: string, colValue: string) {
        // make singleton connection to db and other component
        let dynamodb = new AWS.DynamoDB();
        let p = {
            ExpressionAttributeNames: {
                "#T": colName,
                "#S": "job_state"
            },
            ExpressionAttributeValues: {
                ":t": {
                    S: colValue
                },
                ":s": {
                    S: JobState.INPROGRESS
                }
            },
            Key: {
                "run_time": {
                    S: runTime
                },
                "activity_cd": {
                    S: activityName
                }
            },
            ReturnValues: "NEW",
            TableName: this.tableName,
            UpdateExpression: "SET #T = :t, #S = :s"
        };
        let result = await dynamodb.updateItem(p).promise();
    }

    public async dbQuery(pk: string) {
        let dynamodb = new AWS.DynamoDB();
        let params = {
            ExpressionAttributeValues: {
                ":v1": {
                    S: pk
                }
            },
            KeyConditionExpression: "run_time = :v1",
            TableName: this.tableName
        };
        let result = await dynamodb.query(params).promise();
        return result;
    }


    public async updateActivityTaskId(runTime: string, activityName: string, dbMap: any) {
        let result = null;
        let dynamodb = new AWS.DynamoDB();
        let marshal = DynamoDB.Converter.marshall(dbMap, {convertEmptyValues: true});
        let ExpressionAttributeNames = {};
        let ExpressionAttributeValues = {};
        let updateExpression = {};
        for (let key in marshal) {
            let propName = "#" + key;
            ExpressionAttributeNames[propName] = key;

            let propNameValue = ":" + key;
            ExpressionAttributeValues[propNameValue] = marshal[key];

            updateExpression[propName] = propNameValue;
        }

        let updateExpressionArray = [];
        for (let key in updateExpression) {
            updateExpressionArray.push(`${key} = ${updateExpression[key]}`)
        }
        let UpdateExpressionString = "SET " + updateExpressionArray.join(", ");

        let params = {
            ExpressionAttributeNames: ExpressionAttributeNames,
            ExpressionAttributeValues: ExpressionAttributeValues,
            Key: {
                "run_time": {
                    S: runTime
                },
                "activity_cd": {
                    S: activityName
                }
            },
            ReturnValues: "ALL_NEW",
            TableName: this.tableName,
            UpdateExpression: UpdateExpressionString
        };

        try {
            result = await dynamodb.updateItem(params).promise();
        } catch (e) {
            let msg = "Exception happened while updating the record in dynamodb table";
            console.error(msg);
            console.error(e)
        }
        return result;
    }
}

export enum JobState {
    NOTSTARTED = "NOTSTARTED",
    INPROGRESS = "INPROGRESS",
    COMPLETED = "COMPLETED",
    FAILED = "FAILED"
}

/**
 * AWS GLUE Job has the following status defined in the documents
 *  "STARTING"
 *  "RUNNING"
 *  "STOPPING"
 *  "STOPPED"
 *  "SUCCEEDED"
 *  "FAILED"
 *  "TIMEOUT"
 */
export enum AWSJobState {
    STARTING = "STARTING",
    RUNNING = "RUNNING",
    STOPPING = "STOPPING",
    STOPPED = "STOPPED",
    SUCCEEDED = "SUCCEEDED",
    FAILED = "FAILED",
    TIMEOUT = "TIMEOUT"
}
