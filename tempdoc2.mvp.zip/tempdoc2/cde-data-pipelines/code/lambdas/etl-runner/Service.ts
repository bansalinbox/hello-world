import DBUtility, {AWSJobState, JobState} from "./DBUtility";
import * as AWS from "aws-sdk";
import Glue = require("aws-sdk/clients/glue");
import {CopyObjectRequest} from "aws-sdk/clients/s3";
import {Util} from "./Util";
import {CloudWatchEvents} from "aws-sdk";
import CountTracker, {StatusTracker} from "./CountTracker";

export default class Service {

    constructor() {
    }

    public async getListOfFiles(bucketName: string) {
        let params = {
            Bucket: bucketName
        };
        let s3 = new AWS.S3();
        let listOfFiles = await s3.listObjects(params).promise();
        return listOfFiles;
    }

    /**
     * It is supposed to delete the files with the below strategies:
     * 1) delete the files under the path input/covid/**folderName**, where folderName are the folders older then last 3 ones.
     * 2)
     * @param outputBucketName
     * @param inputFolderStarts
     * @param outputFolderStarts
     * @param fileName
     */
    public async cleanOlderFiles(baseBucketName: string, inputFolderStarts: string, outputFolderStarts: string, fileName: string) {
        let covidInputFolderName = inputFolderStarts + "covid";
        let covidOutputFolderName = outputFolderStarts + "covid";
        let covidOutputStandardFolderName = outputFolderStarts + "standard";
        let covidOutputVAFolderName = outputFolderStarts + "va";
        let filePrefix = fileName + "_";
        let bucketCanBeDeleted = [];
        let promiseArray = [];
        let keySetInput = new Set();
        let keySetOutput = new Set();
        let listOfFiles = await this.getListOfFiles(baseBucketName);
        if (listOfFiles.Contents) {
            let totalKeys = listOfFiles.Contents;
            for (let i = 0; i < totalKeys.length; i++) {
                let currentKey = totalKeys[i].Key;
                let fileCreationTS = totalKeys[i].LastModified.toISOString();
                let parts = currentKey.split("/");
                if (currentKey.startsWith(covidInputFolderName) && currentKey.endsWith("csv.gz")) {
                    if (parts[2].startsWith(filePrefix)) {
                        keySetInput.add(parts[2].replace(filePrefix, ""));
                    }
                }
                if (currentKey.startsWith(covidOutputFolderName) && currentKey.endsWith("csv.gz")) {
                    console.info(currentKey);
                    //check if the folder is not archive
                    if (parts[2].startsWith(filePrefix)) {
                        keySetOutput.add(parts[2].replace(filePrefix, ""));
                     }
                }
            }
            await this.sortAndDelete(baseBucketName, covidInputFolderName, filePrefix, keySetInput, 3, true);
            await this.sortAndDelete(baseBucketName, covidOutputFolderName, filePrefix, keySetOutput, 3, true);
         }

    }

    public async sortAndDelete(baseBucketName: string, folderForDeletion: string, filePrefix: string, keySet: any, daysToKeep: number, isFolder: boolean) {
        console.info(`Going to sort and delete file files older than ${daysToKeep} and the full key set is ${keySet}`);
        let keyFolderArrayToBeDeleted = [];
        let keyFileArrayToBeDeleted = [];
        let keyArray = Array.from(keySet.values());
        keyArray.sort(function (var1, var2) {
            if (var1 < var2) {
                return 1;
            } else if (var1 > var2) {
                return -1;
            } else {
                return 0;
            }
        });
        let keyArrayLength = keyArray.length;
        if (keyArrayLength > daysToKeep) {
            for (let i = daysToKeep; i < keyArrayLength; i++) {
                let keyDeletion = keyArray[i];
                if(isFolder){
                    let fullFolderName = folderForDeletion + "/" + filePrefix + keyDeletion;
                    keyFolderArrayToBeDeleted.push(fullFolderName);
                    console.info(`Going to delete the files under the folder name ${fullFolderName}`);
                    await this.deleteFiles(baseBucketName, fullFolderName, []);
                }else{
                    let fullFileName = folderForDeletion + "/" + filePrefix + keyDeletion + ".csv";
                    keyFileArrayToBeDeleted.push(fullFileName);
                }

            }
            if(keyFileArrayToBeDeleted.length> 0){
                console.info(`Going to delete the files under the folder name ${folderForDeletion}`);
                await this.deleteFiles(baseBucketName, folderForDeletion, keyFileArrayToBeDeleted);
            }

        }
        console.info(`Keys for the deletion are ${keyFolderArrayToBeDeleted} has been completed`);
    }

    public async checkRequiredFields(){
        Util.checkRequiredEnvironmentValue(process.env.FILE_NAME, "FILE_NAME");
        Util.checkRequiredEnvironmentValue(process.env.OUTPUT_FLDR_STARTS, "OUTPUT_FLDR_STARTS");
        Util.checkRequiredEnvironmentValue(process.env.INPUT_FLDR_STARTS, "INPUT_FLDR_STARTS");
        Util.checkRequiredEnvironmentValue(process.env.OUTPUT_BUCKET_NAME, "OUTPUT_BUCKET_NAME");
        Util.checkRequiredEnvironmentValue(process.env.MAX_RETRIES, "MAX_RETRIES");
        Util.checkRequiredEnvironmentValue(process.env.ICOLL_JOB_NAME, "ICOLL_JOB_NAME");
        Util.checkRequiredEnvironmentValue(process.env.ICOLL_SRC_FLDR, "ICOLL_SRC_FLDR");
        Util.checkRequiredEnvironmentValue(process.env.ICOLL_DEST_FLDR, "ICOLL_DEST_FLDR");
        Util.checkRequiredEnvironmentValue(process.env.TBL_BASE_BUCKET_NM, "TBL_BASE_BUCKET_NM");
        Util.checkRequiredEnvironmentValue(process.env.ACTIVITY_BASE_URL, "ACTIVITY_BASE_URL");
        Util.checkRequiredEnvironmentValue(process.env.RENAME_JOB_NAME, "RENAME_JOB_NAME");
    }

    public async updateSfnSuccess(token : string){
        let stepFunctions = new AWS.StepFunctions();
        let param = {output: JSON.stringify({
                step_function_updated: "DONE"
            }), taskToken: token};
        let updateStep = await stepFunctions.sendTaskSuccess(param).promise();
    }

    public async updateSfnFailure(token : string){
        let stepFunctions = new AWS.StepFunctions();
        let param = {
            taskToken: token
        };
        let updateStep = await stepFunctions.sendTaskFailure(param).promise();
    }

    public async renameFile() {
        let fileName = process.env.FILE_NAME;
        let fileCreationTIme = new Date().toISOString();
        let outputFolderStarts = process.env.OUTPUT_FLDR_STARTS;
        let inputFolderStarts = process.env.INPUT_FLDR_STARTS;
        let outputBucketName = process.env.OUTPUT_BUCKET_NAME;
        let bucketCanBeDeleted = [];
        // let archivedFilesName = [];
        let promiseArray = [];
        // let promiseArchiveArray = [];
        let currentKey = "";
        let s3 = new AWS.S3();
        await this.cleanOlderFiles(outputBucketName, inputFolderStarts, outputFolderStarts, fileName);

        let listOfFiles = await this.getListOfFiles(outputBucketName);
        if (listOfFiles.Contents) {
            let totalKeys = listOfFiles.Contents;
            for (let i = 0; i < totalKeys.length; i++) {
                let currentKey = totalKeys[i].Key;
                let fileCreationTS = totalKeys[i].LastModified.toISOString();
                let parts;
                if (currentKey.startsWith(inputFolderStarts)) {
                    console.info(currentKey);
                    let parts = currentKey.split("/");
                    let copySource = `${outputBucketName}/${currentKey}`;
                    let objKey = undefined;
                    if (parts[1] == 'covid') {
                        if (parts[2].startsWith('CMT_')) {
                            let fldName = parts[2];
                            let sparkFileNo = parts[3].split("-")[1];
                            objKey = `${outputFolderStarts}${parts[1]}/${fldName}/${fldName}_${sparkFileNo}.csv.gz`;
                        }
                    } else {
                        objKey = `${outputFolderStarts}${parts[1]}/${fileName}_${fileCreationTS}.csv`;
                    }
                    let copyParam = {
                        Bucket: outputBucketName,
                        CopySource: copySource,
                        Key: objKey
                    };
                    if (objKey != undefined) {
                        bucketCanBeDeleted.push(copySource);
                        promiseArray.push(s3.copyObject(copyParam).promise());
                    }
                }
            }
        }
        await Promise.all(promiseArray).then(value => {
            console.log(`Files are renamed : ${bucketCanBeDeleted}`)
        });
    }

    public async copyFiles(baseBucketName: string, srcFolderStarts: string, destFolderName: string) {
        console.info("copyFiles method has been called");
        let oneTime: boolean = true;
        let promiseArray = [];
        let params = {
            Bucket: baseBucketName
        };

        let s3 = new AWS.S3();
        let listOfFiles = await s3.listObjects(params).promise();
        if (listOfFiles.Contents) {
            let totalKeys = listOfFiles.Contents;
            for (let i = 0; i < totalKeys.length; i++) {
                let currentKey = totalKeys[i].Key;
                if (currentKey.startsWith(srcFolderStarts + "/")) {
                    let parts = currentKey.split("/");
                    let fileCreationTS = totalKeys[i].LastModified.toISOString();
                    let copySource = currentKey;

                    if (parts[2] != undefined && parts[2] != "") {
                        if (oneTime) {
                            // It will run only of there is some file to copy form the temp to local table
                            await this.deleteFiles(baseBucketName, destFolderName, []);
                            oneTime = false;
                        }
                        let copyParam = {
                            Bucket: baseBucketName,
                            CopySource: `/${baseBucketName}/${copySource}`,
                            Key: `${destFolderName}/${parts[2]}`
                        };
                        console.info("copyParam");
                        console.info(copyParam);
                        promiseArray.push(s3.copyObject(copyParam).promise());
                    }
                }
            }
        }
        await Promise.all(promiseArray).then(value => {
            console.log(`Files are copied`);
        });

    }

    public async deleteFiles(bucketName: string, folderName, listOfFileToBeDeleted: string[]) {
        console.info(`Going to delete the objects in the bucket : ${bucketName} having the folder name ${folderName}`);
        let promiseArray = [];
        let deleteObj = [];
        let s3 = new AWS.S3();
        let listOfFiles = await this.getListOfFiles(bucketName);
        if (listOfFiles.Contents) {
            let totalKeys = listOfFiles.Contents;
            for (let i = 0; i < totalKeys.length; i++) {
                let currentKey = totalKeys[i].Key;
                if (currentKey.startsWith(folderName + "/")) {
                    let parts = currentKey.split("/");
                    if(listOfFileToBeDeleted.length == 0){
                        if (parts[2] != undefined && parts[2] != "") {
                            console.info(`File which is going to delete is ${parts[2]}`)
                            deleteObj.push({Key: currentKey});
                        } else {
                            console.info("I dont know why there are some invisible files")
                        }
                    }
                    if(listOfFileToBeDeleted.length>0){
                        let fileNames = new Set(listOfFileToBeDeleted);
                        if(fileNames.has(folderName + "/" +parts[3])){
                            deleteObj.push({Key: currentKey});
                        }
                    }
                }
            }
            if (deleteObj.length > 0) {
                let paramsDelete = {
                    Bucket: bucketName,
                    Delete: {
                        Objects: deleteObj
                    }
                };
                console.info(`Param for the deletion objects are ${paramsDelete}`);
                promiseArray.push(s3.deleteObjects(paramsDelete).promise());
                await Promise.all(promiseArray).then(value => {
                    console.info(`Deletion of the objects in the bucket : ${bucketName} having the folder name ${folderName} has been completed`);
                });
            }
        }
    }

    public async delay(ms: number) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}
