export default class CountTracker {
    total: number = 0;
    found: number = 0;
    skipped: number = 0;
}

export class StatusTracker{
    RUNNING = [];
    FAILED = [];
    SUCCEEDED = []
    GLUE_JOB_STARTED = [];
    STEP_FN_UPDATED = [];
    TOTAL_DB_ITEMS= [];
}
