import {DynamoDB, Glue, StepFunctions} from "aws-sdk"
import {StartJobRunRequest} from "aws-sdk/clients/glue";
import {DeleteItemInput, PutItemInput, QueryInput} from "aws-sdk/clients/dynamodb";


let handler = async (event, context, callback) => {
    let sf: StepFunctions = new StepFunctions();
    let glue: Glue = new Glue({apiVersion: '2017-03-31'});
    let db: DynamoDB = new DynamoDB({region: process.env.REGION});

    try {
        await startGlueJobs(sf,glue,db);
        await checkGlueJobs(sf,glue,db);
        callback(null);
    } catch (e) {
        console.error('UNEXPECTED EXCEPTION HAPPENED');
        callback(e);
    }
}

interface EtlRecord {
    'sfnActivityArn': string,
    'sfnTaskToken': string,
    'glueJobName': string,
    'glueJobRunId': string
}

async function startGlueJobs(sf:StepFunctions, glue:Glue, db:DynamoDB) {
    while (true) {
        let activity_task = await sf.getActivityTask({
            activityArn: process.env.GLUE_ACTIVITY
        }).promise();

        if (!activity_task.taskToken) {
            break;
        }

        console.log(activity_task);

        let taskInput: StartJobRunRequest = JSON.parse(JSON.parse(activity_task.input));

        console.log(taskInput);

        let jobRunResult = await glue.startJobRun(taskInput).promise();
        console.log(jobRunResult)

        let item: EtlRecord = {
            'sfnActivityArn': process.env.GLUE_ACTIVITY,
            'sfnTaskToken': activity_task.taskToken,
            'glueJobName': taskInput.JobName,
            'glueJobRunId': jobRunResult.JobRunId
        };

        let putItemInput: PutItemInput = {
            TableName: process.env.ETL_TABLE,
            Item: DynamoDB.Converter.marshall(item, {convertEmptyValues: true})
        };

        let dbResult = await db.putItem(putItemInput).promise()
    }
}

async function checkGlueJobs(sf:StepFunctions, glue:Glue, db:DynamoDB) {
    var queryInput: QueryInput = {
        ExpressionAttributeValues: {
            ":sfnActivityArn": DynamoDB.Converter.input(process.env.GLUE_ACTIVITY)
        },
        KeyConditionExpression: "sfnActivityArn = :sfnActivityArn",
        TableName: process.env.ETL_TABLE
    };
    let active_jobs = await db.query(queryInput).promise();
    console.log(active_jobs.Items);

    for (var item in active_jobs.Items) {
        let etlRecord: EtlRecord = DynamoDB.Converter.unmarshall(active_jobs.Items[item]) as EtlRecord;

        let glueResponse = await glue.getJobRun({
            JobName: etlRecord.glueJobName,
            RunId: etlRecord.glueJobRunId
        }).promise();
        let jobRunState = glueResponse.JobRun.JobRunState;

        if (['SUCCEEDED'].indexOf(jobRunState) != -1) {

            let taskOutput = {
                "GlueJobName": etlRecord.glueJobName,
                "GlueJobRunId": etlRecord.glueJobRunId,
                "GlueJobRunState": jobRunState,
                "GlueJobStartedOn": glueResponse.JobRun.StartedOn,
                "GlueJobCompletedOn": glueResponse.JobRun.CompletedOn,
                "GlueJobLastModifiedOn": glueResponse.JobRun.LastModifiedOn
            };

            let sfnResp = await sf.sendTaskSuccess(
                {
                    taskToken: etlRecord.sfnTaskToken,
                    output: JSON.stringify(taskOutput)
                }).promise();

            console.log(taskOutput);

            let deleteItemInput: DeleteItemInput = {
                TableName: process.env.ETL_TABLE,
                Key: DynamoDB.Converter.marshall({
                    sfnTaskToken: etlRecord.sfnTaskToken,
                    sfnActivityArn: etlRecord.sfnActivityArn
                })
            }
            await db.deleteItem(deleteItemInput).promise()

        } else if (['STARTING', 'RUNNING', 'STARTING', 'STOPPING'].indexOf(jobRunState) != -1) {
            await sf.sendTaskHeartbeat({taskToken: etlRecord.sfnTaskToken});
        } else if (['FAILED', 'STOPPED'].indexOf(jobRunState) != -1) {
            let taskOutput = {
                "GlueJobName": etlRecord.glueJobName,
                "GlueJobRunId": etlRecord.glueJobRunId,
                "GlueJobRunState": jobRunState,
                "GlueJobStartedOn": glueResponse.JobRun.StartedOn,
                "GlueJobRunErrorMessage": glueResponse.JobRun.ErrorMessage,
                "ActivityToken": etlRecord.sfnTaskToken
            };

            let sfResponce = await sf.sendTaskFailure({
                taskToken: etlRecord.sfnTaskToken,
                cause: JSON.stringify(taskOutput),
                error: "GlueJobFailedError"
            });

            console.log(taskOutput);

            let deleteItemInput: DeleteItemInput = {
                TableName: process.env.ETL_TABLE,
                Key: DynamoDB.Converter.marshall({
                    sfnTaskToken: etlRecord.sfnTaskToken,
                    sfnActivityArn: etlRecord.sfnActivityArn
                })
            };
            await db.deleteItem(deleteItemInput).promise()
        }
    }
}

export {handler as cis};