import * as AWS from 'aws-sdk';
import { cis } from "./handler";

//Setup variables before any other module initializations
var credentials = new AWS.SharedIniFileCredentials({profile: 'saml'});
AWS.config.credentials = credentials;
AWS.config.region = 'us-east-1';

process.env.API_VERSION = '2012-10-08';
process.env.ETL_TABLE="fhir-eligibility-etl";
process.env.GLUE_ACTIVITY="arn:aws:states:us-east-1:003856232118:activity:fhir-gl-sss_eligibility_activity";


cis({}, {}, (arguments1) => {
  console.log(arguments1)
});
