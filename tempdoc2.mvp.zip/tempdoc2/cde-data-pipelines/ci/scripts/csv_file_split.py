import os
import s3fs
import argparse

parser = argparse.ArgumentParser(description='Args for file split script')
parser.add_argument('bucket', type=str, help='S3 bucket name')
parser.add_argument('path', type=str, help='S3 path to file')
parser.add_argument('file', type=str, help='File to process')
args = parser.parse_args()
s3_bucket = args.bucket
s3_path = args.path
s3_file = args.file

input_archive_folder = "input_archive"

file_row_limit = 413250
file_delimiter = ','

# S3 bucket info
s3 = s3fs.S3FileSystem(anon=False)


def lambda_handler(bucket, path, file):
    print("Processing file s3://{}/{}/{}".format(bucket, path, file))
    # Assign some variables that make it easier to work with the data in the
    # event record.
    key = os.path.join(path, file)
    input_file = os.path.join(bucket, key)
    archive_path = os.path.join(bucket, path, input_archive_folder, file)
    to_process_folder = os.path.splitext(file)[0]
    output_file_template = os.path.splitext(file)[0] + "_"
    output_path = os.path.join(bucket, path, to_process_folder)
    # Set a variable that contains the number of files that this Lambda
    # function creates after it runs.
    # Split the input file into several files, each with 50 rows.
    split(s3.open(input_file, 'r'), file_delimiter, file_row_limit, output_file_template, output_path, True)

    # Send the unchanged input file to an archive folder.
    #archive(input_file, archive_path)


# Split the input into several smaller files.
def split(filehandler, delimiter, row_limit, output_name_template, output_path, keep_headers):
    import csv
    reader = csv.reader(filehandler, delimiter=delimiter)

    current_piece = 1
    current_out_path = os.path.join(
        output_path,
        output_name_template + str(current_piece) + ".csv"
    )
    print("Current chunk: {}".format(current_out_path))
    current_out_writer = csv.writer(s3.open(current_out_path, 'w'), delimiter=delimiter)
    current_limit = row_limit
    if keep_headers:
        headers = next(reader)
        current_out_writer.writerow(headers)
    for i, row in enumerate(reader):
        if i + 1 > current_limit:
            current_piece += 1
            current_limit = row_limit * current_piece
            current_out_path = os.path.join(
                output_path,
                output_name_template + str(current_piece) + ".csv"
            )
            print("Current chunk: {}".format(current_out_path))
            current_out_writer = csv.writer(s3.open(current_out_path, 'w'), delimiter=delimiter)
            if keep_headers:
                current_out_writer.writerow(headers)
        current_out_writer.writerow(row)


# Move the original input file into an archive folder.
def archive(input_file, archive_path):
    s3.copy_basic(input_file, archive_path)
    print("Moved " + input_file + " to " + archive_path)
    s3.rm(input_file)


lambda_handler(s3_bucket, s3_path, s3_file)
