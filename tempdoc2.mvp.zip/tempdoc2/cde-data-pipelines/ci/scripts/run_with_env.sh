# The purpose of this file is to set all the proper environment variables so that the CI can run
# In addition to what's set in this file, to run locally, you'll need to set

# GET_PLUGINS       - This says whether or not terraform plugins should be downloaded. Always false in the pipeline
# ENV               - The AWS account this is going to run in
# TFVAR_FILE        - The terraform environment variables to use for this deployment
# TF_LOCATION       - The repo location where the CI should be run
# S3_KEY_NAME_BASE  - The path and tfstate file name (e.g. infra/fhir-code-bucket.tfstate)
# TERRAFORM_COMMAND - The terraform command to be run (in the pipeline, it will be "plan" or "apply -input=false -auto-approve")

# Get deployment credentials
if [ -z "${STAGE}" ]
then
   export STAGE=`echo "${STAGE:-${GITLAB_USER_LOGIN//./}}" | awk '{print tolower($0)}'`
fi

# Finish setting up environment variables
export TFSTATE_BUCKET=fhir-${ENV}-tfstate
export S3_KEY_NAME=${STAGE}/${S3_KEY_NAME_BASE}
export LOCK_TABLE=fhir-tflockstate-${ENV}
#export TF_LOG=TRACE

echo STAGE : ${STAGE}
sh $1
