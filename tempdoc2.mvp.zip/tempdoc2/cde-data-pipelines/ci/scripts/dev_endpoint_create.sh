# Variables needed
# ENDPOINT_NAME Name of the dev endpoint
# ENV_FILE      Filename containing the JSON describing the endpoint

aws sts assume-role --role-arn ${ROLE_ARN} --role-session-name "cde-glue-runner" > data.json

export AWS_ACCESS_KEY_ID="`cat data.json | jq ".Credentials.AccessKeyId" -r`"
export AWS_SECRET_ACCESS_KEY="`cat data.json | jq ".Credentials.SecretAccessKey" -r`"
export AWS_SESSION_TOKEN="`cat data.json | jq ".Credentials.SessionToken" -r`"

rm data.json

cd ci/env/dev-endpoint-json

aws glue get-dev-endpoint --endpoint-name ${ENDPOINT_NAME}

if [ $? -eq 0 ]; then
    echo "Dev endpoint already exists"
else
    aws glue create-dev-endpoint --cli-input-json file://${ENV_FILE}
fi
