#!/bin/bash

pip install s3fs
python /tmp/csv_file_split.py "${s3_bucket}"  "${s3_path}" "${s3_file}"
