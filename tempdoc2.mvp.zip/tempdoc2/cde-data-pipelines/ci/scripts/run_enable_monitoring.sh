aws sts assume-role --role-arn ${ROLE_ARN} --role-session-name "fhir-emr-monitor" > data.json

export AWS_ACCESS_KEY_ID="`cat data.json | jq ".Credentials.AccessKeyId" -r`"
export AWS_SECRET_ACCESS_KEY="`cat data.json | jq ".Credentials.SecretAccessKey" -r`"
export AWS_SESSION_TOKEN="`cat data.json | jq ".Credentials.SessionToken" -r`"

rm data.json

aws s3 cp "s3://${TFSTATE_BUCKET}/${S3_KEY_NAME}" emrTFState.json

export SLAVE_INSTANCE=$(cat emrTFState.json | jq -r .outputs.core_node_ip.value)
export MASTER_INSTANCE=$(cat emrTFState.json  | jq -r .outputs.master_node_ip.value)
echo MASTER_INSTANCE : "${MASTER_INSTANCE}" and SLAVE_INSTANCE : "${SLAVE_INSTANCE}"
aws ec2 monitor-instances --instance-ids "${MASTER_INSTANCE}" "${SLAVE_INSTANCE}"
aws ec2 modify-instance-metadata-options \
    --instance-id "${MASTER_INSTANCE}" \
    --http-tokens required \
    --http-endpoint enabled
aws ec2 modify-instance-metadata-options \
    --instance-id "${SLAVE_INSTANCE}" \
    --http-tokens required \
    --http-endpoint enabled

rm emrTFState.json

