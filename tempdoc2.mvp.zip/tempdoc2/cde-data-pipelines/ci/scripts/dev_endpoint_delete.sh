# ENDPOINT_NAME Name of the dev endpoint
aws sts assume-role --role-arn ${ROLE_ARN} --role-session-name "cde-glue-runner" > data.json

export AWS_ACCESS_KEY_ID="`cat data.json | jq ".Credentials.AccessKeyId" -r`"
export AWS_SECRET_ACCESS_KEY="`cat data.json | jq ".Credentials.SecretAccessKey" -r`"
export AWS_SESSION_TOKEN="`cat data.json | jq ".Credentials.SessionToken" -r`"

rm data.json

aws glue delete-dev-endpoint --endpoint-name ${ENDPOINT_NAME}