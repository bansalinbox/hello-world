# This file is responsible for doing tsc and webpack on the node code for a Lambda. It is also responsible for including the certificates to 
# allow communication with other Cigna resources

# In addition to what's set in this file, to run locally, you'll need to set
# FOLDER_PATH       - The path to the node code that needs to be built

apk add --no-cache zip

echo "Building node lambda from ${FOLDER_PATH}"
echo "Using node and npm versions"
node -v
npm -v
cd ${FOLDER_PATH}

npm install --quiet
npm run test
npm run webpack

echo "Copying certificates"
cd ./.webpack/
CERT_LOCATION="https://git.sys.cigna.com/CIP/certfix/raw/master/cigna.pem"
echo "Downloading from ${CERT_LOCATION}"
curl -sSLO ${CERT_LOCATION}
zip -r lambda.zip .

echo "Files that were built and webpacked"
ls -al
pwd
