#!/usr/bin/env sh

# These are common things that should not change
export AWS_PROFILE="saml"
export ENV="dev"
export TFVAR_FILE="sys"
export LOCAL="true"
export ENV_COMPUTED_NAME="sys"
export CERT_FILE_NAME="cigna.pem"
export GET_PLUGINS="true"
export AWS_REGION="us-east-1"

# User specific settings. Change these based on who you are
export STAGE="matthewping"

# Run specific things. These are things you'll change depending on what script you want to run and it's parameters
export FOLDER_PATH="code/lambdas/etl-runner"
# export TF_LOCATION="ci/terraform/controllers/buckets-tables"
# export S3_KEY_NAME_BASE="glue/data-structures.tfstate"
export TF_LOCATION="ci/terraform/controllers/jobs"
export S3_KEY_NAME_BASE="glue/eligibility.tfstate"
# export TF_LOCATION="ci/terraform/controllers/support"
# export S3_KEY_NAME_BASE="glue/support.tfstate"
export TERRAFORM_COMMAND="plan"

sh ci/scripts/run_with_env.sh $1
