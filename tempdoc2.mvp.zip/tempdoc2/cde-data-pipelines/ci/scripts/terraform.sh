# This file is resposible for 
# In addition to what's set in this file, to run locally, you'll need to set
# TERRAFORM_COMMAND  - The terraform command to be run (in the pipeline, it will be "plan" or "apply -input=false -auto-approve")
# TF_LOCATION        - The location of the terraform scripts
# TFSTATE_BUCKET     - The S3 bucket that the state is stored in
# LOCK_TABLE         - The DynamoDB lock table for the terraform that is being run

cd ${TF_LOCATION}

echo Running terraform in ${TF_LOCATION} 
echo Running terraform init for ${TFSTATE_BUCKET}/${S3_KEY_NAME} in ${AWS_REGION}
echo Using lock table ${LOCK_TABLE}

aws sts assume-role --role-arn ${ROLE_ARN} --role-session-name "fhir-cde-glue" > data.json

export AWS_ACCESS_KEY_ID="`cat data.json | jq ".Credentials.AccessKeyId" -r`"
export AWS_SECRET_ACCESS_KEY="`cat data.json | jq ".Credentials.SecretAccessKey" -r`"
export AWS_SESSION_TOKEN="`cat data.json | jq ".Credentials.SessionToken" -r`"

rm data.json

# Useful for debugging
terraform version

if [ -z "${LOCAL}" ]
then
   tfswitch ${TF_VERSION}
fi 

terraform init \
   -backend-config="bucket=$TFSTATE_BUCKET" \
   -backend-config="key=$S3_KEY_NAME" \
   -backend-config="region=$AWS_REGION" \
   -backend-config="dynamodb_table=$LOCK_TABLE" 

# Run terraform
echo Running terraform ${TERRAFORM_COMMAND} in ${ENV} account using ${TFVAR_FILE} tfvars
echo Using role: ${ROLE_ARN}

if [ -z "${LOCAL}" ]
then
   tfenv terraform ${TERRAFORM_COMMAND} \
      -var-file=../../../env/${TFVAR_FILE}.tfvars \
      -var-file=../../../env/common.tfvars
else 
   echo Running locally
   terraform ${TERRAFORM_COMMAND} \
      -var-file=../../../env/${TFVAR_FILE}.tfvars \
      -var-file=../../../env/common.tfvars
fi
