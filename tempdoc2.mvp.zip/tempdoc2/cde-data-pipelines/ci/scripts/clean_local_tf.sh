# This script is only for cleaning on your local machine. This is not run during the CI process

rm -rf ci/terraform/controllers/buckets-tables/.terraform
rm -rf ci/terraform/controllers/jobs/.terraform