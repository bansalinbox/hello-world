# This file copies and generates the configuration files for the Glue jobs
if [[ -z "${STAGE}" ]]
then
  STAGE="$(echo ${GITLAB_USER_LOGIN} | tr '[:upper:]' '[:lower:]' | tr -d '[:space:]')";
fi
echo "${CI_COMMIT_REF_NAME} branch has the committed the code"
if [[ ${CI_COMMIT_REF_NAME} =~ ^sys$|^pvs$|^sit$ ]]
then
  varPrefix=${CI_COMMIT_REF_NAME}
  dbSuffix=""
  tblPrefix=""
  glueDBSuffix=${CI_COMMIT_REF_NAME}
  cmtBucketSuffix=${CI_COMMIT_REF_NAME}
  echo "Going to set the $varPrefix setting"
elif [[ ${CI_COMMIT_REF_NAME} =~ ^master$|^main$|^release.* ]]
then
  varPrefix="prod"
  dbSuffix=""
  tblPrefix=""
  glueDBSuffix="prod"
  cmtBucketSuffix="prod"
  echo "Going to set the $varPrefix setting"
else
  dbSuffix="${STAGE}"
  tblPrefix="fhir_";
  varPrefix="feat"
  glueDBSuffix="${STAGE}"
  cmtBucketSuffix="${COMPUTED_ENV}-${STAGE}"
  echo "Going to set the $varPrefix setting"
fi
echo "${varPrefix}"

file="ci/scripts/app.properties"
if [ -f "$file" ]
then
  echo "$file found."

  while IFS='=' read -r key value
  do
    key=$(echo $key | tr '.' '_')
    eval ${key}=\${value}
  done < "$file"

  echo "Going to set the variable with prefix ${varPrefix}"
  ccw_dtl_tableName=$(eval "echo \${${varPrefix}_ccw_dtl_tableName}")
  ccw_acc_tableName=$(eval "echo \${${varPrefix}_ccw_acc_tableName}")
  ibor_tableName=$(eval "echo \${${varPrefix}_ibor_tableName}")
  ccw_client_struct_tableName=$(eval "echo \${${varPrefix}_ccw_client_struct_tableName}")
  ccw_db=$(eval "echo \${${varPrefix}_ccw_db}")${dbSuffix}
  clinical_db=$(eval "echo \${${varPrefix}_clinical_db}")${dbSuffix}
  dna_acc=$(eval "echo \${${varPrefix}_dna_acc}")
  ccw_struct_db=$(eval "echo \${${varPrefix}_ccw_struct_db}")${dbSuffix}
  icoll_patient_align_local_tableName=${icoll_patient_align_local_tableName}
  icoll_remote_tableName=$(eval "echo \${${varPrefix}_icoll_remote_tableName}")
  cde_elig_tableName=${cde_elig_tableName}
  ibor_local_tableName=${ibor_local_tableName}
  glue_db=${glue_db}${glueDBSuffix}
  glue_rpt_db=${glue_rpt_db}${glueDBSuffix}
  s3_glue_base_bucket=${s3_glue_base_bucket}${ENV}
  fhir_prefix=${fhir_prefix}
  s3_output_bucket=${s3_output_bucket}${cmtBucketSuffix}
  elig_adt_tableName=${elig_adt_tableName}
  echo "Set the variable with prefix ${varPrefix} is done"
else
  echo "$file not found."
fi

function templateFile() {
  FILENAME="ci/glue-env-config/${1}.tmpl"
  TEMPLATE_CMD="templatefile(\"$FILENAME\", { env: \"$ENV\", stage: \"$dbSuffix\", elig_adt_tableName: \"$elig_adt_tableName\",cde_elig_tableName: \"$cde_elig_tableName\", dnaAcctNum: \"$dna_acc\", ccw_struct_db: \"$ccw_struct_db\", s3BucketName: \"$S3_BUCKET_NAME\", s3_output_bucket: \"$s3_output_bucket\",ccw_db: \"$ccw_db\",clinical_db: \"$clinical_db\", glue_db: \"$glue_db\", glue_rpt_db: \"$glue_rpt_db\", fhir_prefix: \"$fhir_prefix\", s3_glue_base_bucket:\"$s3_glue_base_bucket\", glueDB: \"$GLUE_DB\", glueDBSrc: \"$GLUE_SRC_DB\",dbSuffix: \"$dbSuffix\", tblPrefix: \"$tblPrefix\", ccw_dtl_tableName: \"$ccw_dtl_tableName\", ccw_acc_tableName: \"$ccw_acc_tableName\",ccw_client_struct_tableName: \"$ccw_client_struct_tableName\", ibor_tableName: \"$ibor_tableName\", ibor_local_tableName: \"$ibor_local_tableName\", ccw_ssn_local_tableName: \"$ccw_ssn_local_tableName\", icoll_patient_align_local_tableName: \"$icoll_patient_align_local_tableName\", icoll_remote_tableName: \"$icoll_remote_tableName\"})"
  echo Creating $FILENAME using the following templatefile function:
  echo "${TEMPLATE_CMD}"
  mkdir -p src/main/scala/com/cigna/glue/scripts/main/config
  echo "${TEMPLATE_CMD}" | terraform console > "src/main/scala/com/cigna/glue/scripts/main/config/${1}_${glueDBSuffix}.json"
}

echo "${dbSuffix}"
templateFile "fhir_ccw_cust_acc_dtl_ssn_main"
templateFile "fhir_ccw_cust_acc_dtl_ssn_src_local"
templateFile "fhir_cde_cmt_eligibility_main"
templateFile "fhir_ibor_indiv_idnty_main"
templateFile "fhir_cmt_elig_adt_main"
templateFile "fhir_icoll_pat_alignment_main"


