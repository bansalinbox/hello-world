# This file is resposible for 
# In addition to what's set in this file, to run locally, you'll need to set
# TERRAFORM_COMMAND  - The terraform command to be run (in the pipeline, it will be "plan" or "apply -input=false -auto-approve")
# TF_LOCATION        - The location of the terraform scripts
# TFSTATE_BUCKET     - The S3 bucket that the state is stored in
# LOCK_TABLE         - The DynamoDB lock table for the terraform that is being run

APP_VER=$(cat APP_VER)

cd ${TF_LOCATION}

echo Running terraform in ${TF_LOCATION} 
echo Running terraform init for ${TFSTATE_BUCKET}/${S3_KEY_NAME} in ${AWS_REGION}
echo Using role ${ROLE_ARN}
echo Using lock table ${LOCK_TABLE}
echo Using version: $APP_VER of aws-glue-pipeline

# Useful for debugging
terraform version

if [ -z "${LOCAL}" ]
then
    terraform init -get-plugins=$GET_PLUGINS \
        -backend-config="bucket=$TFSTATE_BUCKET" \
        -backend-config="key=$S3_KEY_NAME" \
        -backend-config="region=$AWS_REGION" \
        -backend-config="role_arn=$ROLE_ARN" \
        -backend-config="dynamodb_table=$LOCK_TABLE" 
else 
    echo Running locally
    terraform init -get-plugins=${GET_PLUGINS} \
        -backend-config="bucket=$TFSTATE_BUCKET" \
        -backend-config="key=$S3_KEY_NAME" \
        -backend-config="region=$AWS_REGION" \
        -backend-config="dynamodb_table=$LOCK_TABLE" 
fi 

# Run terraform
echo Running terraform ${TERRAFORM_COMMAND} in ${ENV} account # using ${TFVAR_FILE} tfvars

if [ -z "${LOCAL}" ]
then
    terraform ${TERRAFORM_COMMAND} \
        -var stage=$STAGE \
        -var env=$ENV/ \
        -var jar_name=aws-glue-pipeline-$APP_VER-jar-with-dependencies.jar \
        -var jar_location=../target/
else 
    echo Running locally
    terraform ${TERRAFORM_COMMAND} \
        -var stage=$STAGE \
        -var env=$ENV/ \
        -var jar_name=aws-glue-pipeline-$APP_VER-jar-with-dependencies.jar \
        -var jar_location=../target/
fi 
