APP_VER=$(cat APP_VER)

# Common JAR file
ls -al target
echo Pushing common JAR from target/aws-glue-pipeline-${APP_VER}-jar-with-dependencies.jar to s3://fhir-code-deploy-${ENV}/${STAGE}/glue/common/aws-glue-pipeline-${APP_VER}-jar-with-dependencies.jar
aws s3 cp target/aws-glue-pipeline-${APP_VER}-jar-with-dependencies.jar s3://fhir-code-deploy-${ENV}/${STAGE}/glue/common/aws-glue-pipeline-${APP_VER}-jar-with-dependencies.jar

# Script files 
ls -al src/main/scala/com/cigna/glue/scripts/main
echo Pushing script files from src/main/scala/com/cigna/glue/scripts/main to s3://fhir-code-deploy-${ENV}/${STAGE}/glue/eligibility/script/ 
aws s3 sync --content-type text/plain src/main/scala/com/cigna/glue/scripts/main s3://fhir-code-deploy-${ENV}/${STAGE}/glue/eligibility/script/
