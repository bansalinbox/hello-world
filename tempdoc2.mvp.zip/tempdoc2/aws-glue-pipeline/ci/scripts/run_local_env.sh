#!/usr/bin/env sh

# These are common things that should not change
export AWS_PROFILE="saml"
export ENV="dev"
export LOCAL="true"
export GET_PLUGINS="true"
export AWS_REGION="us-east-1"

# User specific settings. Change these based on who you are
export STAGE="matthewping"

# Run specific things. These are things you'll change depending on what script you want to run and it's parameters
export TF_LOCATION="terraform"
export S3_KEY_NAME_BASE="glue/jar-etl-code.tfstate"
export TERRAFORM_COMMAND="plan"

. ./ci/scripts/set_env_vars.sh
. ./$1
