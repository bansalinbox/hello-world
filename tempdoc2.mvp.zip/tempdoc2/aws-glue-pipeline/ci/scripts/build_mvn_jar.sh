mvn -U clean package -Dmaven.repo.local="m2_repo"
