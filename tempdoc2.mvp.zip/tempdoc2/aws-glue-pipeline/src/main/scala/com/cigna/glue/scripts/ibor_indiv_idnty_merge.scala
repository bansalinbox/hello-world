package com.cigna.glue.scripts

import com.amazonaws.services.glue.GlueContext
import org.apache.spark.SparkContext
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{DataFrame, SaveMode}
import com.cigna.util.Utility._

object ibor_indiv_idnty_merge {

  var jsonString =
    """
    {
      "env": "src",
      "details": [
          {
            "key": "ibor_local",
            "dbName": "fhir_db_dev",
            "tableName": "ibor_indiv_idnty",
            "predicate": "",
            "accountNo": "",
            "filterCondition": [""],
            "s3PathRead": "",
            "s3PathWrite": ""
          },
          {
            "key": "ibor_inc",
            "dbName": "customer",
            "tableName": "ibor_indiv_idnty",
            "predicate": "incr_ingest_timestamp = 'incr_20181231041430'", // determine this in dynamic way
            "accountNo": "643101592424",
            "filterCondition": [""],
            "s3PathRead": "",
            "s3PathWrite": ""
          },
          {
            "key": "ibor_tmp",
            "dbName": "",
            "tableName": "",
            "predicate": "",
            "accountNo": "",
            "filterCondition": [""],
            "s3PathRead": "",
            "s3PathWrite": "s3://fhir-glue-dev/fhir_db_test/ibor_indiv_idnty_tmp/"
          }
        ]
    }
  """

  var jsonString2 =
    """
    {
      "env": "test",
      "details": [
          {
            "key": "ibor_local",
            "dbName": "fhir_db_test",
            "tableName": "ibor_indiv_idnty",
            "predicate": "",
            "accountNo": "",
            "filterCondition": [""],
            "s3PathRead": "",
            "s3PathWrite": "",
            "prep_data": false
          },
          {
            "key": "ibor_inc",
            "dbName": "fhir_db_src",
            "tableName": "ibor_indiv_idnty",
            "predicate": "incr_ingest_timestamp = 'incr_20181231041430'", // determine this in dynamic way
            "accountNo": "",
            "filterCondition": [""],
            "s3PathRead": "",
            "s3PathWrite": "",
            "prep_data": false
          },
          {
            "key": "ibor_tmp",
            "dbName": "",
            "tableName": "",
            "predicate": "",
            "accountNo": "",
            "filterCondition": [""],
            "s3PathRead": "",
            "s3PathWrite": "s3://fhir-glue-dev/fhir_db_test/ibor_indiv_idnty_tmp/",
            "prep_data": false
          }
        ]
    }
  """

  def run(sysArgs: Array[String]) {

    val sc: SparkContext = new SparkContext()
    val glueContext: GlueContext = new GlueContext(sc)

    //##############################ibor##############################
    val f1 = "indiv_enterprise_id = 1"
    val data = "data_ctgry_attrib_nm"
    val id = "indiv_enterprise_id"
    var key = "ibor_local"
    var ibor = fetchDataAsDFFromGlueTable(key, jsonString, glueContext).toDF()

    ibor = ibor.filter(f1)
    //##############################ibor_inc##############################
    key = "ibor_inc"
    val ibor_inc = fetchDataAsDFFromGlueTable(key, jsonString, glueContext)

    val ibor_inc_df = ibor_inc
      .filter(x => (x.getField(data).exists(_ == "GENDER")
        || x.getField(data).exists(_ == "NAME")
        || x.getField(data).exists(_ == "DOB")
        || x.getField(data).exists(_ == "ADDRESS")
        || x.getField(data).exists(_ == "PHONE")
        )).toDF()

    val ibor_inc_df_filtered = ibor_inc_df.select(id, data, "rcd_num", "addr_ty", "ph_ty", "addr_ln_1",
      "vrbl_attrib_val_txt", "frst_nm", "mid_nm", "last_nm", "ph_num", "vrbl_attrib_val_txt", "addr_ln_1", "addr_ln_2",
      "addr_city_nm", "addr_ste_nm", "addr_zip_cd", "addr_cnty_nm", "ingest_timestamp")
      .withColumn("rank", row_number().over(Window.partitionBy(id, data)
        .orderBy(
          when(column("ph_ty") === "HOMEPHONE", 11)
            .when(column("ph_ty") === "MOBILEPHONE", 12)
            .when(column("ph_ty") === "WORKPHONE", 13)
            .when(column("ph_ty") === "GENERALPHONE", 14)
            .when(column("ph_ty") === "OVRRDPHONE1", 15)
            .when(column("ph_ty") === "OVRRDPHONE2", 16)
            .when(column("ph_ty") === "BEEPERPHONE", 17)
            .when(column("ph_ty") === "TLLFREEPHONE", 18)
            .when(column("ph_ty") === "SECRESPHONE", 19)
            .when(column("ph_ty") === "PRIVATEPHONE", 20)
            .otherwise(null).asc,
          when(column("addr_ty") === "HOMEADDR", 1)
            .when(column("addr_ty") === "MAILADDR", 2)
            .when(column("addr_ty") === "OVERADDR", 3)
            .when(column("addr_ty") === "PRIVADDR", 4)
            .otherwise(null).asc,
          column("rcd_num").desc
        )
      )).where(column("rank") === 1)
      .withColumn("phone_type_order",
        when(column("ph_ty") === "HOMEPHONE", 11)
          .when(column("ph_ty") === "MOBILEPHONE", 12)
          .when(column("ph_ty") === "WORKPHONE", 13)
          .when(column("ph_ty") === "GENERALPHONE", 14)
          .when(column("ph_ty") === "OVRRDPHONE1", 15)
          .when(column("ph_ty") === "OVRRDPHONE2", 16)
          .when(column("ph_ty") === "BEEPERPHONE", 17)
          .when(column("ph_ty") === "TLLFREEPHONE", 18)
          .when(column("ph_ty") === "SECRESPHONE", 19)
          .when(column("ph_ty") === "PRIVATEPHONE", 20)
          .otherwise(null))
      .withColumn("addr_type_order",
        when(column("addr_ty") === "HOMEADDR", 1)
          .when(column("addr_ty") === "MAILADDR", 2)
          .when(column("addr_ty") === "OVERADDR", 3)
          .when(column("addr_ty") === "PRIVADDR", 4)
          .otherwise(null))


    var iborPivotAndSquashNew: DataFrame = ibor_inc_df_filtered.select(col(id),
      when(column(data) === "NAME", column("frst_nm")).as("first_nm"),
      when(column(data) === "NAME", column("mid_nm")).as("middle"),
      when(column(data) === "NAME", column("last_nm")).as("last_nm"),
      when(column(data) === "PHONE", column("ph_num")).as("home"),
      when(column(data) === "DOB", column("vrbl_attrib_val_txt")).as("dob"),
      when(column(data) === "GENDER", column("vrbl_attrib_val_txt")).as("gender"),
      when(column(data) === "ADDRESS", column("addr_ln_1")).as("address"),
      when(column(data) === "ADDRESS", column("addr_ln_2")).as("address2"),
      when(column(data) === "ADDRESS", column("addr_city_nm")).as("city"),
      when(column(data) === "ADDRESS", column("addr_ste_nm")).as("state"),
      when(column(data) === "ADDRESS", column("addr_zip_cd")).as("zip"),
      when(column(data) === "ADDRESS", column("addr_cnty_nm")).as("county"),
      col("ingest_timestamp").as("ingest_timestamp"),
      col("phone_type_order").as("phone_type_order"),
      col("addr_type_order").as("addr_type_order")
    ).groupBy(id).agg(
      collect_set("first_nm").getItem(0).as("first_nm"),
      collect_set("middle").getItem(0).as("middle"),
      collect_set("last_nm").getItem(0).as("last_nm"),
      collect_set("home").getItem(0).as("home"),
      collect_set("dob").getItem(0).as("dob"),
      collect_set("gender").getItem(0).as("gender"),
      collect_set("address").getItem(0).as("address"),
      collect_set("address2").getItem(0).as("address2"),
      collect_set("city").getItem(0).as("city"),
      collect_set("state").getItem(0).as("state"),
      collect_set("zip").getItem(0).as("zip"),
      collect_set("county").getItem(0).as("county"),
      collect_set("phone_type_order").getItem(0).as("phone_type_order"),
      collect_set("addr_type_order").getItem(0).as("addr_type_order"),
      collect_set("ingest_timestamp").getItem(0).as("ingest_timestamp")
    ).withColumn("last_updated_ts", column("ingest_timestamp"))

    def joinAndMerge(iborHistory: DataFrame, iborCurrent: DataFrame): DataFrame = {
      return iborHistory.join(iborCurrent, iborHistory(id) === iborCurrent(id), "full").select(
        when(iborHistory(id).isNull, iborCurrent(id).cast(IntegerType)).otherwise(iborHistory(id).cast(IntegerType)).as(id),
        when(iborHistory(id).isNull, iborCurrent("first_nm")).otherwise(when(iborHistory("ingest_timestamp") < iborCurrent("ingest_timestamp") && iborCurrent("first_nm").isNotNull, iborCurrent("first_nm")).otherwise(iborHistory("first_nm"))).as("first_nm"),
        when(iborHistory(id).isNull, iborCurrent("middle")).otherwise(when(iborHistory("ingest_timestamp") < iborCurrent("ingest_timestamp") && iborCurrent("first_nm").isNotNull, iborCurrent("middle")).otherwise(iborHistory("middle"))).as("middle"),
        when(iborHistory(id).isNull, iborCurrent("last_nm")).otherwise(when(iborHistory("ingest_timestamp") < iborCurrent("ingest_timestamp") && iborCurrent("first_nm").isNotNull, iborCurrent("last_nm")).otherwise(iborHistory("last_nm"))).as("last_nm"),
        when(iborHistory(id).isNull, iborCurrent("dob")).otherwise(when(iborHistory("ingest_timestamp") < iborCurrent("ingest_timestamp") && iborCurrent("dob").isNotNull, iborCurrent("dob")).otherwise(iborHistory("dob"))).as("dob"),
        when(iborHistory(id).isNull, iborCurrent("gender")).otherwise(when(iborHistory("ingest_timestamp") < iborCurrent("ingest_timestamp") && iborCurrent("gender").isNotNull, iborCurrent("gender")).otherwise(iborHistory("gender"))).as("gender"),
        when(iborHistory(id).isNull, iborCurrent("home")).otherwise(when(iborHistory("ingest_timestamp") < iborCurrent("ingest_timestamp") && iborCurrent("phone_type_order") <= iborHistory("phone_type_order") && iborCurrent("home").isNotNull, iborCurrent("home")).otherwise(iborHistory("home"))).as("home"),
        when(iborHistory(id).isNull, iborCurrent("address")).otherwise(when(iborHistory("ingest_timestamp") < iborCurrent("ingest_timestamp") && iborCurrent("addr_type_order") <= iborHistory("addr_type_order") && iborCurrent("address").isNotNull, iborCurrent("address")).otherwise(iborHistory("address"))).as("address"),
        when(iborHistory(id).isNull, iborCurrent("address2")).otherwise(when(iborHistory("ingest_timestamp") < iborCurrent("ingest_timestamp") && iborCurrent("addr_type_order") <= iborHistory("addr_type_order") && iborCurrent("address").isNotNull, iborCurrent("address2")).otherwise(iborHistory("address2"))).as("address2"),
        when(iborHistory(id).isNull, iborCurrent("city")).otherwise(when(iborHistory("ingest_timestamp") < iborCurrent("ingest_timestamp") && iborCurrent("addr_type_order") <= iborHistory("addr_type_order") && iborCurrent("address").isNotNull, iborCurrent("city")).otherwise(iborHistory("city"))).as("city"),
        when(iborHistory(id).isNull, iborCurrent("state")).otherwise(when(iborHistory("ingest_timestamp") < iborCurrent("ingest_timestamp") && iborCurrent("addr_type_order") <= iborHistory("addr_type_order") && iborCurrent("address").isNotNull, iborCurrent("state")).otherwise(iborHistory("state"))).as("state"),
        when(iborHistory(id).isNull, iborCurrent("zip")).otherwise(when(iborHistory("ingest_timestamp") < iborCurrent("ingest_timestamp") && iborCurrent("addr_type_order") <= iborHistory("addr_type_order") && iborCurrent("address").isNotNull, iborCurrent("zip")).otherwise(iborHistory("zip"))).as("zip"),
        when(iborHistory(id).isNull, iborCurrent("county")).otherwise(when(iborHistory("ingest_timestamp") < iborCurrent("ingest_timestamp") && iborCurrent("addr_type_order") <= iborHistory("addr_type_order") && iborCurrent("address").isNotNull, iborCurrent("county")).otherwise(iborHistory("county"))).as("county"),
        when(iborHistory(id).isNull, iborCurrent("phone_type_order")).otherwise(when(iborHistory("ingest_timestamp") < iborCurrent("ingest_timestamp") && iborCurrent("phone_type_order") <= iborHistory("phone_type_order") && iborCurrent("phone_type_order").isNotNull, iborCurrent("phone_type_order")).otherwise(iborHistory("phone_type_order"))).as("phone_type_order"),
        when(iborHistory(id).isNull, iborCurrent("addr_type_order")).otherwise(when(iborHistory("ingest_timestamp") < iborCurrent("ingest_timestamp") && iborCurrent("addr_type_order") <= iborHistory("addr_type_order") && iborCurrent("address").isNotNull, iborCurrent("addr_type_order")).otherwise(iborHistory("addr_type_order"))).as("addr_type_order"),
        when(iborHistory(id).isNull, iborCurrent("ingest_timestamp")).otherwise(when(iborHistory("ingest_timestamp") < iborCurrent("ingest_timestamp") && iborCurrent("ingest_timestamp").isNotNull, iborCurrent("ingest_timestamp")).otherwise(iborHistory("ingest_timestamp"))).as("ingest_timestamp")
      )
    }

    var resultSet = joinAndMerge(ibor, iborPivotAndSquashNew)
    key = "ibor_tmp" // this need to be ibor main table again
    var currentTable = findDetails(key, jsonString);
    resultSet.show()
    resultSet.write.mode(SaveMode.Overwrite).parquet(currentTable.s3PathWrite)
  }
}
