package com.cigna.glue.scripts

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

import com.amazonaws.services.glue.GlueContext
import com.cigna.util.Utility._
import org.apache.spark.SparkContext
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SaveMode}

object cmt_elig_adt {
  def run(configMap: Map[String, String]) {
    var jsonString = "";
    configMap get "TBLS_CONFIG" match {
      case Some(value) => jsonString = value
      case None => println("it is not possible")
    }
    val sc: SparkContext = new SparkContext()
    val glueContext: GlueContext = new GlueContext(sc)

    //############################## Standard Eligibility ##############################

    var std_key = "elig_adt_standard"
    println(s" ${read_tbl_msg} ${std_key}")

    val elig_adt_df = fetchDataAsDFFromGlueTable(std_key, jsonString, glueContext).toDF()
    var currentStdTable = findDetails(std_key, jsonString)
    var currentTimestamp = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSSSSS").format(LocalDateTime.now)
//
//    val elig_adt_df_standard: DataFrame = elig_adt_df.select(col("state"), col("county")
////      ,((current_timestamp().cast("long") - col("DOB").cast("timestamp").cast("long")) / (365 * 24D * 3600D)).as("age")
//    )
//      .filter(currentStdTable.filterCondition(0))
////      .filter(
////      col("age").cast("int") >= 18
////        and col("age").cast("int") < 130
////    )
//
//    val elig_adt_df_standard_final : DataFrame = elig_adt_df_standard.drop("age").groupBy("state", "county").agg(count("*").alias("population"))
//      .withColumn("type", lit("individual"))
//      .withColumn("condition", lit("standard"))
//      .withColumn("created_ts", lit(currentTimestamp).cast("timestamp"))
//      .select("created_ts", "type", "state", "county", "population", "condition")
//
//    val elig_adt_df_standard_final_total: DataFrame = elig_adt_df_standard.agg(count("*").alias("population"))
//      .withColumn("condition", lit("standard"))
//      .withColumn("type", lit("total"))
//      .withColumn("created_ts", lit(currentTimestamp).cast("timestamp"))
//      .select("created_ts", "type", "population", "condition")
//      .withColumn("state", lit(""))
//      .withColumn("county", lit(""))
//      .select("created_ts", "type", "state", "county", "population", "condition")

    //############################## VA Eligibility ##############################

    val va_key = "elig_adt_va"
    println(s" ${read_tbl_msg} ${va_key}")

    var currentVATable = findDetails(va_key, jsonString)
    val elig_adt_df_va: DataFrame = elig_adt_df.select("state", "county")
      .filter(currentVATable.filterCondition(0))
      .filter(currentVATable.filterCondition(1))  // This should bring in the funding arrangement limit

    val elig_adt_df_va_final: DataFrame = elig_adt_df_va.groupBy("state", "county").agg(count("*").alias("population"))
      .withColumn("type", lit("individual"))
      .withColumn("condition", lit("VA"))
      .withColumn("created_ts", lit(currentTimestamp).cast("timestamp"))
      .select("created_ts", "type", "state", "county", "population", "condition")

    val elig_adt_df_va_final_total: DataFrame = elig_adt_df_va.agg(count("*").alias("population"))
      .withColumn("type", lit("total"))
      .withColumn("condition", lit("VA"))
      .withColumn("state", lit(""))
      .withColumn("county", lit(""))
      .withColumn("created_ts", lit(currentTimestamp).cast("timestamp"))
      .select("created_ts", "type", "state", "county", "population", "condition")

    //############################## COVID Eligibility ##############################

//    val covid_key = "elig_adt_covid"
//    println(s" ${read_tbl_msg} ${covid_key}")
//
//    var currentCovidTable = findDetails(covid_key, jsonString)
//    val elig_adt_df_covid: DataFrame = elig_adt_df.select("state", "county")
//
//    val elig_adt_df_covid_final: DataFrame = elig_adt_df_covid.groupBy("state", "county").agg(count("*").alias("population"))
//      .withColumn("type", lit("individual"))
//      .withColumn("condition", lit("COVID"))
//      .withColumn("created_ts", lit(currentTimestamp).cast("timestamp"))
//      .select("created_ts", "type", "state", "county", "population", "condition")
//
//    val elig_adt_df_covid_final_total: DataFrame = elig_adt_df_covid.agg(count("*").alias("population"))
//      .withColumn("type", lit("total"))
//      .withColumn("condition", lit("COVID"))
//      .withColumn("state", lit(""))
//      .withColumn("county", lit(""))
//      .withColumn("created_ts", lit(currentTimestamp).cast("timestamp"))
//      .select("created_ts", "type", "state", "county", "population", "condition")

    elig_adt_df_va_final
      .unionAll(elig_adt_df_va_final_total)
//      .unionAll(elig_adt_df_covid_final)
//      .unionAll(elig_adt_df_covid_final_total)
      .coalesce(1).write.mode(SaveMode.Append).option("quoteAll","false").csv(currentStdTable.s3PathWrite)
  }
}

