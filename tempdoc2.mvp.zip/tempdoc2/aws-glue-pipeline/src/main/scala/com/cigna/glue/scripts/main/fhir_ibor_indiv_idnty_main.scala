import com.amazonaws.services.glue.util.GlueArgParser
import com.amazonaws.services.glue.util.Job
import com.cigna.glue.scripts._
import com.cigna.util.RequiredParameter

object fhir_ibor_indiv_idnty_main {

  def main(sysArgs: Array[String]): Unit = {
    val tbl_config : String = "TBLS_CONFIG"
    val args = GlueArgParser.getResolvedOptions(sysArgs, Seq("JOB_NAME",tbl_config).toArray)
    println("TBLS_CONFIG---->" + args(tbl_config))
    if(args(tbl_config).isEmpty){
      throw new RequiredParameter("Required TBLS_CONFIG parameter not found");
    }
    val configMap : Map[String, String] = Map("JOB_NAME" -> args("JOB_NAME"), tbl_config -> args(tbl_config))
    ibor_indiv_idnty.run(configMap);
    Job.commit()
  }
}
