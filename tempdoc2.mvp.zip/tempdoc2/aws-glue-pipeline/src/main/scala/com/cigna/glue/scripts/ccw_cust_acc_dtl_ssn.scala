package com.cigna.glue.scripts

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

import com.amazonaws.services.glue.GlueContext
import org.apache.spark.SparkContext
import org.apache.spark.sql.functions.{column, _}
import org.apache.spark.sql.{SQLContext, SaveMode}
import com.cigna.util.Utility._
import org.apache.spark.sql.expressions.Window

object ccw_cust_acc_dtl_ssn {
  def run(configMap: Map[String, String]) {
    var jsonString = "";
    configMap get "TBLS_CONFIG" match {
      case Some(value) => jsonString = value
      case None => println("it is not possible")
    }
    val sc: SparkContext = new SparkContext()
    val glueContext: GlueContext = new GlueContext(sc)
    val sqlContext = new SQLContext(sc);

    //##############################ccw_dtl##############################
    var key = "ccw_dtl"
    println(s" ${read_tbl_msg} ${key}")
    val ccw_dtl_df = fetchDataAsDFFromGlueTable(key, jsonString, glueContext).toDF()
    var currentTable = findDetails(key, jsonString);
    var ccw_dtl = sqlContext.emptyDataFrame
    var ccw_dtl_dedup = sqlContext.emptyDataFrame

    if (currentTable.prep_data == true) {
      ccw_dtl = ccw_dtl_df.select(col("*"))
      ccw_dtl.printSchema();
    } else {
      ccw_dtl = ccw_dtl_df.select("indiv_entpr_id", "nt_id", "client_ben_key", "elgbty_brnch_num", "cust_elgbty_acct_key", "ami", "rpt_seg_cd", "cust_elgbty_cvrg_eff_dt", "cust_elgbty_cvrg_term_dt")
        .where(
          column("prodt_ctgry_cd") === lit("MED")
            && column("chnl_cd") === lit("INT")
            && column("nt_id").isNotNull
            && column("cust_elgbty_cvrg_eff_dt") <= to_timestamp(current_timestamp())
            && (column("cust_elgbty_cvrg_term_dt") > current_date() || column("cust_elgbty_cvrg_term_dt").isNull)
            && (column("cust_intgrd_dtl_mv_term_dt") > to_timestamp(current_timestamp()) || column("cust_intgrd_dtl_mv_term_dt").isNull)
        )
      ccw_dtl_dedup = ccw_dtl.select("*").withColumn("rank", row_number().over(Window.partitionBy("indiv_entpr_id")
        .orderBy(column("indiv_entpr_id").desc)
      )).where(column("rank") === 1).drop(column("rank"))
    }
    if (currentTable.prep_data == true) {
      println(s" ${crt_tbl_msg} ${key}")
      ccw_dtl.show()
      ccw_dtl.limit(10)
      ccw_dtl.limit(10).write.mode(SaveMode.Append).csv(currentTable.s3PathWrite)
    }

    //##############################ccw_acc##############################
    key = "ccw_acc"
    println(s" ${read_tbl_msg} ${key}")
    currentTable = findDetails(key, jsonString);
    var ccw_acc = sqlContext.emptyDataFrame
    var ccw_acc_dedup = sqlContext.emptyDataFrame
    val ccw_acc_df = fetchDataAsDFFromGlueTable(key, jsonString, glueContext).toDF()
    if (currentTable.prep_data == true) {
      ccw_acc = ccw_acc_df.select(col("*"))
    } else {
      ccw_acc = ccw_acc_df.select("indiv_entpr_id", "cust_supld_ssn", "cust_elgbty_acct_key", "cust_supld_ssn", "curr_rcd_ind", "chnl_cd", "updt_ts")
        .where(
          column("curr_rcd_ind") === lit("Y")
            && column("chnl_cd") === lit("INT")
            && column("cust_supld_ssn").isNotNull
            && column("cust_supld_ssn").notEqual(lit("000000000"))
            && column("cust_supld_ssn").notEqual(lit("999999999"))
        )
      ccw_acc_dedup = ccw_acc.select("*").withColumn("rank", row_number().over(Window.partitionBy("indiv_entpr_id")
        .orderBy(column("indiv_entpr_id").desc)
      )).where(column("rank") === 1).drop(column("rank"))
    }
    if (currentTable.prep_data == true) {
      println(s" ${crt_tbl_msg} ${key}")
      ccw_acc.show()
      ccw_acc.write.mode(SaveMode.Append).csv(currentTable.s3PathWrite)
    }
    //##############################ccw_client##############################
    //    key = "ccw_client"
    //    println(s" ${read_tbl_msg} ${key}")
    //    currentTable = findDetails(key, jsonString)
    //
    //    var ccw_client = sqlContext.emptyDataFrame
    //    val ccw_client_df = fetchDataAsDFFromGlueTable(key, jsonString, glueContext).toDF()
    //    if (currentTable.prep_data == true) {
    //      ccw_client = ccw_client_df.select(col("*"))
    //    } else {
    //      ccw_client = ccw_client_df.select(col("client_acct_key"), col("client_id"), col("client_acct_nm"), col("client_acct_num"), col("fund_arngmt_ty_cd"), col("client_acct_eff_dt").cast("timestamp"), col("client_acct_termntn_dt").cast("timestamp"))
    //        .where(
    //          column("client_id").isNotNull
    //            && column("client_acct_eff_dt") <= to_timestamp(current_timestamp())
    //            && (column("client_acct_termntn_dt") > to_timestamp(current_timestamp()) || column("client_acct_termntn_dt").isNull)
    //        )
    //    }
    //    if (currentTable.prep_data == true) {
    //      println(s" ${crt_tbl_msg} ${key}")
    //      ccw_client.show()
    //      ccw_client.write.mode(SaveMode.Append).csv(currentTable.s3PathWrite)
    //    }
    //##############################ccw_client_struct##############################
    key = "ccw_client_struct"
    println(s" ${read_tbl_msg} ${key}")
    currentTable = findDetails(key, jsonString)

    var ccw_client_struct = sqlContext.emptyDataFrame
    val ccw_client_struct_df = fetchDataAsDFFromGlueTable(key, jsonString, glueContext).toDF()
    if (currentTable.prep_data == true) {
      ccw_client_struct = ccw_client_struct_df.select(col("*"))
    } else {
      ccw_client_struct = ccw_client_struct_df.select(col("elgbty_brnch_num"), col("nt_id"), col("client_ben_key"), col("client_id"), col("client_acct_nm"), col("client_acct_num"), col("fund_arngmt_ty_cd"))
        .where(
          column("nt_id").isNotNull
            && column("prodt_ctgry_cd") === lit("MED")
            && column("chnl_cd") === lit("INT")
            && column("client_struc_intgrd_mv_eff_dt") <= to_timestamp(current_timestamp())
            && (column("client_struc_intgrd_mv_term_dt") >= to_timestamp(current_timestamp()) || column("client_struc_intgrd_mv_term_dt").isNull)
        )
    }
    if (currentTable.prep_data == true) {
      println(s" ${crt_tbl_msg} ${key}")
      ccw_client_struct.show()
      ccw_client_struct.write.mode(SaveMode.Append).csv(currentTable.s3PathWrite)
    }
    //##############################ccw_final##############################
    var currentTimestamp = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format(LocalDateTime.now);
    var ccw_ssn_dedup = ccw_dtl_dedup.join(ccw_client_struct, ccw_dtl_dedup("elgbty_brnch_num") === ccw_client_struct("elgbty_brnch_num") && ccw_dtl_dedup("nt_id") === ccw_client_struct("nt_id") && ccw_dtl_dedup("client_ben_key") === ccw_client_struct("client_ben_key"), "inner")
      .join(ccw_acc_dedup, ccw_acc_dedup("indiv_entpr_id") === ccw_dtl_dedup("indiv_entpr_id"), "left")
      .select(ccw_dtl_dedup("indiv_entpr_id"),ccw_acc_dedup("cust_supld_ssn"),ccw_client_struct("client_id"),ccw_dtl_dedup("ami"),ccw_client_struct("client_acct_nm"),
        ccw_client_struct("client_acct_num"),ccw_dtl_dedup("rpt_seg_cd"),ccw_dtl_dedup("cust_elgbty_cvrg_eff_dt").cast("timestamp"),ccw_dtl_dedup("cust_elgbty_cvrg_term_dt").cast("timestamp"),ccw_client_struct("fund_arngmt_ty_cd")).withColumn("last_updated_ts", lit(currentTimestamp).cast("timestamp"))

        key = "ccw_final"
        println(s" ${write_s3_msg} ${key}")
        currentTable = findDetails(key, jsonString)
        ccw_ssn_dedup.write.mode(SaveMode.Overwrite).parquet(currentTable.s3PathWrite)
  }
}




