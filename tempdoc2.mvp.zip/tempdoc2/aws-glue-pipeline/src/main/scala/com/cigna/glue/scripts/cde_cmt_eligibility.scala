package com.cigna.glue.scripts

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

import com.amazonaws.services.glue.GlueContext
import org.apache.spark.SparkContext
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.functions.{col, column, current_date, current_timestamp, lit, to_timestamp, when}
import com.cigna.util.Utility._

object cde_cmt_eligibility {

  def run(configMap: Map[String, String]) {
    var jsonString = "";
    configMap get "TBLS_CONFIG" match {
      case Some(value) => jsonString = value
      case None => println("it is not possible")
    }

    val sc: SparkContext = new SparkContext()
    val glueContext: GlueContext = new GlueContext(sc)

    //##############################ibor_local##############################
    var key = "ibor_local"
    println(s" ${read_tbl_msg} ${key}")
    val ibor = fetchDataAsDFFromGlueTable(key, jsonString, glueContext)
    val ibor_df = fetchDataAsDFFromGlueTable(key, jsonString, glueContext).toDF()

    //##############################ccw_ssn##############################
    key = "ccw_ssn"
    val ccw_ssn_df = fetchDataAsDFFromGlueTable(key, jsonString, glueContext).toDF()
    val ccw_ssn_all_df = ccw_ssn_df.select(col("*"))

    val ibor_elig_all = ibor_df.join(ccw_ssn_all_df, ibor_df("indiv_enterprise_id") === ccw_ssn_all_df("indiv_entpr_id"), "inner")

    var cde_elg = ibor_elig_all.select(
      ibor_df.col("indiv_enterprise_id"),
      col("address").as("Address"),
      col("address2").as("Address2"),
      col("city").as("City"),
      col("state").as("State"),
      col("zip").as("Zip"),
      col("county").as("County"),
      col("cust_supld_ssn").as("SSN"),
      col("dob").as("DOB"),
      col("gender").as("Gender"),
      col("home").as("Home"),
      col("first_nm").as("First"),
      col("middle").as("Middle"),
      col("last_nm").as("Last"),
      lit("CIGNA CORP").as("InsurerName"),
      lit("1").as("InsurerID"),
      col("client_id").as("PolicyNumber"),
      col("ami").as("PolicyNumberSuffix"),
      col("client_acct_nm").as("InsurerGroupName"),
      col("client_acct_num").as("InsurerGroupID"),
      col("fund_arngmt_ty_cd").as("fund_arngmt_ty_cd"),
      when(
        (column("rpt_seg_cd") === "IFP_OTHERS" || column("rpt_seg_cd") === "IFP_CONNCT" || column("rpt_seg_cd") === "IFP_OTHECN"), lit("IFP")
      ).otherwise(lit("COMMERCIAL")).as("LOB"),
      (col("cust_elgbty_cvrg_eff_dt").cast("timestamp")).as("EnrollmentStartDate"),
      (col("cust_elgbty_cvrg_term_dt").cast("timestamp")).as("EnrollmentEndDate"),
      ((current_timestamp().cast("long") - col("DOB").cast("timestamp").cast("long")) / (365 * 24D * 3600D)).as("age")
    )

    var currentTimestamp = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format(LocalDateTime.now);
    import java.time.format.DateTimeFormatter
    val currentTSFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").format(LocalDateTime.now);

    key = "cde_elig"
    var currentTable = findDetails(key, jsonString);
    cde_elg.drop(col("age")).withColumn("last_updated_ts", lit(currentTimestamp).cast("timestamp")).write.mode(SaveMode.Overwrite).parquet(currentTable.s3PathRead);
    cde_elg = cde_elg.withColumnRenamed("indiv_enterprise_id", "Patient Primary Identifier");

    /* Stop creating the covid file
    val cde_elg_all = cde_elg.drop(col("age")).drop(col("fund_arngmt_ty_cd"));
    cde_elg_all.repartition(col("State")).write.mode(SaveMode.Overwrite).option("header", "true").option("quoteAll","true").option("compression","gzip").option("delimiter", ",").csv(currentTable.s3PathWrite + "covid/CMT_Eligibility_" + currentTSFormat + "/");
    */
    val cde_elg_va = cde_elg.drop(col("age")).filter(currentTable.filterCondition(0)).filter(currentTable.filterCondition(2)).drop(col("fund_arngmt_ty_cd"));
    cde_elg_va.coalesce(1).write.mode(SaveMode.Overwrite).option("header", "true").option("quoteAll","true").option("delimiter", ",").csv(currentTable.s3PathWrite + "va/");

    //##############################ccw_ssn##############################
//    val cde_elg_standard = cde_elg.drop(col("fund_arngmt_ty_cd")).filter(currentTable.filterCondition(1));
//      //      .filter(
//      //      col("age").cast("int") >= 18
//      //        and col("age").cast("int") < 130
//      //    );
//    key = "pat_align"
//    val pat_align_df = fetchDataAsDFFromGlueTable(key, jsonString, glueContext).toDF()
//    var pat_align_all_df = pat_align_df.select(col("ibor_id"), col("clbrtn_id")).withColumnRenamed("clbrtn_id","CacId");
//    // Join With the iColl Alignment
//    var elig_standard = cde_elg_standard.join(pat_align_all_df, cde_elg_standard("Patient Primary Identifier") === pat_align_all_df("ibor_id") , "inner").select(
//      cde_elg_standard("Patient Primary Identifier"),
//      cde_elg_standard("Address"),
//      cde_elg_standard("Address2"),
//      cde_elg_standard("City"),
//      cde_elg_standard("State"),
//      cde_elg_standard("Zip"),
//      cde_elg_standard("County"),
//      cde_elg_standard("SSN"),
//      cde_elg_standard("DOB"),
//      cde_elg_standard("Gender"),
//      cde_elg_standard("Home"),
//      cde_elg_standard("First"),
//      cde_elg_standard("Middle"),
//      cde_elg_standard("Last"),
//      cde_elg_standard("InsurerName"),
//      cde_elg_standard("InsurerID"),
//      cde_elg_standard("PolicyNumber"),
//      cde_elg_standard("PolicyNumberSuffix"),
//      cde_elg_standard("InsurerGroupName"),
//      cde_elg_standard("InsurerGroupID"),
//      cde_elg_standard("LOB"),
//      cde_elg_standard("EnrollmentStartDate"),
//      cde_elg_standard("EnrollmentEndDate"),
//      pat_align_all_df("CacId")
//    )
//    elig_standard
//      .limit(100000)
//      .coalesce(1).write.mode(SaveMode.Overwrite).option("quoteAll","true").option("header", "true").option("delimiter", ",").csv(currentTable.s3PathWrite + "standard/");
  }

}
