import com.amazonaws.services.glue.util.{GlueArgParser, Job}
import com.cigna.glue.scripts._
import com.cigna.util.RequiredParameter

object fhir_cmt_elig_adt_main {
  def main(sysArgs: Array[String]): Unit = {
    val tbl_config : String = "TBLS_CONFIG"
    val args = GlueArgParser.getResolvedOptions(sysArgs, Seq("JOB_NAME",tbl_config).toArray)
    println("TBLS_CONFIG---->" + args(tbl_config))
    if(args(tbl_config).isEmpty){
      throw new RequiredParameter("Required JSON_CONFIG parameter not found");
    }
    val configMap : Map[String, String] = Map("JOB_NAME" -> args("JOB_NAME"), tbl_config -> args(tbl_config))
    cmt_elig_adt.run(configMap);
    Job.commit()
  }
}
