package com.cigna.util

import net.liftweb.json.{DefaultFormats, parse }

case class Details(key: String, dbName: String, tableName: String, predicate: String, accountNo: String, filterCondition: List[String], s3PathRead: String, s3PathWrite: String, prep_data : Boolean)

case class TablesConfig(env: String, details: List[Details])

object Utility {

  import com.amazonaws.services.glue.{DynamicFrame, GlueContext}

  val crt_tbl_msg = "going to create data for the table : "
  val read_tbl_msg = "Going to read the table"
  val write_s3_msg = "Going to write the data to s3 fro the key"

  def findDetails(criteria: String, jsonString: String): Details = {
    implicit val formats = DefaultFormats
    val jValue = parse(jsonString)
    val tablesConfig = jValue.extract[TablesConfig]
    val tableDetails = tablesConfig.details
    val currentTable: Option[Details] = tableDetails.find(x => x.key == criteria)
    currentTable.get
  }

  def fetchDataAsDFFromGlueTable(key: String, jsonString: String, glueContext: GlueContext): DynamicFrame = {
    val currentTable: Details = findDetails(key, jsonString);
    val dbName = currentTable.dbName
    val tableName = currentTable.tableName
    val predicate = currentTable.predicate
    val accountNo = currentTable.accountNo
    val s3PathWrite = currentTable.s3PathWrite

    println(s"INFO: key: $key, dbName : $dbName, tableName : $tableName, predicate : $predicate, accountNo : $accountNo, s3PathWrite : $s3PathWrite")
    if ("".equals(predicate)) {
      return glueContext
        .getCatalogSource(database = dbName, tableName = tableName, catalogId = accountNo)
        .getDynamicFrame()
    } else {
      return glueContext
        .getCatalogSource(database = dbName, tableName = tableName, pushDownPredicate = predicate, catalogId = accountNo)
        .getDynamicFrame()
    }
  }
}


class RequiredParameter(msg: String) extends Exception(msg) {
  def this(msg: String, cause: Throwable) = {
    this(msg)
    initCause(cause)
  }

  def this(cause: Throwable) = {
    this(Option(cause).map(_.toString).orNull)
    initCause(cause)
  }

  def this() = {
    this(null: String)
  }
}
