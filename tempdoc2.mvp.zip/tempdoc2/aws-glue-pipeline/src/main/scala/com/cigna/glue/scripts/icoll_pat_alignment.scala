package com.cigna.glue.scripts

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

import com.amazonaws.services.glue.GlueContext
import com.cigna.util.Utility._
import org.apache.spark.SparkContext
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{column, _}
import org.apache.spark.sql.types.{DataType, IntegerType, Metadata}
import org.apache.spark.sql.{DataFrame, RelationalGroupedDataset, SQLContext, SaveMode}

object icoll_pat_alignment {
  def run(configMap: Map[String, String]) {
    var jsonString = "";
    configMap get "TBLS_CONFIG" match {
      case Some(value) => jsonString = value
      case None => println("it is not possible")
    }
    val sc: SparkContext = new SparkContext()
    val glueContext: GlueContext = new GlueContext(sc)
    val sqlContext = new SQLContext(sc);
    //##############################pat_align remote##############################
    import java.time.format.DateTimeFormatter
    val currentTSFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").format(LocalDateTime.now);
    var key = "pat_align_remote"
    println(s" ${read_tbl_msg} ${key}")
    val pat_align_df = fetchDataAsDFFromGlueTable(key, jsonString, glueContext).toDF()
    var currentTable = findDetails(key, jsonString);
    var pat_align = sqlContext.emptyDataFrame
    var pat_align_s1 = sqlContext.emptyDataFrame
    pat_align = pat_align_df.select("indiv_entpr_id", "prov_id","PROV_ALGNMT_MTHD_CD","clbrtn_sub_grp_id",
      "ffv_ty_cd","cret_ts","updt_ts","ingest_timestamp","chnl_cd","chnl_src_cd","RPT_PER_END_DT","clbrtn_id")
    .where(column("curr_rcd_ind") === lit("Y")
    && column("FLLOUT_ALGNMT_IND") === lit("N")
    )

    pat_align_s1 = pat_align.filter(column("curr_rcd_ind") === lit("Y")
      && column("FLLOUT_ALGNMT_IND") === lit("N"))
      .select(max("updt_ts").alias("updt_ts"), max("RPT_PER_END_DT").alias("RPT_PER_END_DT"))



    var pat_step1 = pat_align.join(pat_align_s1, pat_align("updt_ts") === pat_align_s1("updt_ts") && pat_align("RPT_PER_END_DT") === pat_align_s1("RPT_PER_END_DT") , "inner")
        .select(pat_align("indiv_entpr_id"),pat_align("prov_id"),pat_align("PROV_ALGNMT_MTHD_CD")
          ,pat_align("clbrtn_sub_grp_id"),pat_align("ffv_ty_cd"),pat_align("cret_ts"),pat_align("updt_ts")
          ,pat_align("ingest_timestamp"),pat_align("chnl_cd"),pat_align("chnl_src_cd"),
          lit("0").alias("inactive"),pat_align("clbrtn_id"))
      .distinct()

    var pat_step2_s1 : DataFrame= pat_step1.select(pat_step1("indiv_entpr_id"),
      pat_step1("updt_ts"), pat_step1("prov_algnmt_mthd_cd").alias("algnmt_mthd_cd"))
    .groupBy("indiv_entpr_id", "updt_ts")
      .agg(min("algnmt_mthd_cd").alias("algnmt_mthd_cd"))

    var pat_step2 = pat_step1.join(pat_step2_s1,pat_step1("indiv_entpr_id") === pat_step2_s1("indiv_entpr_id") && pat_step1("updt_ts") === pat_step2_s1("updt_ts") && pat_step1("prov_algnmt_mthd_cd") === pat_step2_s1("algnmt_mthd_cd"),"inner")
      .distinct()
        .select(pat_step1("indiv_entpr_id").as("ibor_id"),pat_step1("prov_id").as("provider_id"),pat_step1("PROV_ALGNMT_MTHD_CD").as("alignment_method_code")
          ,pat_step1("clbrtn_sub_grp_id").as("subgroup_id"),pat_step1("ffv_ty_cd").as("ifp_indicator")
          ,pat_step1("cret_ts"),pat_step1("updt_ts"),pat_step1("ingest_timestamp"),pat_step1("chnl_cd"),pat_step1("chnl_src_cd"),pat_step1("inactive"),pat_step1("clbrtn_id"))

    //##############################pat_align local##############################
    key = "pat_align_local"
    println(s" ${read_tbl_msg} ${key}")
    val pat_align_local_df = fetchDataAsDFFromGlueTable(key, jsonString, glueContext).toDF()
    currentTable = findDetails(key, jsonString);

    val step3a = pat_align_local_df.join(pat_step2, pat_step2("ibor_id") === pat_align_local_df("ibor_id"),"left")
    .select(pat_align_local_df("IBOR_ID"),pat_align_local_df("PROVIDER_ID"),pat_align_local_df("ALIGNMENT_METHOD_CODE"),pat_align_local_df("subgroup_id"),pat_align_local_df("IFP_INDICATOR"),pat_align_local_df("cret_ts")
      ,when(pat_step2("inactive").isNull, lit(currentTSFormat).cast("timestamp")).otherwise(pat_align_local_df("updt_ts")).as("updt_ts")
      ,pat_align_local_df("ingest_timestamp"),pat_align_local_df("chnl_cd"),pat_align_local_df("chnl_src_cd")
      ,when(pat_step2("inactive").isNull, lit("1")).otherwise(pat_align_local_df("updt_ts")).as("inactive"),pat_align_local_df("clbrtn_id"))
      .filter(pat_align_local_df("IBOR_ID").isNotNull && pat_align_local_df("provider_id").isNotNull && pat_align_local_df("inactive") === "1")

    val step3b = pat_step2.join(pat_align_local_df, pat_step2("ibor_id") === pat_align_local_df("ibor_id"),"left")
      .select(pat_step2("IBOR_ID"),pat_step2("PROVIDER_ID"),pat_step2("ALIGNMENT_METHOD_CODE"),pat_step2("subgroup_id"),pat_step2("IFP_INDICATOR"),pat_step2("cret_ts")
        ,when(pat_align_local_df("inactive").isNull, lit(currentTSFormat).cast("timestamp")).otherwise(pat_align_local_df("updt_ts")).as("updt_ts")
        ,pat_step2("ingest_timestamp"),pat_step2("chnl_cd"),pat_step2("chnl_src_cd")
        ,when(pat_align_local_df("inactive").isNull, lit("0")).otherwise(pat_step2("updt_ts")).as("inactive"),pat_step2("clbrtn_id"))
      .filter(pat_step2("IBOR_ID").isNotNull && pat_step2("provider_id").isNotNull)

    val icoll_alignment_final = step3a.union(step3b)
    icoll_alignment_final.write.mode(SaveMode.Overwrite).csv(currentTable.s3PathWrite)
  }
}




