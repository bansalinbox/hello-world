package com.cigna.glue.scripts

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

import com.amazonaws.services.glue.GlueContext
import org.apache.spark.SparkContext
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{DataFrame, SaveMode}
import com.cigna.util.Utility._

object ibor_indiv_idnty {

  def run(configMap: Map[String, String]) {
    var jsonString = "";
    configMap get "TBLS_CONFIG" match {
      case Some(value) => jsonString = value
      case None => println("it is not possible")
    }
    val sc: SparkContext = new SparkContext()
    //##############################ibor##############################
    val glueContext: GlueContext = new GlueContext(sc)
    var currentTimestamp = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format(LocalDateTime.now);
    var key = "ibor"
    println(s" ${read_tbl_msg} ${key}")
    val ibor = fetchDataAsDFFromGlueTable(key, jsonString, glueContext)
    val ibor_df = ibor
      .filter(x => (x.getField("data_ctgry_attrib_nm").exists(_ == "GENDER")
        || x.getField("data_ctgry_attrib_nm").exists(_ == "NAME")
        || x.getField("data_ctgry_attrib_nm").exists(_ == "DOB")
        || x.getField("data_ctgry_attrib_nm").exists(_ == "ADDRESS")
        || x.getField("data_ctgry_attrib_nm").exists(_ == "PHONE")
        )).toDF()

    val ibor_pivot_df = ibor_df.select("indiv_enterprise_id", "data_ctgry_attrib_nm", "rcd_num", "addr_ty", "ph_ty", "addr_ln_1",
      "vrbl_attrib_val_txt", "frst_nm", "mid_nm", "last_nm", "ph_num", "vrbl_attrib_val_txt", "addr_ln_1", "addr_ln_2",
      "addr_city_nm", "addr_ste_nm", "addr_zip_cd", "addr_cnty_nm", "ingest_timestamp")
      .withColumn("rank", row_number().over(Window.partitionBy("indiv_enterprise_id", "data_ctgry_attrib_nm")
        .orderBy(
          when(column("ph_ty") === "HOMEPHONE", 11)
            .when(column("ph_ty") === "MOBILEPHONE", 12)
            .when(column("ph_ty") === "WORKPHONE", 13)
            .when(column("ph_ty") === "GENERALPHONE", 14)
            .when(column("ph_ty") === "OVRRDPHONE1", 15)
            .when(column("ph_ty") === "OVRRDPHONE2", 16)
            .when(column("ph_ty") === "BEEPERPHONE", 17)
            .when(column("ph_ty") === "TLLFREEPHONE", 18)
            .when(column("ph_ty") === "SECRESPHONE", 19)
            .when(column("ph_ty") === "PRIVATEPHONE", 20)
            .otherwise(null).asc,
          when(column("addr_ty") === "HOMEADDR", 1)
            .when(column("addr_ty") === "MAILADDR", 2)
            .when(column("addr_ty") === "OVERADDR", 3)
            .when(column("addr_ty") === "PRIVADDR", 4)
            .otherwise(null).asc,
          column("rcd_num").desc
        )
      )).where(column("rank") === 1)
    var currentTable = findDetails(key, jsonString);

    var iborPivotAndSquash: DataFrame = ibor_pivot_df.select(col("indiv_enterprise_id").cast(IntegerType),
      when(column("data_ctgry_attrib_nm") === "NAME", column("frst_nm")).as("first_nm"),
      when(column("data_ctgry_attrib_nm") === "NAME", column("mid_nm")).as("middle"),
      when(column("data_ctgry_attrib_nm") === "NAME", column("last_nm")).as("last_nm"),
      when(column("data_ctgry_attrib_nm") === "PHONE", column("ph_num")).as("home"),
      when(column("data_ctgry_attrib_nm") === "DOB", column("vrbl_attrib_val_txt")).as("dob"),
      when(column("data_ctgry_attrib_nm") === "GENDER", column("vrbl_attrib_val_txt")).as("gender"),
      when(column("data_ctgry_attrib_nm") === "ADDRESS", column("addr_ln_1")).as("address"),
      when(column("data_ctgry_attrib_nm") === "ADDRESS", column("addr_ln_2")).as("address2"),
      when(column("data_ctgry_attrib_nm") === "ADDRESS", column("addr_city_nm")).as("city"),
      when(column("data_ctgry_attrib_nm") === "ADDRESS", column("addr_ste_nm")).as("state"),
      when(column("data_ctgry_attrib_nm") === "ADDRESS", column("addr_zip_cd")).as("zip"),
      when(column("data_ctgry_attrib_nm") === "ADDRESS", column("addr_cnty_nm")).as("county"),
      col("ingest_timestamp").as("ingest_timestamp")
    ).groupBy("indiv_enterprise_id").agg(
      collect_set("first_nm").getItem(0).as("first_nm"),
      collect_set("middle").getItem(0).as("middle"),
      collect_set("last_nm").getItem(0).as("last_nm"),
      collect_set("home").getItem(0).as("home"),
      collect_set("dob").getItem(0).as("dob"),
      collect_set("gender").getItem(0).as("gender"),
      collect_set("address").getItem(0).as("address"),
      collect_set("address2").getItem(0).as("address2"),
      collect_set("city").getItem(0).as("city"),
      collect_set("state").getItem(0).as("state"),
      collect_set("zip").getItem(0).as("zip"),
      collect_set("county").getItem(0).as("county"),
      collect_set("ingest_timestamp").getItem(0).as("ingest_timestamp")
    ).withColumn("last_updated_ts", lit(currentTimestamp).cast("timestamp"))
    //.filter(currentTable.filterCondition(0)); removing due to covid changes

    iborPivotAndSquash.write.mode(SaveMode.Overwrite).parquet(currentTable.s3PathWrite)

  }
}
