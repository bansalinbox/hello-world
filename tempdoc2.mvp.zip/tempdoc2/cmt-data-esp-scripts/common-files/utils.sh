#!/bin/bash

bline() {
    ENV=$1

    # int and pvs are currently the same
    if [ "${ENV}" = "int" ] || [ "${ENV}" = "pvs" ]
    then
        export BEELINE_JDBC="jdbc:hive2://t-hive.sys.cigna.com:25006/default;principal=hive/t-hive.sys.cigna.com@HADOOPQA.SYS.CIGNATEST.COM"
    elif [ "${ENV}" = "prod" ] || [ "${ENV}" = "PRD" ]
    then
        export BEELINE_JDBC="jdbc:hive2://hive.sys.cigna.com:25006/default;principal=hive/hive.sys.cigna.com@INTERNAL.CIGNA.COM"
    else
        exit 1
    fi
}

krbauth() {
    ENV=$1

    # int and pvs are currently the same
    if [ "${ENV}" = "int" ] || [ "${ENV}" = "pvs" ]
    then
        kinit -S krbtgt/SILVER.COM@SILVER.COM rtdesvc@SILVER.COM -k -t "$HOME"/rtdesvc.keytab
    elif [ "${ENV}" = "prod" ] || [ "${ENV}" = "PRD" ]
    then
        kinit -S krbtgt/INTERNAL.CIGNA.COM@INTERNAL.CIGNA.COM rtdesvc@INTERNAL.CIGNA.COM -k -t /opt/app/cis/rtdesvc.keytab
    else
        exit 1
    fi
}

queuename() {
    ENV=$1

    # int and pvs are currently the same
    if [ "${ENV}" = "int" ] || [ "${ENV}" = "pvs" ]
    then
        export QUEUE_NAME=g_hadoop_d_clin_dev
    elif [ "${ENV}" = "prod" ] || [ "${ENV}" = "PRD" ]
    then
        export QUEUE_NAME=g_hadoop_p_clin_dev
    else
        exit 1
    fi
}

hbaseConfigDir() {
    ENV=$1

    if [ "${ENV}" = "int" ]
    then
        export HBASE_CONFIG_DIR=/opt/app/dev/hbase-configs/int
    elif [ "${ENV}" = "pvs" ]
    then
        export HBASE_CONFIG_DIR=/opt/app/dev/hbase-configs/pvs
    elif [ "${ENV}" = "prod" ] || [ "${ENV}" = "PRD" ]
    then
        export HBASE_CONFIG_DIR=/opt/app/dev/hbase-configs/prod
    else
        exit 1
    fi
}

hbaseURL() {
    ENV=$1

    if [ "${ENV}" = "int" ]
    then
        export HBASE_URL=cilhbnms0001.sys.cigna.com:8020
    elif [ "${ENV}" = "pvs" ]
    then
        export HBASE_URL=cilhbnmv0101.sys.cigna.com:8020
    elif [ "${ENV}" = "prod" ] || [ "${ENV}" = "PRD" ]
    then
        export HBASE_URL=cilhbnmp1003.sys.cigna.com:8020
    else
        exit 1
    fi
}

# Logging util functions
log_debug () {
  echo "$(date) [DEBUG] : $*" >&2
}

log_info () {
  echo "$(date) [INFO]  : $*" >&2
}

log_warn () {
  echo "$(date) [WARN]  : $*" >&2
}

log_error () {
  echo "$(date) [ERROR] : $*" >&2
}

log_fatal () {
  echo "$(date) [FATAL] : $*" >&2
}

# metrics reporting
TIMESTAMP=$(date +%s)
export TIMESTAMP
export GRAPHITE_HOST=10.37.166.81
export GRAPHITE_PORT=8125
export METRIC_MARK=1

send_success_metric() {
    GRAPHITE_COMMAND=$(echo "${NAMESPACE} ${METRIC_MARK} ${TIMESTAMP}" | nc ${GRAPHITE_HOST} ${GRAPHITE_PORT})

    if ${GRAPHITE_COMMAND}; then
        log_info "Metric successful"
    else
        log_error "Metric failed"
        exit 1
   fi
}