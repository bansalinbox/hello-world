#!/usr/bin/env bash
# shellcheck disable=SC1090
## check for the db space name in prod

testenv=""
case $1 in
  int )
    export ENVIRONMENT=$1
    export FINAL_FILE_PATH_EXTENSION="test"
    if [ "$2" == "test" ]
    then testenv="-test"
    else testenv=""
    fi
    ;;
  pvs )
    export ENVIRONMENT=$1
    ;;
  prod )
    export FINAL_FILE_PATH_EXTENSION="csv"
    export ENVIRONMENT=$1
    ;;
  * )
    echo "Invalid Environment"
    exit 1
    ;;
esac

echo "Script is running in ${ENVIRONMENT} ${testenv} environment at $(date "+%Y.%m.%d-%H.%M.%S")"
export PROJECT_NAME=cmt-data-esp-scripts
export ELIGIBILITY_HOME="/opt/app/cis/${PROJECT_NAME}/eligibility"
export APP_HOME="${ELIGIBILITY_HOME}/${ENVIRONMENT}"
export CMT_ECLIGIBILITY_HQL="${APP_HOME}/hql/cmt-eligibility-query${testenv}.hql"
export OUTPUT_PATH="${ELIGIBILITY_HOME}/output"
currentTime=$(date "+%Y%m%d")
export FINAL_FILE_PATH="${OUTPUT_PATH}/CMT_Eligibility_${currentTime}.${FINAL_FILE_PATH_EXTENSION}"
export FILE_NAME="CMT_Eligibility_local_${currentTime}.${FINAL_FILE_PATH_EXTENSION}"
export FILE_FULL_PATH="${OUTPUT_PATH}/${FILE_NAME}"
export SCHEMA_PATH="${OUTPUT_PATH}/eligibility-schema.csv"
export NAMESPACE="spark.${ENVIRONMENT}.cmt-eligibility.Success.count"

source "${APP_HOME}/env.conf"
source "${ELIGIBILITY_HOME}/scripts/common.sh"

# Needs to be after env.conf because $LAN_ID is in there
export KRB5CCNAME="/tmp/${LAN_ID}"

main () {
  if remove_eligibility_from_local
    then
      log_info "Clean up output dir remove_eligibility_from_local"
    else
      log_error "Error in Clean up output dir remove_eligibility_from_local"
  fi

  setup_env
  check_or_create_hdfs_dir

  log_info "Beginning Hive load"
  if  beeline /etc/hive/beeline.properties \
      --hiveconf hive.session.id=CmtEligibility \
      --hiveconf mapred.job.queue.name=g_hadoop_d_clin_dev \
      --hiveconf mapreduce.map.java.opts=-Xmx4096m \
      --hiveconf mapreduce.reduce.java.opts=-Xmx4096m \
      --hiveconf mapreduce.map.memory.mb=64000 \
      --hiveconf mapreduce.reduce.memory.mb=64000 \
      --hiveconf spark.executor.cores=5 \
      --hiveconf spark.executor.memory=20114267176 \
      --nullemptystring=true \
      --showHeader=true \
      --outputformat=csv2 \
      --verbose=false \
      --hivevar "HDFS_ELIG_PATH=${HDFS_ELIG_PATH}" \
      --hivevar "CCW_CUST_TBL=${CCW_CUST_TBL}" \
      -u "${BEELINE_JDBC}" \
      -f "${CMT_ECLIGIBILITY_HQL}"
    then
      log_info "Completed Hive load"
      if copy_to_local_and_merge
        then
        log_info "complete copy_to_local_and_merge"
        if copy_to_remote_server
          then
          log_info "complete copy_to_remote_server"
            if remove_eligibility_from_local
              then
              log_info "complete remove_eligibility_from_local"
              send_success_metric
              else
              log_error "Error in remove_eligibility_from_local"
            fi
          else
            log_error "Error in copy_to_remote_server"
        fi
        else
        log_error "Error in copy_to_local_and_merge"
      fi
    else
      log_error "Hive Load Error"
      exit 1
  fi
}

main
