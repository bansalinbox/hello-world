#!/bin/ksh

cd /rtde_ibor/CMT

# email failed notification to. Separate add'l recipients with comma
if [[ $(hostname) == *"cilrtdmp0001"* ]]
then 
   RECP1=ClinicalIntegrationServicesL3Support@Cigna.com
else
    RECP1=matthew.ping@cigna.com,artsrun.gasparyan@cigna.com,gourav.bansal@cigna.com
fi

# Grabbing the file
echo Moving from /rtde/sftp-cmt/CMT_Eligibility_\* to $(pwd)/CMT_Eligibility_\* 
mv /rtde/sftp-cmt/CMT_Eligibility_* .

export CURR_FILE=$(ls -t | egrep 'CMT_Eligibility_([0-9]{8}).csv' | head -1)

# ****** Source path *************************
SPTH1=/rtde_ibor/CMT
# ****** Source filenames ********************
SF1=$CURR_FILE
# ****** Destination paths ********************
DPTH1=/mailbox/X5C1000/Outbox
# ****** Destination filenames ****************
DF1=cig_collmedtech__x5c0001o.62086.$CURR_FILE
# ****** Archive Directory ********************
ARCPTH1=/rtde_ibor/CMT/archive
# **** PROCN is the process name
# *** change the value of PROCN for each new script...use 8 or less characters
PROCN=CVSECHCO
#
#
# The following ENV vars are required to invoke C:D
#  Actual C:D script starts here
PATH=$PATH:/cdunix/ndm/bin
DATE=`date +'%m%d%y%H%M%S'`
NDMAPICFG=/cdunix/ndm/cfg/cliapi/ndmapi.cfg
export PATH NDMAPICFG

echo Copying $SPTH1/$SF1 to $DPTH1/$DF1
echo Archiving to $ARCPTH1/$SF1.$DATE
echo PROCN - cdstats_$PROCN

PATH=$PATH:/cdunix/ndm/bin
DATE=`date +'%m%d%y%H%M%S'`
NDMAPICFG=/cdunix/ndm/cfg/cliapi/ndmapi.cfg
export PATH NDMAPICFG
 
PROCN=CVSECHCO
cond_code=0
set -v
/cdunix/ndm/bin/ndmcli  -x << EOJ > cdstats_$PROCN
submit maxdelay=unlimited
$PROCN  process    snode=CIGB2BPRD
step01  copy from (file=$SPTH1/$SF1
/*                   sysopts=":datatype=binary:"  */
                   pnode
                   disp=shr)
                   to (file=$DPTH1/$DF1
/*                   sysopts=":datatype=binary:"    */
                   snode
                   disp=rpl)
        if (step01 = 0) then
            step1del run task pnode
            sysopts="mv $SPTH1/$SF1 $ARCPTH1/$SF1.$DATE"
         eif
pend;
EOJ
cond_code=$?
echo "C:D cond code="$cond_code
echo "C:D cond code="$cond_code
#
#The EOJ line is the end of the C:D script
#
# get C:D stats
#
pnum=`awk '/Submitted/ { print $6 }' cdstats_$PROCN`
if [ "$pnum" == ""  ]
then
pnum=`grep 'Process Number' cdstats_$PROCN| cut -d= -f2| tr ":" " "`
fi
/cdunix/ndm/bin/ndmcli -x > cdstats_$PROCN << EOJ2
sel stat startt=(today) detail=yes recids=(CTRC,RTED) pnum=$pnum ;
EOJ2
#
# email only if failed
#
if [ "$cond_code" != "0" ]; then
/bin/mailx -s ' '$PROCN' failed -- C:D process# '$pnum' ' $RECP1 < cdstats_$PROCN
   fi
echo $cond_code
# comment out the next line if you want to keep the stats output
# rm -f cdstats_$PROCN
exit cond_code
