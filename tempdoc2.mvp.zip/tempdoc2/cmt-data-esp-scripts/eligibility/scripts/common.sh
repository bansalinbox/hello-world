#!/usr/bin/env bash

# Logging util functions
log_debug () {
  echo "$(date) [DEBUG] : $*" >&2
}

log_info () {
  echo "$(date) [INFO]  : $*" >&2
}

log_warn () {
  echo "$(date) [WARN]  : $*" >&2
}

log_error () {
  echo "$(date) [ERROR] : $*" >&2
}

log_fatal () {
  echo "$(date) [FATAL] : $*" >&2
}

setup_env() {
    log_info "Setting Environment: ${ENVIRONMENT}"
    KINIT_COMMAND=${KERBORES_CMD}

    log_info "kinit like: ${KINIT_COMMAND}"
    $KINIT_COMMAND
    if $KINIT_COMMAND; then
        log_info "kinit successful"
    else
        log_error "kinit failed"
        exit 1
    fi
}

copy_to_local_and_merge(){
  MERGE="hdfs dfs -getmerge ${HDFS_ELIG_PATH} ${FILE_FULL_PATH}"
  log_info "MERGE like: ${MERGE}"
  $MERGE
  if $MERGE; then
      log_info "MERGE successful"
  else
      log_error "MERGE failed"
      exit 1
  fi
  insert_header="cp ${SCHEMA_PATH} ${FINAL_FILE_PATH}"
  $insert_header
  if $insert_header; then
      log_info "insert_header successful"
      final_merge=$(cat "${FILE_FULL_PATH}" >> "${FINAL_FILE_PATH}")
      if $final_merge; then
        log_info "final_merge successful"
      else
        log_error "final_merge failed"
        exit 1
      fi
  else
      log_error "insert_header failed"
      exit 1
  fi
}

copy_to_remote_server(){
  SCP="scp ${FINAL_FILE_PATH} ${SFTP_LOC}"
  log_info "SCP like: ${SCP}"
  $SCP
  if $SCP; then
      log_info "SCP successful"
  else
      log_error "SCP failed"
      exit 1
  fi
}

remove_eligibility_from_local(){
  remove="rm -f ${OUTPUT_PATH}/CMT*"
  log_info "Remove like: ${remove}"
  $remove
  if $remove; then
      log_info "Remove successful"
  else
      log_error "Remove failed"
      exit 1
  fi
}

check_or_create_hdfs_dir(){
  hdfs_dir_test=$( hdfs dfs -test -d "${HDFS_ELIG_PATH}" )
  hdfs_dir=$?
  echo "${hdfs_dir_test}"
  echo ${hdfs_dir}
  if [ "${hdfs_dir}" = "0" ]
  then
    log_info "DIRECTORY ${HDFS_ELIG_PATH} already exists"
  else
    log_info "Going to create dir ${HDFS_ELIG_PATH}"
    output=$( hdfs dfs -mkdir "${HDFS_ELIG_PATH}" )
    lod_resp=$?
    echo "lod_resp : ${lod_resp}"
    echo "${output}"
  fi
  hdfs_dir_test2=$( hdfs dfs -test -d "${HDFS_ELIG_PATH}" )
  hdfs_dir2=$?
  if [ "${hdfs_dir2}" = "0" ]
  then
    log_info "Going to change the permission"
    hdfs_dir_permission=$( hdfs dfs -chmod 777 "${HDFS_ELIG_PATH}" )
    hdfs_dir_per=$?
    echo "${hdfs_dir_permission}"
    if [ "${hdfs_dir_per}" = "0" ]
    then
      log_info "Permission changes sucessfully"
    else
      log_error "hdfs_dir_permission failed"
      exit 1
    fi
  else
  log_error "check_or_create_hdfs_dir failed to create dir ${hdfs_dir2} ${hdfs_dir_test2}"
  exit 1
  fi
}

# metrics reporting
TIMESTAMP=$(date +%s)
export TIMESTAMP
export GRAPHITE_HOST=10.37.166.81
export GRAPHITE_PORT=8125
export METRIC_MARK=1
send_success_metric() {
    GRAPHITE_COMMAND=$(echo "${NAMESPACE} ${METRIC_MARK} ${TIMESTAMP}" | nc ${GRAPHITE_HOST} ${GRAPHITE_PORT})

    if ${GRAPHITE_COMMAND}; then
        log_info "Metric successful"
    else
        log_error "Metric failed"
        exit 1
   fi
}
