package com.cigna.fhir.httpserver.config;

import com.cigna.fhir.httpserver.exception.RequiredParameterException;
import com.cigna.fhir.httpserver.util.DatabaseUtil;
import org.apache.log4j.Logger;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class Config {

    final static Logger logger= Logger.getLogger(DatabaseUtil.class);

    public void loadPropertiesAndPrint(String configPath) throws IOException, RequiredParameterException {
        Properties prop = null;
        try (InputStream input = new FileInputStream(configPath)) {
            prop = new Properties();
            prop.load(input);
        }

        HBaseConfig.setHBaseConfigMap(setHbaseConfig(prop));
        Map<String, String> loadedProp = HBaseConfig.getHBaseConfigMap();
        for( Map.Entry<String, String> entry : loadedProp.entrySet()){
            logger.info("key : " + entry.getKey() + " Value : " + entry.getValue());
        }
    }

    public void loadSecretProperties(String configPath) throws IOException, RequiredParameterException {
        Properties prop = null;
        try (InputStream input = new FileInputStream(configPath)) {
            prop = new Properties();
            prop.load(input);
        }
        IBORSecrets.setIborSecretsMap(setIBORSecretsConfig(prop));
    }

    public String getRequiredProp(Properties prop, String key) throws RequiredParameterException {
        String value = "";
        key = key.trim();
        if(key != null && !"".equals(key)){
            value = prop.getProperty(key);
            if(value == null || "".equals(value)){
                String msg = key + " has no value";
                throw new RequiredParameterException(msg);
            }
        }else{
            String err = "Key Can not be null or empty";
            throw new RequiredParameterException(err);
        }
        return value;
    }

    private Map<String, String> setIBORSecretsConfig(Properties prop) throws RequiredParameterException {
        Map<String, String> config = new HashMap<String, String>();
        config.put(IBORSecrets.IBOR_USER_ID, getRequiredProp(prop, IBORSecrets.IBOR_USER_ID));
        config.put(IBORSecrets.IBOR_PASSWORD,  getRequiredProp(prop, IBORSecrets.IBOR_PASSWORD));
        return config;
    }

    private Map<String, String> setHbaseConfig(Properties prop) throws RequiredParameterException {
        Map<String, String> config = new HashMap<String, String>();
        config.put(HBaseConfig.KEYTAB_PATH, getRequiredProp(prop,HBaseConfig.KEYTAB_PATH));
        config.put(HBaseConfig.KRB_CONFIG_PATH,  getRequiredProp(prop,HBaseConfig.KRB_CONFIG_PATH));
        config.put(HBaseConfig.PRINCIPAL, getRequiredProp(prop,HBaseConfig.PRINCIPAL));
        config.put(HBaseConfig.CORE_SITE_PATH, getRequiredProp(prop,HBaseConfig.CORE_SITE_PATH));
        config.put(HBaseConfig.HBASE_SITE_PATH,  getRequiredProp(prop,HBaseConfig.HBASE_SITE_PATH));
        config.put(HBaseConfig.HDFS_SITE_PATH, getRequiredProp(prop,HBaseConfig.HDFS_SITE_PATH));
        config.put(HBaseConfig.KRB_DEBUG, getRequiredProp(prop,HBaseConfig.KRB_DEBUG));
        config.put(HBaseConfig.RESOURCE_HBASE_TABLE_NAME, getRequiredProp(prop,HBaseConfig.RESOURCE_HBASE_TABLE_NAME));
        config.put(HBaseConfig.RESOURCE_HBASE_FAMILY, getRequiredProp(prop,HBaseConfig.RESOURCE_HBASE_FAMILY));
        config.put(HBaseConfig.ENC_HABSE_COLUMN_NAME, getRequiredProp(prop,HBaseConfig.ENC_HABSE_COLUMN_NAME));
        config.put(HBaseConfig.JWKS_URL, getRequiredProp(prop,HBaseConfig.JWKS_URL));
        config.put(HBaseConfig.OATH_ISS, getRequiredProp(prop,HBaseConfig.OATH_ISS));
        config.put(HBaseConfig.ENC_POST_SCOPE, getRequiredProp(prop,HBaseConfig.ENC_POST_SCOPE));
        config.put(HBaseConfig.ENC_GET_SCOPE, getRequiredProp(prop,HBaseConfig.ENC_GET_SCOPE));
        config.put(HBaseConfig.SECRET_PATH, getRequiredProp(prop,HBaseConfig.SECRET_PATH));
        config.put(HBaseConfig.RETRIEVED_IND_URL, getRequiredProp(prop,HBaseConfig.RETRIEVED_IND_URL));
        return config;
    }
}
