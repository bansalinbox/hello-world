package com.cigna.fhir.httpserver.service;

import io.micronaut.http.HttpResponse;
import io.micronaut.http.MediaType;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;
import io.micronaut.http.annotation.Produces;

@Controller("/healthcheck")
public class HealthCheckController {
    @Get("/")
    @Produces(MediaType.APPLICATION_JSON)
    public HttpResponse index()  {
        return HttpResponse.ok();
    }
}
