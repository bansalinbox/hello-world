package com.cigna.fhir.httpserver.exception;

public class RequiredParameterException extends Exception {
    public RequiredParameterException() {
        super();
    }

    public RequiredParameterException(String message) {
        super(message);
    }

    public RequiredParameterException(String message, Throwable cause) {
        super(message, cause);
    }

    public RequiredParameterException(Throwable cause) {
        super(cause);
    }
}
