package com.cigna.fhir.httpserver.util;

import com.cigna.fhir.httpserver.config.HBaseConfig;
import com.cigna.fhir.httpserver.exception.HBaseConnectionException;
import com.cigna.fhir.httpserver.exception.HBaseDataException;
import com.cigna.fhir.httpserver.service.Application;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.Map;

public class DatabaseUtil {

    final static Logger logger = Logger.getLogger(HBaseConnection.class);

    private static Map<String, String> hbaseConfig = HBaseConfig.getHBaseConfigMap();
    private static String familyName = hbaseConfig.get(HBaseConfig.RESOURCE_HBASE_FAMILY);
    private static String encounterHBaseColumnName = hbaseConfig.get(HBaseConfig.ENC_HABSE_COLUMN_NAME);

    public void createTable(String tableStringName) throws IOException, HBaseConnectionException {
        Admin admin = HBaseConnection.getConnection(Application.configuration).getAdmin();
        byte[] family = Bytes.toBytes(DatabaseUtil.familyName);

        String namespaceName = tableStringName.split(":")[0];
        System.out.println("Namespace: " + namespaceName);

        TableName tableName = TableName.valueOf(tableStringName);
        TableDescriptor desc = TableDescriptorBuilder.newBuilder(tableName)
                .setColumnFamily(ColumnFamilyDescriptorBuilder.of(family))
                .build();
        admin.createTable(desc);
    }

    public void deleteTable(String tableStringName) throws IOException, HBaseConnectionException {
        Admin admin = HBaseConnection.getConnection(Application.configuration).getAdmin();
        TableName tableName = TableName.valueOf(tableStringName);
        admin.disableTable(tableName);
        admin.deleteTable(tableName);
    }

    public void writeToTable(String rowId, byte[] correlationId,  byte[] data, byte[] cohort, byte[] user) throws HBaseDataException, HBaseConnectionException {
        Table table = null;
        Connection connection = HBaseConnection.getConnection(Application.configuration);
        try {
            table = connection.getTable(TableName.valueOf(hbaseConfig.get(HBaseConfig.RESOURCE_HBASE_TABLE_NAME)));
            byte[] family = Bytes.toBytes(DatabaseUtil.familyName);
            byte[] column = Bytes.toBytes(DatabaseUtil.encounterHBaseColumnName);
            byte[] cohortColumn = Bytes.toBytes("cohort");
            byte[] userColumn = Bytes.toBytes("user");
            byte[] correlationColumn = Bytes.toBytes("correlationId");
            byte[] val = data;
            Put p = new Put(Bytes.toBytes(rowId));
            p.addColumn(family, column, val);
            p.addColumn(family, cohortColumn, cohort);
            p.addColumn(family, userColumn, user);
            p.addColumn(family, correlationColumn, correlationId);
            table.put(p);
        } catch (IOException e) {
            logger.error(Utility.getStackMsg(e));
            String err = "Exception happened while writing to the table for the rowId : " + rowId;
            throw new HBaseDataException(err, e);
        } finally {
            try {
                if (table != null) {
                    table.close();
                }
            } catch (IOException e) {
                logger.error(Utility.getStackMsg(e));
                String err = "Exception happened while closing the table configuration in writingToTable for the rowID : " + rowId;
                throw new HBaseDataException(err, e);
            }
        }

    }

    public byte[] readFromTable(String rowId) throws HBaseDataException, HBaseConnectionException {
        Table table = null;
        byte[] value = null;
        Connection connection = HBaseConnection.getConnection(Application.configuration);
        try {
            table = connection.getTable(TableName.valueOf(hbaseConfig.get(HBaseConfig.RESOURCE_HBASE_TABLE_NAME)));
            byte[] family = Bytes.toBytes(DatabaseUtil.familyName);
            byte[] column = Bytes.toBytes(DatabaseUtil.encounterHBaseColumnName);

            Get g = new Get(Bytes.toBytes(rowId));
            Result result = table.get(g);
            value = result.getValue(family, column);

        } catch (IOException e) {
            logger.error(Utility.getStackMsg(e));
            String err = "Exception happened in readFromTable for the rowID : " + rowId;
            throw new HBaseDataException(err, e);
        } finally {
            try {
                if (table != null) {
                    table.close();
                }
            } catch (IOException e) {
                logger.error(Utility.getStackMsg(e));
                String err = "Exception happened while closing the table configuration in readFromTable for the rowID : " + rowId;
                throw new HBaseDataException(err, e);
            }
        }
        return value;
    }
}
