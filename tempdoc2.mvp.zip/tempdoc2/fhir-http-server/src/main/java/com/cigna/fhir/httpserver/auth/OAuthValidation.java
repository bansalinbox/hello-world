package com.cigna.fhir.httpserver.auth;

import com.auth0.jwk.Jwk;
import com.auth0.jwk.JwkException;
import com.auth0.jwk.JwkProvider;
import com.auth0.jwk.UrlJwkProvider;
import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.cigna.fhir.httpserver.config.HBaseConfig;
import com.cigna.fhir.httpserver.exception.OAuthException;
import com.cigna.fhir.httpserver.util.DatabaseUtil;
import io.micronaut.http.HttpResponse;
import org.apache.log4j.Logger;

import java.net.MalformedURLException;
import java.net.URL;
import java.security.interfaces.RSAPublicKey;
import java.util.Map;

import static com.cigna.fhir.httpserver.service.Application.CONFIG;

public class OAuthValidation {

    final static Logger logger= Logger.getLogger(OAuthValidation.class);

    public static void validateBearerToken(String bearerToken, String validScope) throws OAuthException {

        Map<String, String> config = HBaseConfig.getHBaseConfigMap();

        logger.info("Validating token using - " + config.get(HBaseConfig.JWKS_URL));

        try {
            JwkProvider jwkStore = new UrlJwkProvider(new URL(config.get(HBaseConfig.JWKS_URL)));

            // Only accept Bearer tokens
            if (bearerToken.contains("Bearer")) {
                String token = bearerToken.replace("Bearer ", "");
                DecodedJWT decodedJWT = JWT.decode(token);

                // Verify the JWT Token
                Jwk jwk = jwkStore.get(decodedJWT.getKeyId());
                Algorithm algorithm = Algorithm.RSA256((RSAPublicKey) jwk.getPublicKey(), null);
                JWTVerifier verifier = JWT.require(algorithm)
                    .withIssuer(config.get(HBaseConfig.OATH_ISS))
                    .build();
                DecodedJWT jwt = verifier.verify(token);

                // Validate the scope claims are correct
                if (!jwt.getClaim("scope").asString().contains(validScope)) {
                    String err = validScope + " is not a valid OAuth Scope for this method";
                    throw new OAuthException(err);
                }
            }
            else {
                String err = "Not a valid format for OAuth token: " + bearerToken;
                throw new OAuthException(err);
            }
        } catch (MalformedURLException badURLex) {
            String err = "ERROR with Cognito URL " + badURLex.toString();
            throw new OAuthException(err, badURLex);
        } catch (JwkException jwkex) {
            String err = "Exception happened while getting the JWk key ID : " + jwkex.toString();
            throw new OAuthException(err, jwkex);
        } catch (JWTVerificationException verifex){
            String err = "Exception happened while verifying the JWT Token : " + verifex.toString();
            throw new OAuthException(err, verifex);
        }
    }
}
