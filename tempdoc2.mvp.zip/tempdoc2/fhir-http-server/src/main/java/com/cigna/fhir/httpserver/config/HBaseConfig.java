package com.cigna.fhir.httpserver.config;

import java.util.Map;

public class HBaseConfig {

    public static final String KEYTAB_PATH = "keytabPath";

    public static final String KRB_CONFIG_PATH = "krb5configPath";

    public static final String PRINCIPAL = "principal";

    public static final String CORE_SITE_PATH= "coreSitePath";

    public static final String HBASE_SITE_PATH= "hbaseSitePath";

    public static final String HDFS_SITE_PATH= "hdfsSitePath";

    public static final String KRB_DEBUG= "krbDebug";

    public static final String RESOURCE_HBASE_TABLE_NAME= "resourcesHBaseTableName";

    public static final String RESOURCE_HBASE_FAMILY= "resourcesHBaseFamily";

    public static final String ENC_HABSE_COLUMN_NAME= "encounterHBaseColumnName";

    public static final String JWKS_URL= "jwksURL";

    public static final String OATH_ISS= "oauthISS";

    public static final String ENC_POST_SCOPE= "encounterPostScope";

    public static final String ENC_GET_SCOPE= "encounterGetScope";

    public static final String SECRET_PATH = "secretsPath";

    public static final String RETRIEVED_IND_URL = "retrieveIndividualsURL";


    private static Map<String, String> hbaseConfigMap;

    public static Map<String, String> getHBaseConfigMap() {
        return hbaseConfigMap;
    }

    public static void setHBaseConfigMap(Map<String, String> HBaseConfigMap) {
        hbaseConfigMap = HBaseConfigMap;
    }

}
