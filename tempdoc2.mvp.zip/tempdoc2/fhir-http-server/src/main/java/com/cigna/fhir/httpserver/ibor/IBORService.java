package com.cigna.fhir.httpserver.ibor;

import com.cigna.cis.dragonops.fhir.cmt.encounter.v1_2.CMTPayloadEncounter;
import com.cigna.fhir.httpserver.exception.IBORServiceException;
import org.apache.log4j.Logger;

import java.util.ArrayList;

public class IBORService {

    final static Logger logger= Logger.getLogger(IBORService.class);

    public CMTPayloadEncounter getGroupNoByEid(CMTPayloadEncounter enc) throws IBORServiceException {
        String eID = null;
        eID = enc.getEID().toString();
        logger.info("Fetching group no for eid : " + eID);
        ArrayList groupNos = retrieveIndividual(eID);
        int groupNoSize = groupNos.size();
        if(groupNoSize == 0){
            logger.warn("No group number retrieved for eid : " + eID);
        }
        for(int i =0; i < groupNoSize; i++){
            if(i == 0){
                enc.setAccountNo(groupNos.get(i).toString());
            }else if(i == 1){
                enc.setAccountNoDual(groupNos.get(i).toString());
            }
        }

        return enc;
    }

    /**
     * Fetch
     * @param eID
     * @return
     * @throws IBORServiceException
     */
    public ArrayList retrieveIndividual(String eID) throws IBORServiceException {
        ArrayList groupNos;
        XMLRequest request = new XMLRequest();
        groupNos = request.makeXMLRequest(eID);
        return groupNos;
    }
}
