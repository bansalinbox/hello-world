package com.cigna.fhir.httpserver.service;

import com.cigna.fhir.httpserver.config.Config;
import com.cigna.fhir.httpserver.exception.KerberosLoginException;
import com.cigna.fhir.httpserver.exception.RequiredParameterException;
import com.cigna.fhir.httpserver.util.KerberosLogin;
import io.micronaut.runtime.Micronaut;

import org.apache.hadoop.conf.Configuration;
import java.io.IOException;

public class Application {

    public static Configuration configuration;
    public static final String SECRETS_PATH = "secrets/ibor.secret";
    public static final String CONFIG_PATH = "./config/config.properties";
    public static final Config CONFIG = new Config();

    public static void main(String[] args) throws RequiredParameterException, IOException, KerberosLoginException {
        CONFIG.loadPropertiesAndPrint(CONFIG_PATH);
        CONFIG.loadSecretProperties(SECRETS_PATH);
        Application.configuration = KerberosLogin.login();
        Micronaut.run(Application.class);
    }
}
