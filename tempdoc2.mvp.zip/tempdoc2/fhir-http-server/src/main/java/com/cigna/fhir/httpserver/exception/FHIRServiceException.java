package com.cigna.fhir.httpserver.exception;

/**
 * This is the custom exception raised in FHIR service
 */
public class FHIRServiceException extends Exception{
    public FHIRServiceException() {
        super();
    }

    public FHIRServiceException(String message) {
        super(message);
    }

    public FHIRServiceException(String message, Throwable cause) {
        super(message, cause);
    }

    public FHIRServiceException(Throwable cause) {
        super(cause);
    }
}
