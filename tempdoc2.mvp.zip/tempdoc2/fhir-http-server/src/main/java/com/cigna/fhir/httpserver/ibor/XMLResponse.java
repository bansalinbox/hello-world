package com.cigna.fhir.httpserver.ibor;


import com.cigna.fhir.httpserver.config.HBaseConfig;
import com.cigna.fhir.httpserver.config.IBORSecrets;
import com.cigna.fhir.httpserver.exception.IBORServiceException;
import com.cigna.fhir.httpserver.util.Utility;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import javax.net.ssl.HttpsURLConnection;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.Collections;
import java.util.Map;
import java.util.ArrayList;
import java.util.Arrays;


public class XMLResponse {

    public ArrayList xmlSOAPRequest(Document xmlRequest) throws IBORServiceException {
        Map<String, String> hbaseConfig = HBaseConfig.getHBaseConfigMap();
        Map<String, String> iborConfig = IBORSecrets.getIborSecretsMap();
        ArrayList<String> groupNos;
        String url = hbaseConfig.get(HBaseConfig.RETRIEVED_IND_URL);
        URL obj = null;
        try {
            obj = new URL(url);
        } catch (MalformedURLException e) {
            e.printStackTrace();
            String errMSg = "Exception happened while setting the url for the xmlSOAPRequest";
            throw new IBORServiceException(errMSg, Utility.fhir_code.IBOR_SERVICE_ERROR, e);
        }
        HttpsURLConnection con = null;
        try {
            con = (HttpsURLConnection) obj.openConnection();
        } catch (IOException e) {
            String errMSg = "Exception happened while open the connection for the xmlSOAPRequest";
            throw new IBORServiceException(errMSg, Utility.fhir_code.IBOR_SERVICE_ERROR, e);
        }
        try {
            con.setRequestMethod("POST");
        } catch (ProtocolException e) {
            String errMSg = "Exception happened while setting the proctocol for the xmlSOAPRequest";
            throw new IBORServiceException(errMSg, Utility.fhir_code.IBOR_SERVICE_ERROR, e);
        }

        con.setRequestProperty("Content-Type", "application/xml; charset=utf-8");
        String xml = getStringFromDocument(xmlRequest);
        con.setDoOutput(true);
        DataOutputStream wr = null;
        String responseStatus = null;
        try {
            wr = new DataOutputStream(con.getOutputStream());
            wr.writeBytes(xml);
            wr.flush();
            wr.close();
            responseStatus = con.getResponseMessage();
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            String responseMessage = response.toString();
            groupNos = getGroupNos(responseMessage);
        } catch (IOException e) {
            String errMSg = "Exception happened while reading the response from for the xmlSOAPRequest";
            throw new IBORServiceException(errMSg, Utility.fhir_code.IBOR_SERVICE_ERROR, e);
        }
        return groupNos;
    }


    public ArrayList getGroupNos(String responseMessage) throws IBORServiceException {
        DocumentBuilder dbFactory = null;
        ArrayList<String> groupNoArray = new ArrayList<>();
        try {
            dbFactory = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            String errMSg = "Exception happened while getting the group no for the xmlSOAPRequest";
            throw new IBORServiceException(errMSg, Utility.fhir_code.IBOR_SERVICE_ERROR, e);
        }
        InputSource is = new InputSource();
        is.setCharacterStream(new StringReader(responseMessage));
        Document doc = null;
        try {
            doc = dbFactory.parse(is);
        } catch (SAXException e) {
            String errMSg = "Exception happened while parsing the response for group no of the xmlSOAPRequest";
            throw new IBORServiceException(errMSg, Utility.fhir_code.IBOR_DATA_ERROR, e);
        } catch (IOException e) {
            String errMSg = "Exception happened while parsing the response for group no of the xmlSOAPRequest";
            throw new IBORServiceException(errMSg, Utility.fhir_code.IBOR_DATA_ERROR, e);
        }
        NodeList nList = doc.getElementsByTagName("ns3:memberOccurrence");

        for (int i = 0; i < nList.getLength(); i++) {

            Node nNode = nList.item(i);

            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                Element eElement = (Element) nNode;
                if (eElement.getElementsByTagName("ns4:groupNumber").getLength() > 0) {
                    String groupNo = eElement.getElementsByTagName("ns4:groupNumber").item(0).getTextContent();
                    groupNoArray.add(groupNo);
                }
            }
        }
        Collections.sort(groupNoArray);
        return groupNoArray;
    }

    private String getStringFromDocument(Document doc) throws IBORServiceException {
        DOMSource domSource = new DOMSource(doc);
        StringWriter writer = new StringWriter();
        StreamResult result = new StreamResult(writer);
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer transformer = null;
        try {
            transformer = tf.newTransformer();
        } catch (TransformerConfigurationException e) {
            String errMSg = "Exception happened while transforming the documents for the xmlSOAPRequest";
            throw new IBORServiceException(errMSg, Utility.fhir_code.IBOR_SERVICE_ERROR, e);
        }
        try {
            transformer.transform(domSource, result);
        } catch (TransformerException e) {
            String errMSg = "Exception happened while transforming the dom source for the xmlSOAPRequest";
            throw new IBORServiceException(errMSg, Utility.fhir_code.IBOR_SERVICE_ERROR, e);
        }
        return writer.toString();
    }
}