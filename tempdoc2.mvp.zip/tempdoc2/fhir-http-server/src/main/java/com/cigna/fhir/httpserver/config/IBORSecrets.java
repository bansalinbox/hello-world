package com.cigna.fhir.httpserver.config;

import java.util.Map;

public class IBORSecrets {

    public static final String IBOR_USER_ID = "userid";

    public static final String IBOR_PASSWORD = "password";

    private static Map<String, String> iborSecretsMap;

    public static Map<String, String> getIborSecretsMap() {
        return iborSecretsMap;
    }

    public static void setIborSecretsMap(Map<String, String> iborSecretsMap) {
        IBORSecrets.iborSecretsMap = iborSecretsMap;
    }
}
