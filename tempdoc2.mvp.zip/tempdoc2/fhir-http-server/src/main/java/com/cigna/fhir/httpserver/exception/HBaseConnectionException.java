package com.cigna.fhir.httpserver.exception;

public class HBaseConnectionException extends Exception {
    public HBaseConnectionException() {
        super();
    }

    public HBaseConnectionException(String message) {
        super(message);
    }

    public HBaseConnectionException(String message, Throwable cause) {
        super(message, cause);
    }

    public HBaseConnectionException(Throwable cause) {
        super(cause);
    }
}