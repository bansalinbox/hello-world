package com.cigna.fhir.httpserver.util;

import com.cigna.fhir.httpserver.config.HBaseConfig;
import com.cigna.fhir.httpserver.exception.KerberosLoginException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.security.UserGroupInformation;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Map;

public class KerberosLogin {
    static Map<String, String> hbaseConfig = HBaseConfig.getHBaseConfigMap();

    public static Configuration login() throws KerberosLoginException {
        final String kerberos = "kerberos";
        String principal = hbaseConfig.get(HBaseConfig.PRINCIPAL);
        String keytabLocation = hbaseConfig.get(HBaseConfig.KEYTAB_PATH);
        System.setProperty("java.security.krb5.conf", hbaseConfig.get(HBaseConfig.KRB_CONFIG_PATH));
        System.setProperty("sun.security.krb5.debug", hbaseConfig.get(HBaseConfig.KRB_DEBUG));

        Configuration configuration = new Configuration();

        try {
            configuration.addResource(new FileInputStream(new File(hbaseConfig.get(HBaseConfig.CORE_SITE_PATH))));
            configuration.addResource(new FileInputStream(new File(hbaseConfig.get(HBaseConfig.HBASE_SITE_PATH))));
            configuration.addResource(new FileInputStream(new File(hbaseConfig.get(HBaseConfig.HDFS_SITE_PATH))));
        } catch (FileNotFoundException e) {
            String errMsg = "Exception happened reading the hbase configuration files";
            throw new KerberosLoginException(errMsg, e);
        }
        configuration.set("hadoop.security.authentication", kerberos);
        configuration.set("hbase.security.authentication", kerberos);
        configuration.set("hbase.client.keytab.file", keytabLocation);
        configuration.set("hbase.client.kerberos.principal", principal);

        UserGroupInformation.setConfiguration(configuration);
        try {
            UserGroupInformation.loginUserFromKeytab(principal, keytabLocation);
        } catch (IOException e) {
            e.printStackTrace();
            String errMsg = "Exception happened while kerberos login";
            throw new KerberosLoginException(errMsg, e);
        }

        return configuration;
    }
}
