package com.cigna.fhir.httpserver.ibor;

import com.cigna.fhir.httpserver.config.HBaseConfig;
import com.cigna.fhir.httpserver.config.IBORSecrets;
import com.cigna.fhir.httpserver.exception.IBORServiceException;
import com.cigna.fhir.httpserver.util.Utility;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.Map;


public class XMLRequest {

    final static Logger logger= Logger.getLogger(XMLRequest.class);
    static File soapRequestXML = new File("./config/SOAPRequest.xml");

    public ArrayList makeXMLRequest(String eID) throws IBORServiceException {
        logger.info("Going to build the SOAP request for the eid : " + eID);
        Document doc = buildSOAPRequest(soapRequestXML, eID);
        XMLResponse response = new XMLResponse();
        logger.info("Start to fetch group nos by SOAP request for the eid : " + eID);
        ArrayList groupNos = response.xmlSOAPRequest(doc);
        logger.info("End to fetch group nos by SOAP request for the eid : " + eID);
        return groupNos;
    }

    //TODO: read the xml once as static variable on start of the application
    public Document buildSOAPRequest(File xmlFile, String eID) throws IBORServiceException {
        Map<String, String> iborSecretsMap = IBORSecrets.getIborSecretsMap();
        Map<String, String> hbaseConfig = HBaseConfig.getHBaseConfigMap();
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = null;
        try {
            dBuilder = dbFactory.newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            String errMsg = "Exception happened in buildSOAPRequest method while creating the builder for the request ";
            throw new IBORServiceException(errMsg, Utility.fhir_code.IBOR_SERVICE_ERROR, e);
        }
        Document doc = null;
        try {
            doc = dBuilder.parse(xmlFile);
        } catch (SAXException e) {
            String errMsg = "Exception happened in buildSOAPRequest method parsing the request ";
            throw new IBORServiceException(errMsg, Utility.fhir_code.IBOR_SERVICE_ERROR, e);
        } catch (IOException e) {
            String errMsg = "Exception happened in buildSOAPRequest method while parsing the xml file of request ";
            throw new IBORServiceException(errMsg, Utility.fhir_code.IBOR_SERVICE_ERROR, e);
        }

        doc.getDocumentElement().normalize();

        NodeList nListHeader = doc.getElementsByTagName("soapenv:Header");

        for (int temp = 0; temp < nListHeader.getLength(); temp++) {

            Node nNode = nListHeader.item(temp);

            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                Element eElement = (Element) nNode;
                eElement.getElementsByTagName("wsse:Username").item(0).setTextContent(iborSecretsMap.get(IBORSecrets.IBOR_USER_ID));
                eElement.getElementsByTagName("wsse:Password").item(0).setTextContent(iborSecretsMap.get(IBORSecrets.IBOR_PASSWORD));
            }
        }
        NodeList nListBody = doc.getElementsByTagName("soapenv:Body");
        for (int temp = 0; temp < nListBody.getLength(); temp++) {

            Node nNode = nListBody.item(temp);

            if (nNode.getNodeType() == Node.ELEMENT_NODE) {

                Element eElement = (Element) nNode;
                eElement.getElementsByTagName("ns5:enterpriseId").item(0).setTextContent(eID);
            }
        }
        return doc;
    }
}