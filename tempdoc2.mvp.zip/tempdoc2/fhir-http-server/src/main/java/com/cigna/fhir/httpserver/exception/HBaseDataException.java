package com.cigna.fhir.httpserver.exception;

public class HBaseDataException extends Exception {
    public HBaseDataException() {
        super();
    }

    public HBaseDataException(String message) {
        super(message);
    }

    public HBaseDataException(String message, Throwable cause) {
        super(message, cause);
    }

    public HBaseDataException(Throwable cause) {
        super(cause);
    }
}
