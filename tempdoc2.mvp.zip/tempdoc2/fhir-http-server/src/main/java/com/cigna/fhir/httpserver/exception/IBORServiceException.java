package com.cigna.fhir.httpserver.exception;

import com.cigna.fhir.httpserver.util.Utility;

public class IBORServiceException extends Exception {
    String errorType = null;
    public IBORServiceException() {
        super();
    }

    public IBORServiceException(String message) {
        super(message);
    }

    public IBORServiceException(String message, Throwable cause) {
        super(message, cause);
    }

    public IBORServiceException(String message, Utility.fhir_code errorType, Throwable cause) {
        super(message, cause);
        this.errorType = errorType.toString();
    }

    public String getIBORErrorType(){
        return errorType;
    }

}
