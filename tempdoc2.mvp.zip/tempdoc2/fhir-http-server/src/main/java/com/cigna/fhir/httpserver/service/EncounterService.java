package com.cigna.fhir.httpserver.service;

import com.cigna.cis.dragonops.fhir.cmt.encounter.v1_2.CMTPayloadEncounter;
import com.cigna.fhir.httpserver.config.HBaseConfig;
import com.cigna.fhir.httpserver.exception.*;
import com.cigna.fhir.httpserver.ibor.IBORService;
import com.cigna.fhir.httpserver.util.DatabaseUtil;
import com.cigna.fhir.httpserver.auth.OAuthValidation;
import com.cigna.fhir.httpserver.util.Utility;
import com.fasterxml.jackson.core.JsonParseException;
import io.micronaut.core.convert.exceptions.ConversionErrorException;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.MediaType;
import io.micronaut.http.annotation.*;
import io.micronaut.http.annotation.Error;
import org.apache.log4j.Logger;
import org.apache.hadoop.hbase.util.Bytes;

import java.io.IOException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Controller("/v1/encounter")
public class EncounterService {
    final static Logger logger = Logger.getLogger(EncounterService.class);

    private DatabaseUtil repository;

    public EncounterService() {
        this.repository = new DatabaseUtil();
    }

    @Post("/")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public HttpResponse post(@Header String authorization, @Body CMTPayloadEncounter[] encArray) {
        return processPostMessage(authorization, encArray);
    }

    public HttpResponse processPostMessage(String authorization, CMTPayloadEncounter[] encArray) {
        IBORService valEnc = new IBORService();
        List<String> successRowIDs = new ArrayList<String>();
        List<String> failedRowIDs = new ArrayList<String>();

        try {
            int toalNoOfMsg = encArray.length;
            logger.debug("Post Method is called, total no of item in the request are : " + toalNoOfMsg);
            Map<String, String> hbaseConfig = HBaseConfig.getHBaseConfigMap();
            logger.info("Going to validate bearer token");

            try {
                OAuthValidation.validateBearerToken(authorization, hbaseConfig.get(HBaseConfig.ENC_POST_SCOPE));
            } catch (OAuthException e) {
                String errMsg = "Exception happened while Validating the Bearer Token";
                String errorJSON = Utility.errorResponse(Utility.fhir_code.TOKEN_VALIDATION_ERROR, 401, errMsg, successRowIDs, failedRowIDs, e);
                logger.error(errorJSON);
                return HttpResponse.unauthorized().body(errorJSON);
            }

            for (CMTPayloadEncounter enc : encArray) {
                String rowId = enc.getRowKey().toString();

                try {
                    enc = valEnc.getGroupNoByEid(enc);
                } catch (IBORServiceException e) {
                    // If the error is data error then skip that record
                    if (Utility.fhir_code.IBOR_DATA_ERROR.equals(e.getIBORErrorType())) {
                        String errMsg = "Exception happened while serialzing the data for the rowId " + rowId;
                        String errorJSON = Utility.errorResponse(Utility.fhir_code.IBOR_DATA_ERROR, 400, errMsg, successRowIDs, failedRowIDs, e);
                        failedRowIDs.add(rowId);
                        logger.error(errorJSON);
                    } else {
                        String errMsg = "Exception happened while serialzing the data for the rowId " + rowId;
                        String errorJSON = Utility.errorResponse(Utility.fhir_code.IBOR_SERVICE_ERROR, 500, errMsg, successRowIDs, failedRowIDs, e);
                        failedRowIDs.add(rowId);
                        logger.error(errorJSON);
                        return HttpResponse.serverError().body(errorJSON);
                    }
                }

                rowId = Utility.updateRowKey(enc);
                enc.setLastUpdatedDate(Instant.now().toString());
                byte[] encounterPayload = null;
                byte[] cohortPayload = Bytes.toBytes(enc.getCohort().toString());
                byte[] userPayload = Bytes.toBytes(enc.getUser().toString());
                byte[] correlationIdPayload = Bytes.toBytes(enc.getCorrelationId().toString());

                try {
                    encounterPayload = Utility.serializeEncounter(enc, CMTPayloadEncounter.getClassSchema());
                } catch (FHIRServiceException e) {
                    // Need to remove error msg from here
                    String errMsg = "Exception happened while serialzing the data for the rowId " + rowId;
                    String errorJSON = Utility.errorResponse(Utility.fhir_code.TOKEN_VALIDATION_ERROR, 400, errMsg, successRowIDs, failedRowIDs, e);
                    failedRowIDs.add(rowId);
                    logger.error(errorJSON);
                }
                try {
                    this.repository.writeToTable(rowId, correlationIdPayload, encounterPayload, cohortPayload, userPayload);
                } catch (HBaseDataException e) {
                    String errMsg = "Exception happened while save the rowID to the table : " + rowId;
                    String errorJSON = Utility.errorResponse(Utility.fhir_code.DATABASE_ERROR, 500, errMsg, successRowIDs, failedRowIDs, e);
                    failedRowIDs.add(rowId);
                    logger.error(errorJSON);
                    return HttpResponse.serverError().body(errorJSON);
                } catch (HBaseConnectionException e){
                    String errMsg = "Exception happened while obtaining connection to HBASE : " + rowId;
                    String errorJSON = Utility.errorResponse(Utility.fhir_code.HBASE_CONNECTION_ERROR, 500, errMsg, successRowIDs, failedRowIDs, e);
                    failedRowIDs.add(rowId);
                    logger.error(errorJSON);
                    return HttpResponse.serverError().body(errorJSON);
                }
                successRowIDs.add(rowId);
            }
        } catch (Exception e) {
            String errorMSG = "UNEXPECTED EXCEPTION";
            String errorJSON = Utility.errorResponse(Utility.fhir_code.UNEXPECTED_ERROR, 500, errorMSG, successRowIDs, failedRowIDs, e);
            logger.error(errorJSON);
            return HttpResponse.serverError().body(errorJSON);
        }
        return HttpResponse.ok(Utility.successResponse(200, successRowIDs, failedRowIDs));
    }

    // Catch any issues relating to mapping the payload to a CMTEncounterPayload message
    @Error
    public HttpResponse jacksonError(HttpRequest request, ConversionErrorException jsonMapException) {
        String errorJson = Utility.errorResponse(Utility.fhir_code.PAYLOAD_ERROR, 400, jsonMapException.getMessage(), jsonMapException);
        logger.error(errorJson);

        return HttpResponse.badRequest().body(errorJson);
    }

    // Catch any issues with JSON Formatting
    @Error
    public HttpResponse jsonError(HttpRequest request, JsonParseException jsonParseException) {
        String errorJson = Utility.errorResponse(Utility.fhir_code.PAYLOAD_ERROR, 400, jsonParseException.getMessage(), jsonParseException);
        logger.error(errorJson);

        return HttpResponse.badRequest().body(errorJson);
    }

    @Get("/{rowkey}")
    @Produces(MediaType.APPLICATION_JSON)
    public HttpResponse get(String rowkey, @Header String authorization) {
        try {
            logger.debug("Get Method is called");
            Map<String, String> hbaseConfig = HBaseConfig.getHBaseConfigMap();
            logger.info("Going to validate bearer token");

            try {
                OAuthValidation.validateBearerToken(authorization, hbaseConfig.get(HBaseConfig.ENC_GET_SCOPE));
            } catch (OAuthException e) {
                String errMsg = "Exception happened while Validating the Bearer Token";
                String errorJSON = Utility.errorResponse(Utility.fhir_code.TOKEN_VALIDATION_ERROR, 401, errMsg, e);
                logger.error(errorJSON);
                return HttpResponse.unauthorized().body(errorJSON);
            }

            byte[] result = this.repository.readFromTable(rowkey);

            String encounter;

            if (result != null) {
                encounter = Utility.deserializeRecord(result, CMTPayloadEncounter.getClassSchema()).next().toString();
                return HttpResponse.ok(encounter);
            } else {
                return HttpResponse.notFound("{ \"error\": \"Data not found\" }");
            }

        } catch (Exception e){
            String errorMSG = "UNEXPECTED EXCEPTION";
            String errorJSON = Utility.errorResponse(Utility.fhir_code.UNEXPECTED_ERROR, 500, errorMSG, e);
            logger.error(errorJSON);
            return HttpResponse.serverError().body(errorJSON);
        }
    }
}
