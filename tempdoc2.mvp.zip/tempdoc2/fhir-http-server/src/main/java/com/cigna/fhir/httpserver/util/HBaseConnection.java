package com.cigna.fhir.httpserver.util;

import com.cigna.fhir.httpserver.exception.HBaseConnectionException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.log4j.Logger;

import java.io.IOException;

public class HBaseConnection {
    final static Logger logger = Logger.getLogger(HBaseConnection.class);

    private static Connection connection = null;

    private static boolean isClosed() {
        return HBaseConnection.connection == null || HBaseConnection.connection.isClosed();
    }

    synchronized public static Connection getConnection(Configuration configuration) throws HBaseConnectionException {
        if (!HBaseConnection.isClosed()) {
            return HBaseConnection.connection;
        }

        Configuration hbaseConfiguration = HBaseConfiguration.create(configuration);
        try {
            HBaseConnection.connection = ConnectionFactory.createConnection(hbaseConfiguration);
        } catch (IOException e) {
            logger.error(Utility.getStackMsg(e));
            String errMsg = "Exception happened creating the configuration to the hbase";
            throw new HBaseConnectionException(errMsg, e);
        }

        return HBaseConnection.connection;
    }
}