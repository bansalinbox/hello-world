package com.cigna.fhir.httpserver.exception;

public class KerberosLoginException extends Exception {
    public KerberosLoginException() {
        super();
    }

    public KerberosLoginException(String message) {
        super(message);
    }

    public KerberosLoginException(String message, Throwable cause) {
        super(message, cause);
    }

    public KerberosLoginException(Throwable cause) {
        super(cause);
    }
}