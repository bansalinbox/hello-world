package com.cigna.fhir.httpserver.util;

import com.cigna.cis.dragonops.fhir.cmt.encounter.v1_2.CMTPayloadEncounter;
import com.cigna.fhir.httpserver.exception.FHIRServiceException;
import org.apache.avro.Schema;
import org.apache.avro.file.DataFileStream;
import org.apache.avro.file.DataFileWriter;
import org.apache.avro.generic.GenericDatumReader;
import org.apache.avro.generic.GenericDatumWriter;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.io.*;
import org.apache.avro.specific.SpecificDatumWriter;
import org.apache.avro.specific.SpecificRecordBase;
import org.json.JSONObject;

import java.io.*;
import java.util.List;

public class Utility {

    public static String errorResponse(fhir_code errorType, int status, String errMsg, List<String> success, List<String> failed, Throwable cause) {
        String errorString = new JSONObject()
                .put("status_code", status)
                .put("error_type", errorType)
                .put("error_msg", errMsg)
                .put("success_rowId", success)
                .put("failed_rowId", failed)
                .put("stack_print", getStackMsg(cause)).toString();

        return errorString;
    }

    public static String errorResponse(fhir_code errorType, int status, String errMsg, Throwable cause) {
        String errorString = new JSONObject()
                .put("status_code", status)
                .put("error_type", errorType)
                .put("error_msg", errMsg)
                .put("stack_print", getStackMsg(cause)).toString();

        return errorString;
    }

    public static String successResponse(int status, List<String> success, List<String> failed) {
        String message;
        String successString = new JSONObject().put("status_code", status).put("success_rowId", success).put("failed_rowId", failed).toString();

        return successString;
    }

    public static String getStackMsg(Throwable e) {
        StringBuffer sb = new StringBuffer();
        sb.append(e.toString()).append("\n");
        StackTraceElement[] stackArray = e.getStackTrace();

        for (int i = 0; i < stackArray.length; ++i) {
            StackTraceElement element = stackArray[i];
            sb.append(element.toString() + "\n");
        }

        return sb.toString();
    }

    public static <T extends SpecificRecordBase> byte[] serializeEncounter(T data, Schema myShema) throws FHIRServiceException {
        DatumWriter<T> datumWriter = new SpecificDatumWriter<T>();
        ByteArrayOutputStream stream = new ByteArrayOutputStream();

        DataFileWriter<T> dataFileWriter = new DataFileWriter<T>(datumWriter);
        try {
            dataFileWriter.create(myShema, stream);
            dataFileWriter.append(data);
            dataFileWriter.close();
        } catch (IOException e) {
            String err = "Exception happened while serializing the data";
            throw new FHIRServiceException(err, e);
        }
        return stream.toByteArray();
    }


    public static byte[] jsonToAvro(String json, String schemaStr) throws IOException {
        InputStream input = null;
        DataFileWriter<GenericRecord> writer = null;
        Encoder encoder = null;
        ByteArrayOutputStream output = null;
        try {
            Schema schema = new Schema.Parser().parse(schemaStr);
            DatumReader<GenericRecord> reader = new GenericDatumReader<GenericRecord>(schema);
            input = new ByteArrayInputStream(json.getBytes());
            output = new ByteArrayOutputStream();
            DataInputStream din = new DataInputStream(input);
            writer = new DataFileWriter<GenericRecord>(new GenericDatumWriter<GenericRecord>());
            writer.create(schema, output);
            Decoder decoder = DecoderFactory.get().jsonDecoder(schema, din);
            GenericRecord datum;
            while (true) {
                try {
                    datum = reader.read(null, decoder);
                } catch (EOFException eofe) {
                    break;
                }
                writer.append(datum);
            }
            writer.flush();
            return output.toByteArray();
        } finally {
            try {
                input.close();
            } catch (Exception e) {
            }
        }
    }

    public static DataFileStream<GenericRecord> deserializeRecord(byte[] value, Schema myShema) throws FHIRServiceException {
        ByteArrayInputStream stream = new ByteArrayInputStream(value);
        DatumReader<GenericRecord> datumReader = new GenericDatumReader<GenericRecord>(myShema);
        DataFileStream<GenericRecord> dataFileReader = null;
        try {
            dataFileReader = new DataFileStream<GenericRecord>(stream, datumReader);
        } catch (IOException e) {
            String err = "Exception happened while deserializing the data";
            throw new FHIRServiceException(err, e);
        }
        return dataFileReader;
    }

    public enum fhir_code {
        DATABASE_ERROR, TOKEN_VALIDATION_ERROR, HBASE_CONNECTION_ERROR, UNEXPECTED_ERROR, IBOR_SERVICE_ERROR, IBOR_DATA_ERROR, PAYLOAD_ERROR
    }

    /**
     * This method build rowkey from encounter fields
     * @param enc
     * @return
     */
    public static String updateRowKey(CMTPayloadEncounter enc) {
        StringBuilder rowKey = new StringBuilder("encounter");
        rowKey.append("#" + enc.getEID());
        rowKey.append("#" + enc.getEncounter().getStartDate());
        rowKey.append("#" + enc.getEncounter().getEndDate());
        rowKey.append("#" + enc.getCmtCreatedDt());
        rowKey.append("#" + enc.getSource());
        enc.setRowKey(rowKey);
        return rowKey.toString();
    }
}
