### Configuration
#### Health Check
GET `localhost:8080/healthcheck`

```text
curl -X GET \
  http://localhost:8080/healthcheck \
  -H 'cache-control: no-cache'
```

#### Configuration path
Path to config file is `./config/config.properties`  

#### Keytab file
Path to Keytab should be set via configuration file.

##### Generating new keytab
ktutil --keytab=/Users/m36014/Downloads/SVT_FHIR_BIGDATA@SILVER.COM.keytab add --principal=SVT_FHIR_BIGDATA@SILVER.COM --enctype=aes256-cts-hmac-sha1-96

### Local run
#### Keytab 
 specify path to keytab file in configuration file.    
 
#### Certs
To be able make a call from code it IBOR you need specify additional certificates
-Djavax.net.ssl.trustStore=$JAVA_HOME/jre/lib/security/cacert
-Djavax.net.ssl.trustStorePassword=changeit

### Generate avro classes.  

```text
java -jar $ATP compile schema ./avroschema/hbase_cmt_encounter.avsc src/main/java
```

Where $ATP is a path to `avro-tools-1.8.2.jar`.  
get `avro-tools-1.8.2.jar`  
```text
curl http://apache.claz.org/avro/avro-1.8.2/java/avro-tools-1.8.2.jar --output avro-tools-1.8.2.jar
```

## Examples

Beware that this is only examples and probably some improvements should be introduced.  
For example: Return values, MediaTypes.  

### Scan and deserialize HBASE records.
```text
public void scanTable() throws IOException {
        Table table = this.connection.getTable(TableName.valueOf(Application.CONFIG.getCmtResourcesHBaseTableName()));
        ResultScanner scanner = table.getScanner(Bytes.toBytes(CmtHBaseRepository.familyName));

        // Reading values from scan result
        for (Result result = scanner.next(); result != null; result = scanner.next()) {
            System.out.println("Found row : " + result);

            byte[] family = Bytes.toBytes(CmtHBaseRepository.familyName);
            byte[] column = Bytes.toBytes(CmtHBaseRepository.cmtEncounterColumnName);
            byte[] data = result.getValue(family, column);

            AvroSerializer avroSerializer = new AvroSerializer();
            System.out.println(avroSerializer.deserializeRecord(data, CMTEncounter.getClassSchema()).next());
        }

        scanner.close();
    }
```

Code in controller could look like this.
```text
    @Get("/scan")
    @Produces(MediaType.APPLICATION_JSON)
    public String scan() throws IOException {
        this.repository.scanTable();

        return "Hello World";
    }
```